<?php
/**
 * Al desinstalar el plugin: borra lo que guarda.
 *
 * El plugin no tiene ajustes ni tablas. Lo que deja en la base de datos es:
 *
 * - Los totales de ventas de Inicio: cinco transients (uno por periodo) que
 *   caducan solos al minuto. Aquí se borran sin esperar.
 * - Los avisos de pedidos nuevos, si alguien los activó en la app: el
 *   identificador de avisos de cada teléfono (una meta de usuario), la lista
 *   de quién tiene alguno y lo que esperaba su recibo (dos opciones) y las
 *   tareas encoladas. Se borra todo (APSW_App_Push::uninstall()); las tareas,
 *   si Action Scheduler está cargado, que viene con WooCommerce: sin él no
 *   hay con qué cancelarlas, y cuando corran sin el plugin no harán nada.
 * - Las fotos que la app sube para un producto nuevo, mientras no son de
 *   ningún producto: una marca en cada una (una meta del adjunto) y la tarea
 *   de WordPress que borra las que nadie usó. Aquí se quitan las marcas y la
 *   tarea (APSW_App_Uploads::uninstall()). Las fotos no: las de un producto
 *   son de la tienda, y las que estaban pendientes se quedan en la biblioteca
 *   de medios, como cualquier otra imagen.
 *
 * Nada más se toca: ni pedidos —la marca de que un pedido ya avisó se queda
 * con él, es parte de su historial—, ni productos —el que se creó desde la
 * app conserva la meta con el identificador de su formulario—, ni las contraseñas de
 * aplicación que cada usuario creó para la app, que son suyas y se revocan
 * desde su perfil.
 *
 * En una red de sitios, los transients se borran en el sitio desde el que se
 * desinstala (los de los demás caducan solos); los teléfonos, en todos.
 *
 * @package Mosley_Digital_Woo
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Los nombres de los transients los sabe la clase de Inicio. Si el otro plugin
// de Mosley Digital está activo ya la declaró él: no se declara dos veces.
if ( ! class_exists( 'APSW_App_Home', false ) ) {
	require_once __DIR__ . '/includes/app/class-apsw-app-home.php';
}

APSW_App_Home::forget_sales_cache();

if ( ! class_exists( 'APSW_App_Push', false ) ) {
	require_once __DIR__ . '/includes/app/class-apsw-app-push.php';
}

/*
 * Los teléfonos son los mismos para otra copia de este plugin, en otra
 * carpeta, y para el otro plugin de Mosley Digital: mientras alguno siga
 * activo, son suyos y no se borran.
 *
 * Quién sigue activo se mira en la lista de plugins activos de WordPress, sin
 * contar el que se desinstala, y no en las constantes que este proceso tenga
 * definidas: quien desactiva y desinstala de una vez (`wp plugin uninstall
 * --deactivate`) todavía tiene cargado el plugin que está desinstalando. Del
 * otro plugin se dice aquí dónde está si está cargado; si no lo está —quien
 * desinstala sin cargar los plugins, con `--skip-plugins`—, se le reconoce en
 * la lista igualmente, porque trae la misma clase de los avisos.
 */
$mosley_digital_woo_sharing = array( 'mosley-digital-for-woocommerce.php' );

if ( defined( 'APSW_PLUGIN_FILE' ) ) {
	$mosley_digital_woo_sharing[] = plugin_basename( APSW_PLUGIN_FILE );
}

APSW_App_Push::uninstall( WP_UNINSTALL_PLUGIN, $mosley_digital_woo_sharing );

// Y lo de las fotos que la app sube para un producto nuevo: ver arriba.
if ( ! class_exists( 'APSW_App_Uploads', false ) ) {
	require_once __DIR__ . '/includes/app/class-apsw-app-uploads.php';
}

APSW_App_Uploads::uninstall( WP_UNINSTALL_PLUGIN, $mosley_digital_woo_sharing );

unset( $mosley_digital_woo_sharing );
