<?php
/**
 * Los avisos de pedidos nuevos de la app móvil.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Avisa a los teléfonos registrados en la tienda cuando entra un pedido.
 *
 * El aviso viaja así: pedido → WooCommerce → una tarea en segundo plano de
 * este plugin → el servicio de avisos de Expo → Apple o Google → el teléfono.
 * Es la única petición hacia fuera que hace el plugin, y solo la hace si
 * alguien activó los avisos en la app para esta tienda: sin ningún teléfono
 * registrado no se encola nada ni se llama a nadie.
 *
 * Tres partes:
 *
 * - **Los teléfonos.** Cada usuario registra el identificador de avisos de su
 *   teléfono (`ExponentPushToken[…]`), lo borra y ve los suyos. Se guardan en
 *   una meta de usuario, por identificador: su plataforma, cuándo se registró,
 *   el último error que dio y la dirección de la tienda en la que se registró.
 *   Nada más: ni el nombre del teléfono ni su versión. Hacia fuera, un
 *   teléfono se nombra por un resumen de su identificador, nunca por el
 *   identificador.
 * - **El disparo.** Un pedido que llega a «Procesando», a «En espera» o a
 *   «Completado» —el de solo descargas pasa de pagarse a completado— desde un
 *   estado en el que todavía no era un pedido en firme: pendiente de pago,
 *   fallido, cancelado, un borrador, o ninguno porque acaba de crearse. Lo
 *   que cuenta es el estado del que viene: el que viene de uno de esos tres,
 *   de reembolsado o de la papelera no es un pedido nuevo. Tampoco el que se
 *   crea con una fecha de hace más de un día: es un pedido antiguo que alguien
 *   está importando o apuntando a mano. Una vez por pedido: lo apunta en una
 *   meta del pedido y encola una tarea de Action Scheduler. Nunca envía dentro
 *   de la petición que cambia el pedido, que suele ser la compra del cliente.
 * - **El envío.** La tarea reúne los teléfonos de los usuarios que en ese
 *   momento pueden editar pedidos —menos los de quien hizo el cambio, que ya
 *   lo sabe, y los que se registraron en otra dirección, que son de una copia
 *   de la tienda—, compone el aviso y se lo manda a Expo, sin credenciales, de
 *   cien en cien. Un intento por pedido. A los quince minutos otra tarea pide
 *   los recibos. Un teléfono que Expo da por no registrado se borra; cualquier
 *   otro error se apunta en el teléfono y en el registro de WooCommerce, sin
 *   escribir nunca un identificador entero.
 *
 * El texto del aviso lleva el número y el importe del pedido y el nombre de la
 * tienda: ni el nombre del cliente ni ningún dato suyo, porque pasa por Expo y
 * por Apple o Google.
 *
 * No comprueba los permisos de las rutas: eso es cosa de APSW_App_Rest.
 */
class APSW_App_Push {

	/**
	 * La meta de usuario con sus teléfonos. En una red de sitios cada sitio
	 * tiene la suya (ver meta_key()).
	 */
	const DEVICES_META = 'apsw_app_push_devices';

	/**
	 * La opción, de carga automática, con los ids de los usuarios que tienen
	 * algún teléfono registrado. Es lo que se mira al cambiar un pedido: si
	 * está vacía no se consulta ningún usuario ni se encola nada. Vacía no se
	 * guarda, y se lee de las opciones que WordPress ya tiene cargadas: ver
	 * users().
	 */
	const USERS_OPTION = 'apsw_app_push_users';

	/**
	 * La opción, que no es de carga automática, con lo que Expo aceptó de cada
	 * pedido y espera su recibo: id del pedido => array( time, tickets ). Solo
	 * la tocan las tareas en segundo plano.
	 */
	const TICKETS_OPTION = 'apsw_app_push_tickets';

	/** La meta del pedido que ya avisó: el instante en que se encoló. */
	const SENT_META = '_apsw_app_push_sent';

	/** La tarea que envía el aviso de un pedido. */
	const SEND_HOOK = 'apsw_app_push_order';

	/** La tarea que pide los recibos de ese envío. */
	const RECEIPTS_HOOK = 'apsw_app_push_receipts';

	/** El grupo de las dos tareas en Action Scheduler. */
	const GROUP = 'apsw-app-push';

	/**
	 * El servicio de avisos de Expo. Las dos peticiones salen de aquí: `/send`
	 * y `/getReceipts`. El filtro `apsw_app_push_endpoint` deja apuntarlas a
	 * otro sitio, para probar contra un servidor local.
	 */
	const ENDPOINT = 'https://exp.host/--/api/v2/push';

	/** Teléfonos por usuario: al registrar uno más se borra el más antiguo. */
	const MAX_DEVICES = 10;

	/**
	 * Los estados a los que llega un pedido nuevo: los dos que la app llama
	 * «por atender», y «Completado», que es adonde va al pagarse un pedido que
	 * no hay que preparar —solo descargas—
	 * (`WC_Order::payment_complete()` y `needs_processing()`).
	 */
	const NOTIFY_STATUSES = array( 'processing', 'on-hold', 'completed' );

	/**
	 * Los estados desde los que un cambio no es un pedido nuevo: ya era un
	 * pedido en firme, o se devolvió, o vuelve de la papelera.
	 */
	const SETTLED_STATUSES = array( 'processing', 'on-hold', 'completed', 'refunded', 'trash' );

	/**
	 * Los estados en los que, cuando le toca a la tarea, ya no hay nada que
	 * avisar.
	 */
	const GONE_STATUSES = array( 'cancelled', 'failed', 'refunded', 'trash' );

	const PLATFORMS = array( 'ios', 'android' );

	/** El canal de Android que crea la app, «Pedidos nuevos». */
	const CHANNEL = 'orders';

	/** Mensajes por petición de envío, y recibos por petición: los topes de Expo. */
	const SEND_BATCH    = 100;
	const RECEIPT_BATCH = 300;

	/** Segundos que se espera a Expo. */
	const TIMEOUT = 10;

	/** Segundos entre el envío y la petición de sus recibos. */
	const RECEIPTS_DELAY = 900;

	/**
	 * Segundos que vale un aviso encolado, y que se guarda lo que Expo aceptó
	 * de él: una tarea que corre un día después —la cola estuvo parada, o el
	 * plugin desinstalado— ya no avisa de nada.
	 */
	const LIFETIME = 86400;

	/**
	 * Segundos de antigüedad a partir de los que un pedido que se acaba de
	 * crear no es un pedido nuevo: se está importando, o apuntando a mano con
	 * una fecha anterior. Solo cuenta para el que nace en la petición que lo
	 * avisa; el que ya existía —pendiente de pago desde hace una semana, y
	 * pagado hoy— es una venta de hoy, tenga la fecha que tenga.
	 */
	const MAX_AGE = 86400;

	/** La fuente de lo que se escribe en el registro de WooCommerce. */
	const LOG_SOURCE = 'mosley-digital';

	/**
	 * Tareas que no se pudieron encolar porque Action Scheduler aún no estaba
	 * listo: array( gancho, argumentos, segundos de espera ).
	 *
	 * @var array
	 */
	private $waiting = array();

	/**
	 * Los pedidos que se han creado en esta petición: id => true. Ver
	 * remember_new_order().
	 *
	 * @var array
	 */
	private $created = array();

	/**
	 * Cuántas veces de las que se ha disparado `woocommerce_new_order` ha
	 * llegado ya a remember_new_order(). Ver is_being_created().
	 *
	 * @var int
	 */
	private $remembered = 0;

	/**
	 * Si los ganchos ya están puestos.
	 *
	 * @var bool
	 */
	private static $hooked = false;

	/**
	 * Engancha el disparo, las dos tareas, la limpieza de un usuario borrado y
	 * las herramientas de privacidad de WordPress.
	 *
	 * @return void
	 */
	public function init() {
		if ( self::$hooked ) {
			return;
		}

		self::$hooked = true;

		// Las veces que `woocommerce_new_order` se disparó antes de que esto
		// escuchara no van a llegar a remember_new_order().
		$this->remembered = (int) did_action( 'woocommerce_new_order' );

		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status_changed' ), 10, 4 );
		add_action( 'woocommerce_new_order', array( $this, 'remember_new_order' ), PHP_INT_MIN );
		add_action( 'woocommerce_new_order', array( $this, 'on_new_order' ), 10, 2 );
		add_action( self::SEND_HOOK, array( $this, 'send' ), 10, 3 );
		add_action( self::RECEIPTS_HOOK, array( $this, 'check_receipts' ) );
		add_action( 'deleted_user', array( __CLASS__, 'forget_user' ) );
		add_action( 'remove_user_from_blog', array( __CLASS__, 'forget_user_of_site' ), 10, 2 );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
	}

	/*
	 * Los teléfonos.
	 */

	/**
	 * Los teléfonos de un usuario, del más antiguo al más nuevo.
	 *
	 * @param int $user_id Id del usuario.
	 * @return array array( devices => lista de array( id, platform, registered_at ) ).
	 */
	public function devices( $user_id ) {
		$user_id = (int) $user_id;
		$devices = self::devices_of( $user_id );
		$list    = array();

		// Tiene teléfonos y no está en la lista de la tienda: se le vuelve a
		// apuntar, para que el pedido siguiente lo encuentre.
		if ( $devices && ! in_array( $user_id, self::users(), true ) ) {
			self::save( $user_id, $devices );
		}

		foreach ( self::oldest_first( $devices ) as $token => $device ) {
			$list[] = array(
				'id'            => self::device_id( $token ),
				'platform'      => $device['platform'],
				'registered_at' => (string) wp_date( 'c', $device['registered_at'] ),
			);
		}

		return array( 'devices' => $list );
	}

	/**
	 * Registra el teléfono de un usuario.
	 *
	 * Registrar otra vez el mismo no lo duplica: se queda con su fecha, y se
	 * le borra el error que tuviera. Un teléfono es de quien lo registró el
	 * último: si otro usuario de la tienda lo tenía, deja de tenerlo, para que
	 * un pedido no le llegue dos veces y para que al apagar los avisos no
	 * siga llegando por el otro.
	 *
	 * Con cada teléfono se guarda la dirección de la tienda en la que se
	 * registra: una copia de la tienda en otra dirección (un entorno de
	 * pruebas) se lleva los teléfonos en su base de datos, y no tiene que
	 * avisarles (ver same_site()).
	 *
	 * @param int   $user_id  Id del usuario.
	 * @param mixed $token    El identificador de avisos de Expo.
	 * @param mixed $platform `ios` o `android`.
	 * @return array|WP_Error array( id ), o invalid_token / invalid_platform (400).
	 */
	public function register( $user_id, $token, $platform ) {
		$user_id = (int) $user_id;

		if ( ! self::is_token( $token ) ) {
			return self::invalid_token();
		}

		if ( ! is_string( $platform ) || ! in_array( $platform, self::PLATFORMS, true ) ) {
			return new WP_Error( 'invalid_platform', __( 'The platform must be ios or android.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		foreach ( self::users() as $other ) {
			if ( $other === $user_id ) {
				continue;
			}

			$theirs = self::devices_of( $other );

			if ( isset( $theirs[ $token ] ) ) {
				unset( $theirs[ $token ] );
				self::save( $other, $theirs );
			}
		}

		$devices = self::devices_of( $user_id );

		$devices[ $token ] = array(
			'platform'      => $platform,
			'registered_at' => isset( $devices[ $token ] ) ? $devices[ $token ]['registered_at'] : time(),
			'last_error'    => '',
			'site'          => self::home(),
		);

		// Con el undécimo se va el más antiguo de los que había.
		while ( count( $devices ) > self::MAX_DEVICES ) {
			foreach ( array_keys( self::oldest_first( $devices ) ) as $oldest ) {
				if ( $oldest !== $token ) {
					unset( $devices[ $oldest ] );
					break;
				}
			}
		}

		self::save( $user_id, $devices );

		return array( 'id' => self::device_id( $token ) );
	}

	/**
	 * Borra el teléfono de un usuario. Borrar uno que no está no es un error.
	 *
	 * @param int   $user_id Id del usuario.
	 * @param mixed $token   El identificador de avisos de Expo.
	 * @return array|WP_Error array( removed ), o invalid_token (400).
	 */
	public function unregister( $user_id, $token ) {
		$user_id = (int) $user_id;

		if ( ! self::is_token( $token ) ) {
			return self::invalid_token();
		}

		$devices = self::devices_of( $user_id );
		$removed = isset( $devices[ $token ] );

		if ( $removed ) {
			unset( $devices[ $token ] );
			self::save( $user_id, $devices );
		}

		return array( 'removed' => $removed );
	}

	/**
	 * Cuántos teléfonos tienen los avisos activados para esta tienda: los
	 * registrados en esta dirección.
	 *
	 * @return int
	 */
	public static function device_count() {
		$count = 0;

		foreach ( self::users() as $user_id ) {
			foreach ( self::devices_of( $user_id ) as $device ) {
				if ( self::same_site( $device['site'] ) ) {
					++$count;
				}
			}
		}

		return $count;
	}

	/**
	 * Si algo es un identificador de avisos de Expo: `ExponentPushToken[…]`, o
	 * `ExpoPushToken[…]`, que es como los escribían las versiones anteriores
	 * de Expo. Entre los corchetes, caracteres visibles y ningún corchete.
	 *
	 * @param mixed $token Lo que llegó.
	 * @return bool
	 */
	public static function is_token( $token ) {
		return is_string( $token ) && 1 === preg_match( '/\AExpo(?:nent)?PushToken\[[\x21-\x5A\x5C\x5E-\x7E]{1,200}\]\z/', $token );
	}

	/**
	 * El nombre de un teléfono hacia fuera: un resumen de su identificador.
	 *
	 * @param string $token El identificador de avisos.
	 * @return string
	 */
	public static function device_id( $token ) {
		return hash( 'sha256', (string) $token );
	}

	/**
	 * El error de un identificador que no lo es.
	 *
	 * @return WP_Error
	 */
	private static function invalid_token() {
		return new WP_Error( 'invalid_token', __( 'That push token is not valid.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
	}

	/**
	 * La clave de la meta de los teléfonos. En una red de sitios las metas de
	 * usuario son de toda la red, y cada sitio es una tienda con sus avisos:
	 * la clave lleva el id del sitio, para que apagarlos en una tienda no los
	 * apague en las demás.
	 *
	 * @return string
	 */
	private static function meta_key() {
		return is_multisite() ? self::DEVICES_META . '_' . get_current_blog_id() : self::DEVICES_META;
	}

	/**
	 * Los ids de los usuarios con algún teléfono registrado en esta tienda.
	 *
	 * Se leen de las opciones de carga automática, que WordPress trae todas
	 * juntas al arrancar (`wp_load_alloptions()`), y no con `get_option()`: la
	 * opción no existe mientras nadie activa los avisos, y `get_option()` va a
	 * la base de datos, una vez por petición, a preguntar por una opción que
	 * no está entre las cargadas. Así, en una tienda sin teléfonos, esto no
	 * cuesta ninguna consulta.
	 *
	 * @return int[]
	 */
	private static function users() {
		$options = wp_load_alloptions();
		$users   = is_array( $options ) && isset( $options[ self::USERS_OPTION ] ) ? maybe_unserialize( $options[ self::USERS_OPTION ] ) : array();

		return is_array( $users ) ? array_values( array_unique( array_filter( array_map( 'intval', $users ) ) ) ) : array();
	}

	/**
	 * Los teléfonos guardados de un usuario, solo los que están bien formados.
	 *
	 * @param int $user_id Id del usuario.
	 * @return array identificador => array( platform, registered_at, last_error, site ).
	 */
	private static function devices_of( $user_id ) {
		$stored  = $user_id > 0 ? get_user_meta( $user_id, self::meta_key(), true ) : array();
		$devices = array();

		foreach ( is_array( $stored ) ? $stored : array() as $token => $device ) {
			if ( ! self::is_token( $token ) || ! is_array( $device ) || ! isset( $device['platform'] ) || ! in_array( $device['platform'], self::PLATFORMS, true ) ) {
				continue;
			}

			$devices[ $token ] = array(
				'platform'      => $device['platform'],
				'registered_at' => isset( $device['registered_at'] ) && is_numeric( $device['registered_at'] ) ? (int) $device['registered_at'] : 0,
				'last_error'    => isset( $device['last_error'] ) && is_string( $device['last_error'] ) ? $device['last_error'] : '',
				'site'          => isset( $device['site'] ) && is_string( $device['site'] ) ? $device['site'] : '',
			);
		}

		return $devices;
	}

	/**
	 * Si un teléfono se registró en esta tienda y no en una copia suya en otra
	 * dirección.
	 *
	 * Se compara el host, el puerto y la ruta de la dirección guardada con los
	 * de la tienda (ver home()), sin el protocolo y sin un `www.` delante:
	 * pasar la tienda a HTTPS, o quitarle las www, no la convierte en otra. Un
	 * teléfono sin dirección guardada es de esta.
	 *
	 * @param string $site La dirección guardada con el teléfono.
	 * @return bool
	 */
	private static function same_site( $site ) {
		return '' === $site || self::site_key( $site ) === self::site_key( self::home() );
	}

	/**
	 * La dirección de la tienda como está guardada: la opción `home` —o la
	 * constante `WP_HOME`, que WordPress pone en su lugar al leerla—, sin la
	 * barra del final.
	 *
	 * Es la que se guarda con cada teléfono y la que viaja en el aviso, y la
	 * app busca con ella —por su host, su puerto y su ruta— a cuál de sus
	 * tiendas pertenece. Por eso no es `home_url()`: su resultado pasa por un
	 * filtro, y los plugins de varios idiomas le añaden la carpeta del idioma
	 * de cada petición. La tarea que envía corre en una petición cualquiera, y
	 * con `home_url()` el aviso podría decir `…/en` de una tienda que la app
	 * conoce sin esa carpeta.
	 *
	 * La opción es de carga automática: leerla no cuesta una consulta.
	 *
	 * @return string
	 */
	private static function home() {
		$home = get_option( 'home' );

		return is_string( $home ) ? untrailingslashit( trim( $home ) ) : '';
	}

	/**
	 * Lo que identifica a una tienda en su dirección: host (sin un `www.`
	 * delante), puerto y ruta.
	 *
	 * @param string $url Dirección.
	 * @return string
	 */
	private static function site_key( $url ) {
		$parts = wp_parse_url( (string) $url );

		if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
			return '';
		}

		$host = strtolower( (string) $parts['host'] );
		$host = 0 === strpos( $host, 'www.' ) ? substr( $host, 4 ) : $host;

		return $host . ( isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '' ) . ( isset( $parts['path'] ) ? rtrim( (string) $parts['path'], '/' ) : '' );
	}

	/**
	 * Unos teléfonos, del más antiguo al más nuevo. Los que se registraron en
	 * el mismo segundo se quedan en el orden en que se guardaron.
	 *
	 * @param array $devices identificador => teléfono.
	 * @return array
	 */
	private static function oldest_first( array $devices ) {
		$order = array_flip( array_keys( $devices ) );

		uksort(
			$devices,
			static function ( $a, $b ) use ( $devices, $order ) {
				return array( $devices[ $a ]['registered_at'], $order[ $a ] ) <=> array( $devices[ $b ]['registered_at'], $order[ $b ] );
			}
		);

		return $devices;
	}

	/**
	 * Guarda los teléfonos de un usuario y deja al día la lista de la tienda:
	 * el usuario está en ella mientras tenga alguno.
	 *
	 * @param int   $user_id Id del usuario.
	 * @param array $devices identificador => teléfono.
	 * @return void
	 */
	private static function save( $user_id, array $devices ) {
		if ( $user_id < 1 ) {
			return;
		}

		if ( $devices ) {
			update_user_meta( $user_id, self::meta_key(), $devices );
		} else {
			delete_user_meta( $user_id, self::meta_key() );
		}

		$users = self::users();
		$known = in_array( $user_id, $users, true );

		if ( $devices && ! $known ) {
			$users[] = $user_id;
		} elseif ( ! $devices && $known ) {
			$users = array_values( array_diff( $users, array( $user_id ) ) );
		} else {
			return;
		}

		self::save_users( $users );
	}

	/**
	 * Guarda la lista de la tienda. Vacía no se guarda: se borra, y una tienda
	 * sin teléfonos no tiene nada de este plugin en sus opciones.
	 *
	 * @param int[] $users Ids de usuario.
	 * @return void
	 */
	private static function save_users( array $users ) {
		if ( $users ) {
			update_option( self::USERS_OPTION, array_values( $users ), true );
		} else {
			delete_option( self::USERS_OPTION );
		}
	}

	/**
	 * Un usuario borrado deja de estar en la lista de la tienda. Sus metas las
	 * borra WordPress con él.
	 *
	 * @param int $user_id Id del usuario.
	 * @return void
	 */
	public static function forget_user( $user_id ) {
		$users = self::users();

		if ( in_array( (int) $user_id, $users, true ) ) {
			self::save_users( array_values( array_diff( $users, array( (int) $user_id ) ) ) );
		}
	}

	/**
	 * En una red de sitios, un usuario al que se quita de este sitio se queda
	 * sin sus teléfonos de aquí.
	 *
	 * @param int $user_id Id del usuario.
	 * @param int $blog_id Id del sitio del que se le quita.
	 * @return void
	 */
	public static function forget_user_of_site( $user_id, $blog_id = 0 ) {
		if ( (int) $blog_id === (int) get_current_blog_id() ) {
			self::save( (int) $user_id, array() );
		}
	}

	/*
	 * Las herramientas de privacidad de WordPress.
	 */

	/**
	 * Añade a la exportación de datos personales los teléfonos del usuario.
	 *
	 * @param mixed $exporters Los exportadores registrados.
	 * @return array
	 */
	public static function register_exporter( $exporters ) {
		$exporters = is_array( $exporters ) ? $exporters : array();

		$exporters['mosley-digital-push'] = array(
			'exporter_friendly_name' => __( 'Mosley Digital: phones with new order notifications', 'mosley-digital-for-woocommerce' ),
			'callback'               => array( __CLASS__, 'export_personal_data' ),
		);

		return $exporters;
	}

	/**
	 * Añade al borrado de datos personales los teléfonos del usuario.
	 *
	 * @param mixed $erasers Los borradores registrados.
	 * @return array
	 */
	public static function register_eraser( $erasers ) {
		$erasers = is_array( $erasers ) ? $erasers : array();

		$erasers['mosley-digital-push'] = array(
			'eraser_friendly_name' => __( 'Mosley Digital: phones with new order notifications', 'mosley-digital-for-woocommerce' ),
			'callback'             => array( __CLASS__, 'erase_personal_data' ),
		);

		return $erasers;
	}

	/**
	 * Los teléfonos registrados de una persona, para la exportación de sus
	 * datos: la plataforma, la fecha y el resumen del identificador. El
	 * identificador no sale nunca.
	 *
	 * @param string $email_address Correo de la persona.
	 * @param int    $page          Página de la exportación; aquí hay una sola.
	 * @return array array( data, done ).
	 */
	public static function export_personal_data( $email_address, $page = 1 ) {
		$user  = get_user_by( 'email', (string) $email_address );
		$items = array();

		foreach ( $user ? self::oldest_first( self::devices_of( (int) $user->ID ) ) : array() as $token => $device ) {
			$items[] = array(
				'group_id'    => 'mosley-digital-push',
				'group_label' => __( 'Mosley Digital: phones with new order notifications', 'mosley-digital-for-woocommerce' ),
				'item_id'     => 'mosley-digital-push-' . substr( self::device_id( $token ), 0, 12 ),
				'data'        => array(
					array(
						'name'  => __( 'Phone id', 'mosley-digital-for-woocommerce' ),
						'value' => self::device_id( $token ),
					),
					array(
						'name'  => __( 'Platform', 'mosley-digital-for-woocommerce' ),
						'value' => $device['platform'],
					),
					array(
						'name'  => __( 'Registered on', 'mosley-digital-for-woocommerce' ),
						'value' => (string) wp_date( 'c', $device['registered_at'] ),
					),
				),
			);
		}

		return array(
			'data' => $items,
			'done' => true,
		);
	}

	/**
	 * Borra los teléfonos registrados de una persona, cuando pide que se borren
	 * sus datos.
	 *
	 * @param string $email_address Correo de la persona.
	 * @param int    $page          Página del borrado; aquí hay una sola.
	 * @return array array( items_removed, items_retained, messages, done ).
	 */
	public static function erase_personal_data( $email_address, $page = 1 ) {
		$user    = get_user_by( 'email', (string) $email_address );
		$removed = $user ? count( self::devices_of( (int) $user->ID ) ) : 0;

		if ( $removed ) {
			self::save( (int) $user->ID, array() );
		}

		return array(
			'items_removed'  => $removed > 0,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);
	}

	/*
	 * El disparo.
	 */

	/**
	 * Un pedido cambió de estado (`woocommerce_order_status_changed`, que
	 * `WC_Order::status_transition()` dispara después de guardar el pedido).
	 *
	 * Avisa el que llega a uno de los estados de un pedido nuevo desde uno en
	 * el que todavía no lo era. Cuenta el estado del que viene: el que viene
	 * de «por atender» o de completado, o de reembolsado, o vuelve de la
	 * papelera, no es un pedido nuevo, haya avisado o no, y hubiera o no
	 * teléfonos cuando llegó.
	 *
	 * El estado anterior no dice si el pedido existía: un pedido al que se le
	 * pone el estado antes de guardarlo por primera vez
	 * (`wc_create_order( array( 'status' => … ) )`) llega aquí con `pending`
	 * de estado anterior, que es el que tiene un pedido sin guardar, y el que
	 * sale del borrador en blanco del wp-admin también
	 * (`WC_Abstract_Order::set_status()` cuenta `auto-draft` como `pending`).
	 * Eso lo dice is_being_created().
	 *
	 * @param int           $order_id Id del pedido.
	 * @param string        $from     Estado anterior, sin `wc-`.
	 * @param string        $to       Estado nuevo, sin `wc-`.
	 * @param WC_Order|null $order    El pedido.
	 * @return void
	 */
	public function on_status_changed( $order_id, $from = '', $to = '', $order = null ) {
		$order_id = (int) $order_id;

		// El que sale de un borrador del pago no se creó ahora: el cliente lo
		// tenía abierto, quizá desde ayer, y lo que ocurre ahora es la venta.
		if ( 'checkout-draft' === (string) $from ) {
			unset( $this->created[ $order_id ] );
		}

		if ( ! in_array( (string) $to, self::NOTIFY_STATUSES, true ) || in_array( (string) $from, self::SETTLED_STATUSES, true ) ) {
			return;
		}

		$this->maybe_notify( $order instanceof WC_Order ? $order : $order_id, 'checkout-draft' !== (string) $from && $this->is_being_created( $order_id ) );
	}

	/**
	 * Apunta que un pedido se ha creado en esta petición: mientras dure, es un
	 * pedido recién creado, y si su fecha es de hace más de un día no avisa
	 * (ver maybe_notify()).
	 *
	 * Escucha `woocommerce_new_order` antes que nadie. Lo que escucha ese
	 * gancho puede guardar el pedido otra vez, y ese guardado dispara
	 * `woocommerce_order_status_changed` **dentro** de `woocommerce_new_order`,
	 * antes de que les toque a los que vienen detrás: lo hace WooCommerce con
	 * los pedidos creados en el wp-admin, con prioridad 2, para apuntarles su
	 * origen (`OrderAttributionController::maybe_set_admin_source()`). Para
	 * entonces esto ya tiene que haber corrido.
	 *
	 * El gancho no dice si el pedido sale de un borrador del pago; eso lo dice
	 * el cambio de estado, que lo desapunta (on_status_changed()).
	 *
	 * @param int $order_id Id del pedido.
	 * @return void
	 */
	public function remember_new_order( $order_id ) {
		++$this->remembered;

		$this->created[ (int) $order_id ] = true;
	}

	/**
	 * Si un pedido se ha creado en esta petición.
	 *
	 * Lo está el que apuntó remember_new_order(). Y, por si algo escucha
	 * `woocommerce_new_order` todavía antes y guarda el pedido ahí mismo, el
	 * que cambia de estado mientras ese gancho corre y aún no ha llegado a
	 * remember_new_order(): se sabe porque el gancho se ha disparado más veces
	 * de las que se han apuntado. Pasado ese punto no cuenta que el gancho
	 * esté corriendo: quien, al crearse un pedido, cambia el estado de otro
	 * que ya existía no lo convierte en uno recién creado.
	 *
	 * @param int $order_id Id del pedido.
	 * @return bool
	 */
	private function is_being_created( $order_id ) {
		if ( isset( $this->created[ $order_id ] ) ) {
			return true;
		}

		return doing_action( 'woocommerce_new_order' ) && did_action( 'woocommerce_new_order' ) > $this->remembered;
	}

	/**
	 * Se creó un pedido (`woocommerce_new_order`, que los almacenes de pedidos
	 * disparan al guardarlo por primera vez con un estado que no es un
	 * borrador, o al sacarlo de borrador).
	 *
	 * Cubre el pedido que nace ya en uno de esos estados sin pasar por un
	 * cambio de estado. Al que sí pasa por él, `woocommerce_order_status_changed`
	 * le llega justo después —o antes, si alguien lo guardó dentro de este
	 * gancho—, con la meta ya puesta.
	 *
	 * @param int           $order_id Id del pedido.
	 * @param WC_Order|null $order    El pedido.
	 * @return void
	 */
	public function on_new_order( $order_id, $order = null ) {
		$this->maybe_notify( $order instanceof WC_Order ? $order : $order_id, true );
	}

	/**
	 * Encola el aviso de un pedido, si le toca: hay algún teléfono en la
	 * tienda, es un pedido (no un reembolso ni otro tipo), está en uno de los
	 * estados de un pedido nuevo y no ha avisado ya.
	 *
	 * Lo primero que se mira es si hay teléfonos, en las opciones que
	 * WordPress ya tiene cargadas: en una tienda sin ninguno, un cambio de
	 * estado no lee ni escribe nada más, ni hace una sola consulta.
	 *
	 * Con la tarea viaja quién hizo el cambio, si lo hizo un usuario
	 * identificado —desde el wp-admin, con la API REST o con la propia app—:
	 * a sus teléfonos no se les avisa de lo que él mismo acaba de hacer. En la
	 * compra de un cliente no hay nadie del equipo, y se avisa a todos.
	 *
	 * Un pedido recién creado —nace en esta petición, sin estado anterior— con
	 * una fecha de creación de hace más de un día no avisa, ni se apunta: es
	 * un pedido antiguo que alguien está importando, o apuntando a mano con su
	 * fecha. La fecha es la que tenga el pedido en este momento: la que se le
	 * puso antes de guardarlo (`WC_Order::set_date_created()`), o la de ahora
	 * si no se le puso ninguna, que es lo que hace el almacén al crearlo. A
	 * quien se la pone después de crearlo lo ve send(), que la mira otra vez.
	 * El pedido que ya existía avisa tenga la fecha que tenga: uno pendiente
	 * de pago que se paga una semana después es una venta de hoy.
	 *
	 * La meta se guarda con `save_meta_data()`, y no con `save()`: el pedido se
	 * acaba de guardar, y aquí solo se le añade esto. Si guardarla o encolar la
	 * tarea falla, se apunta en el registro y el pedido sigue su camino.
	 *
	 * @param WC_Order|int $order   El pedido, o su id.
	 * @param bool         $created Si el pedido se ha creado en esta petición.
	 * @return void
	 */
	private function maybe_notify( $order, $created ) {
		if ( ! self::users() ) {
			return;
		}

		$order = $order instanceof WC_Order ? $order : wc_get_order( (int) $order );

		if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() || ! in_array( (string) $order->get_status(), self::NOTIFY_STATUSES, true ) ) {
			return;
		}

		if ( '' !== (string) $order->get_meta( self::SENT_META ) ) {
			return;
		}

		if ( $created && self::is_old( $order, time() ) ) {
			return;
		}

		// Esto corre dentro de la petición que guarda el pedido, que suele ser
		// la compra de un cliente: pase lo que pase aquí, el pedido sigue.
		try {
			$order->update_meta_data( self::SENT_META, (string) time() );
			$order->save_meta_data();

			$this->schedule( self::SEND_HOOK, array( (int) $order->get_id(), (int) get_current_user_id(), $created ? 1 : 0 ), 0 );
		} catch ( Throwable $error ) {
			self::log( sprintf( 'Order %1$d: its notification could not be enqueued: %2$s', (int) $order->get_id(), self::redact( $error->getMessage() ) ) );
		}
	}

	/**
	 * Si la fecha de creación de un pedido es de más de un día antes de un
	 * momento dado.
	 *
	 * @param WC_Order $order El pedido.
	 * @param int      $when  El momento con el que se compara.
	 * @return bool
	 */
	private static function is_old( WC_Order $order, $when ) {
		$created = is_callable( array( $order, 'get_date_created' ) ) ? $order->get_date_created() : null;

		return $created instanceof DateTimeInterface && $when - $created->getTimestamp() > self::MAX_AGE;
	}

	/**
	 * Encola una tarea de Action Scheduler: cuanto antes, o dentro de un rato.
	 *
	 * Action Scheduler está listo desde `init` (`action_scheduler_init`); antes
	 * sus funciones no encolan nada y avisan de que se las llamó pronto. Un
	 * pedido que cambia antes de eso se encola cuando llega ese momento.
	 *
	 * @param string $hook  La tarea.
	 * @param array  $args  Sus argumentos: el id del pedido y, en la de envío, el del usuario que hizo el cambio y si el pedido estaba recién creado.
	 * @param int    $delay Segundos de espera; 0 es cuanto antes.
	 * @return void
	 */
	private function schedule( $hook, array $args, $delay ) {
		if ( ! function_exists( 'as_enqueue_async_action' ) || ! did_action( 'action_scheduler_init' ) ) {
			if ( ! $this->waiting ) {
				add_action( 'action_scheduler_init', array( $this, 'schedule_waiting' ) );
			}

			$this->waiting[] = array( $hook, $args, $delay );

			return;
		}

		if ( $delay > 0 ) {
			$task = as_schedule_single_action( time() + $delay, $hook, $args, self::GROUP );
		} else {
			$task = as_enqueue_async_action( $hook, $args, self::GROUP );
		}

		// Las dos devuelven 0 si la tarea no se pudo guardar.
		if ( ! $task ) {
			self::log( sprintf( 'Order %1$d: the task %2$s could not be enqueued.', (int) $args[0], $hook ) );
		}
	}

	/**
	 * Encola lo que estaba esperando a Action Scheduler.
	 *
	 * @return void
	 */
	public function schedule_waiting() {
		$waiting       = $this->waiting;
		$this->waiting = array();

		foreach ( $waiting as $task ) {
			$this->schedule( $task[0], $task[1], $task[2] );
		}
	}

	/*
	 * El envío.
	 */

	/**
	 * La tarea encolada: manda a Expo el aviso de un pedido. Un intento: si
	 * Expo no contesta, ese aviso se pierde y queda apuntado en el registro.
	 *
	 * No manda nada si, para cuando le toca:
	 *
	 * - el pedido ya no existe, o está cancelado, fallido, reembolsado o en la
	 *   papelera. No se le pide que siga en el estado en el que avisó: uno que
	 *   ya pasó de «Procesando» a «Completado» sigue siendo un pedido que entró;
	 * - el pedido no lleva la marca del aviso, o la lleva de hace más de un
	 *   día: es una tarea que se quedó en la cola —parada, o de antes de
	 *   desinstalar el plugin—, y a estas alturas no avisa de nada nuevo;
	 * - el pedido estaba recién creado cuando avisó y su fecha de creación ha
	 *   resultado ser de más de un día antes: quien lo importaba lo creó
	 *   primero (`wc_create_order()` no deja decir la fecha) y se la puso
	 *   después;
	 * - ya se mandó: dos peticiones que cambian el pedido a la vez —el aviso de
	 *   la pasarela y la vuelta del cliente— pueden encolar las dos.
	 *
	 * @param int $order_id Id del pedido.
	 * @param int $actor    Id del usuario que hizo el cambio; 0 si no lo hizo ninguno.
	 * @param int $created  1 si el pedido se había creado en la petición que lo avisó.
	 * @return void
	 */
	public function send( $order_id, $actor = 0, $created = 0 ) {
		$order_id = (int) $order_id;
		$order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;

		if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() || in_array( (string) $order->get_status(), self::GONE_STATUSES, true ) ) {
			return;
		}

		$marked = (int) $order->get_meta( self::SENT_META );

		if ( $marked < 1 || time() - $marked > self::LIFETIME ) {
			return;
		}

		if ( $created && self::is_old( $order, $marked ) ) {
			return;
		}

		if ( isset( self::tickets()[ $order_id ] ) ) {
			return;
		}

		$recipients = self::recipients( (int) $actor, $order_id );

		if ( ! $recipients ) {
			return;
		}

		$messages = $this->messages( $order, $recipients );
		$results  = array();
		$tickets  = array();

		foreach ( array_chunk( array_keys( $recipients ), self::SEND_BATCH ) as $tokens ) {
			$batch = array();

			foreach ( $tokens as $token ) {
				$batch[] = $messages[ $token ];
			}

			$answer = $this->request( 'send', $batch, $order_id );

			if ( null === $answer ) {
				continue;
			}

			if ( count( $answer ) < count( $tokens ) ) {
				self::log( sprintf( 'Order %1$d: the Expo push service answered %2$d results for %3$d messages.', $order_id, count( $answer ), count( $tokens ) ) );
			}

			// Expo contesta un resultado por mensaje, en el mismo orden.
			foreach ( $tokens as $index => $token ) {
				$ticket = isset( $answer[ $index ] ) && is_array( $answer[ $index ] ) ? $answer[ $index ] : array();
				$user   = $recipients[ $token ]['user'];

				if ( isset( $ticket['status'], $ticket['id'] ) && 'ok' === $ticket['status'] && is_string( $ticket['id'] ) && '' !== $ticket['id'] ) {
					$tickets[ $ticket['id'] ] = array( $user, self::device_id( $token ) );

					// Llegó: el error que tuviera ya no es el último.
					if ( '' !== $recipients[ $token ]['last_error'] ) {
						$results[ $user ][ $token ] = array( '', '' );
					}
				} elseif ( isset( $ticket['status'] ) && 'error' === $ticket['status'] ) {
					$results[ $user ][ $token ] = self::error_of( $ticket );
				}
			}
		}

		$this->apply( $results, $order_id );

		if ( $tickets ) {
			$waiting              = self::tickets();
			$waiting[ $order_id ] = array(
				'time'    => time(),
				'tickets' => $tickets,
			);

			self::save_tickets( $waiting );

			$this->schedule( self::RECEIPTS_HOOK, array( $order_id ), self::RECEIPTS_DELAY );
		}
	}

	/**
	 * La segunda tarea: pide a Expo los recibos de lo que aceptó. Ahí es donde
	 * Apple o Google dicen que un teléfono ya no existe.
	 *
	 * @param int $order_id Id del pedido.
	 * @return void
	 */
	public function check_receipts( $order_id ) {
		$order_id = (int) $order_id;
		$waiting  = self::tickets();
		$tickets  = isset( $waiting[ $order_id ]['tickets'] ) && is_array( $waiting[ $order_id ]['tickets'] ) ? $waiting[ $order_id ]['tickets'] : array();

		if ( isset( $waiting[ $order_id ] ) ) {
			unset( $waiting[ $order_id ] );
			self::save_tickets( $waiting );
		}

		if ( ! $tickets ) {
			return;
		}

		$results = array();

		foreach ( array_chunk( array_keys( $tickets ), self::RECEIPT_BATCH ) as $ids ) {
			$answer = $this->request( 'getReceipts', array( 'ids' => array_map( 'strval', $ids ) ), $order_id );

			if ( null === $answer ) {
				continue;
			}

			foreach ( $ids as $id ) {
				$receipt = isset( $answer[ $id ] ) && is_array( $answer[ $id ] ) ? $answer[ $id ] : array();
				$ticket  = is_array( $tickets[ $id ] ) ? array_values( $tickets[ $id ] ) : array();

				if ( ! isset( $receipt['status'] ) || 'error' !== $receipt['status'] || 2 !== count( $ticket ) ) {
					continue;
				}

				// El recibo nombra el teléfono por su resumen: se busca entre los
				// que su usuario tiene ahora.
				foreach ( array_keys( self::devices_of( (int) $ticket[0] ) ) as $token ) {
					if ( self::device_id( $token ) === $ticket[1] ) {
						$results[ (int) $ticket[0] ][ $token ] = self::error_of( $receipt );
					}
				}
			}
		}

		$this->apply( $results, $order_id );
	}

	/**
	 * Lo que Expo aceptó y espera su recibo, por pedido, sin lo que lleva más
	 * de un día esperando.
	 *
	 * @return array id del pedido => array( time, tickets ).
	 */
	private static function tickets() {
		$stored  = get_option( self::TICKETS_OPTION, array() );
		$waiting = array();

		foreach ( is_array( $stored ) ? $stored : array() as $order_id => $entry ) {
			if ( is_array( $entry ) && isset( $entry['time'], $entry['tickets'] ) && time() - (int) $entry['time'] <= self::LIFETIME ) {
				$waiting[ (int) $order_id ] = $entry;
			}
		}

		return $waiting;
	}

	/**
	 * Guarda lo que espera su recibo. Sin nada que esperar, la opción se borra.
	 *
	 * @param array $waiting id del pedido => array( time, tickets ).
	 * @return void
	 */
	private static function save_tickets( array $waiting ) {
		if ( $waiting ) {
			update_option( self::TICKETS_OPTION, $waiting, false );
		} else {
			delete_option( self::TICKETS_OPTION );
		}
	}

	/**
	 * A quién se avisa: los teléfonos de los usuarios de la lista de la tienda
	 * que en este momento pueden editar pedidos, cada teléfono una vez.
	 *
	 * - A quien ya no puede editar pedidos se le quitan sus teléfonos: no va a
	 *   recibir más avisos, y así la cuenta de teléfonos de la tienda es la de
	 *   verdad.
	 * - A quien hizo el cambio no se le avisa.
	 * - Un teléfono que se registró en otra dirección no recibe nada de esta,
	 *   y se queda como está: es de la tienda de la que ésta es copia. Queda
	 *   apuntado en el registro, con las dos direcciones: quien tiene la
	 *   tienda en un dominio y el WordPress en otro encuentra ahí por qué no
	 *   le llega nada.
	 *
	 * @param int $actor    Id del usuario que hizo el cambio; 0 si no lo hizo ninguno.
	 * @param int $order_id Id del pedido, para el registro.
	 * @return array identificador => array( user, platform, last_error ).
	 */
	private static function recipients( $actor, $order_id ) {
		$recipients = array();
		$elsewhere  = array();

		foreach ( self::users() as $user_id ) {
			$devices = self::devices_of( $user_id );

			if ( $devices && ! user_can( $user_id, 'edit_shop_orders' ) ) {
				self::log( sprintf( 'Order %1$d: user %2$d can no longer edit orders: their %3$d phone(s) were removed.', $order_id, $user_id, count( $devices ) ), 'info' );

				$devices = array();
			}

			// Está en la lista y no tiene ninguno: sale de ella.
			if ( ! $devices ) {
				self::save( $user_id, array() );
				continue;
			}

			if ( $user_id === $actor ) {
				continue;
			}

			foreach ( $devices as $token => $device ) {
				if ( ! self::same_site( $device['site'] ) ) {
					$elsewhere[] = self::site_key( $device['site'] );
					continue;
				}

				if ( ! isset( $recipients[ $token ] ) ) {
					$recipients[ $token ] = array(
						'user'       => $user_id,
						'platform'   => $device['platform'],
						'last_error' => $device['last_error'],
					);
				}
			}
		}

		if ( $elsewhere ) {
			self::log(
				sprintf(
					'Order %1$d: %2$d phone(s) were not notified because they are registered under another store address (%3$s); this store is %4$s. Opening the app connected to this address registers them here.',
					$order_id,
					count( $elsewhere ),
					self::redact( implode( ', ', array_slice( array_values( array_unique( $elsewhere ) ), 0, 3 ) ) ),
					self::redact( self::site_key( self::home() ) )
				),
				'info'
			);
		}

		return $recipients;
	}

	/**
	 * El aviso de un pedido para cada teléfono, como lo pide Expo.
	 *
	 * Título «Nuevo pedido» y cuerpo «#1234 · $450.00», con la moneda del
	 * pedido y el formato de la tienda, en texto llano. El nombre de la tienda
	 * va de subtítulo en iOS y de segunda línea en Android, que no tiene
	 * subtítulo: quien tiene varias tiendas en el teléfono sabe de cuál es.
	 * `data` es lo que la app lee al tocar el aviso para abrir ese pedido en
	 * esa tienda.
	 *
	 * El texto sale en el idioma de la tienda, no en el de quien esté
	 * identificado en la petición que corre la tarea.
	 *
	 * @param WC_Order $order      El pedido.
	 * @param array    $recipients identificador => array( user, platform ).
	 * @return array identificador => mensaje.
	 */
	private function messages( WC_Order $order, array $recipients ) {
		$switched = function_exists( 'switch_to_locale' ) && switch_to_locale( get_locale() );
		$title    = __( 'New order', 'mosley-digital-for-woocommerce' );

		if ( $switched ) {
			restore_previous_locale();
		}

		$store = APSW_App_Text::plain( get_bloginfo( 'name' ) );
		$body  = '#' . APSW_App_Text::plain( $order->get_order_number() ) . ' · ' . APSW_App_Text::plain( wc_price( (float) $order->get_total(), array( 'currency' => $order->get_currency() ) ) );
		$data  = array(
			'type'     => 'order',
			'order_id' => (int) $order->get_id(),
			'site'     => self::home(),
		);

		$messages = array();

		foreach ( $recipients as $token => $recipient ) {
			$message = array(
				'to'    => $token,
				'title' => $title,
				'body'  => $body,
			);

			if ( 'ios' === $recipient['platform'] ) {
				if ( '' !== $store ) {
					$message['subtitle'] = $store;
				}
			} else {
				if ( '' !== $store ) {
					$message['body'] = $body . "\n" . $store;
				}

				$message['channelId'] = self::CHANNEL;
			}

			$message['sound']    = 'default';
			$message['priority'] = 'high';
			$message['data']     = $data;

			$messages[ $token ] = $message;
		}

		return $messages;
	}

	/**
	 * Una petición al servicio de avisos de Expo, en JSON y sin credenciales.
	 * Es la única petición hacia fuera del plugin.
	 *
	 * @param string $path     `send` o `getReceipts`.
	 * @param array  $payload  El cuerpo.
	 * @param int    $order_id Id del pedido, para el registro.
	 * @return array|null Lo que Expo contesta en `data`, o null si la petición falló.
	 */
	private function request( $path, array $payload, $order_id ) {
		$endpoint = apply_filters( 'apsw_app_push_endpoint', self::ENDPOINT );
		$endpoint = is_string( $endpoint ) && '' !== $endpoint ? rtrim( $endpoint, '/' ) : self::ENDPOINT;

		$response = wp_remote_post(
			$endpoint . '/' . $path,
			array(
				'timeout'     => self::TIMEOUT,
				'headers'     => array(
					'Accept'       => 'application/json',
					'Content-Type' => 'application/json',
				),
				'body'        => wp_json_encode( $payload ),
				'data_format' => 'body',
			)
		);

		if ( is_wp_error( $response ) ) {
			self::log( sprintf( 'Order %1$d: the request to the Expo push service (%2$s) failed: %3$s', $order_id, $path, $response->get_error_message() ) );

			return null;
		}

		$status  = (int) wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $status || ! is_array( $decoded ) || ! isset( $decoded['data'] ) || ! is_array( $decoded['data'] ) ) {
			$reason = is_array( $decoded ) && isset( $decoded['errors'][0]['message'] ) && is_string( $decoded['errors'][0]['message'] ) ? self::redact( $decoded['errors'][0]['message'] ) : 'no data in the answer';

			self::log( sprintf( 'Order %1$d: the Expo push service (%2$s) answered HTTP %3$d: %4$s', $order_id, $path, $status, $reason ) );

			return null;
		}

		return $decoded['data'];
	}

	/**
	 * El error de un resultado de Expo: su código (`DeviceNotRegistered`,
	 * `MessageRateExceeded`…) y, si lo trae, lo que dice.
	 *
	 * @param array $result Un resultado de envío o un recibo, con `status` `error`.
	 * @return array array( código, mensaje ).
	 */
	private static function error_of( array $result ) {
		$code    = isset( $result['details']['error'] ) && is_string( $result['details']['error'] ) ? $result['details']['error'] : 'UnknownError';
		$message = isset( $result['message'] ) && is_string( $result['message'] ) ? $result['message'] : '';

		return array( substr( preg_replace( '/[^A-Za-z0-9_]/', '', $code ), 0, 60 ), self::redact( $message ) );
	}

	/**
	 * Hace con cada teléfono lo que su resultado pide: el que Expo da por no
	 * registrado se borra; a los demás se les apunta el error, que también va
	 * al registro de WooCommerce; y al que tenía un error y esta vez llegó, se
	 * le quita.
	 *
	 * @param array $results  id de usuario => identificador => array( código, mensaje ); el código vacío es que llegó.
	 * @param int   $order_id Id del pedido, para el registro.
	 * @return void
	 */
	private function apply( array $results, $order_id ) {
		foreach ( $results as $user_id => $errors ) {
			$devices = self::devices_of( (int) $user_id );
			$changed = false;

			foreach ( $errors as $token => $error ) {
				if ( ! isset( $devices[ $token ] ) ) {
					continue;
				}

				$name = substr( self::device_id( $token ), 0, 12 );

				if ( '' === $error[0] ) {
					// Esta vez llegó: se le quita el error que tenía.
					$devices[ $token ]['last_error'] = '';
				} elseif ( 'DeviceNotRegistered' === $error[0] ) {
					unset( $devices[ $token ] );
					self::log( sprintf( 'Order %1$d: device %2$s of user %3$d is no longer registered and was removed.', $order_id, $name, $user_id ), 'info' );
				} else {
					$devices[ $token ]['last_error'] = $error[0];
					self::log( sprintf( 'Order %1$d: device %2$s of user %3$d was not notified: %4$s %5$s', $order_id, $name, $user_id, $error[0], $error[1] ) );
				}

				$changed = true;
			}

			if ( $changed ) {
				self::save( (int) $user_id, $devices );
			}
		}
	}

	/**
	 * Un texto de Expo sin ningún identificador de avisos dentro, y con tope.
	 *
	 * @param string $text Texto.
	 * @return string
	 */
	private static function redact( $text ) {
		return substr( (string) preg_replace( '/Expo(?:nent)?PushToken\[[^\]]*\]?/', '[token]', (string) $text ), 0, 300 );
	}

	/**
	 * Escribe en el registro de WooCommerce.
	 *
	 * @param string $message Mensaje, sin identificadores de avisos.
	 * @param string $level   `warning` o `info`.
	 * @return void
	 */
	private static function log( $message, $level = 'warning' ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}

		$logger = wc_get_logger();

		if ( is_object( $logger ) && method_exists( $logger, 'log' ) ) {
			$logger->log( $level, trim( $message ), array( 'source' => self::LOG_SOURCE ) );
		}
	}

	/*
	 * Desinstalar.
	 */

	/**
	 * Borra lo que los avisos guardan: los teléfonos de todos los usuarios, la
	 * lista de la tienda, lo que esperaba su recibo y las tareas encoladas. La
	 * meta de los pedidos se queda: es parte de su historial.
	 *
	 * Salvo que los siga usando otro plugin activo: las dos ediciones del
	 * plugin, y dos copias de una misma, guardan los teléfonos en el mismo
	 * sitio. Se mira en la lista de plugins activos, sin contar el que se
	 * desinstala, y no en lo que este proceso tiene cargado: quien desactiva y
	 * desinstala en un mismo proceso (`wp plugin uninstall --deactivate`)
	 * todavía tiene cargado el plugin que está desinstalando, y quien lo hace
	 * sin cargar los plugins (`--skip-plugins`) no tiene cargado ninguno,
	 * aunque estén activos. Usa los teléfonos el plugin activo que se llama
	 * como diga `$sharing` y, se llame como se llame, el que trae esta misma
	 * clase (ver carries_notifications()).
	 *
	 * Las tareas se cancelan con Action Scheduler, que viene con WooCommerce:
	 * si WooCommerce no está activo al desinstalar, sus funciones no existen
	 * y no hay con qué cancelarlas (sus tablas no se tocan a mano). Se quedan
	 * en su cola, y cuando WooCommerce vuelva a correrla no harán nada: sin el
	 * plugin sus ganchos no tienen quien los atienda, y Action Scheduler las
	 * da por fallidas sin llamar a nadie (`ActionScheduler_Action::execute()`);
	 * con él, send() no manda nada sin teléfonos, que ya se han borrado, ni de
	 * un aviso de hace más de un día, y check_receipts() no tiene nada que
	 * pedir.
	 *
	 * En una red de sitios se borra en todos los sitios en los que nadie más
	 * los usa. Las tareas, las del sitio desde el que se desinstala: Action
	 * Scheduler trabaja con las tablas del sitio en el que arrancó.
	 *
	 * @param string   $uninstalling El plugin que se desinstala (`WP_UNINSTALL_PLUGIN`: carpeta/archivo.php).
	 * @param string[] $sharing      Quién más usa estos teléfonos: nombres de archivo principal, o plugins enteros (carpeta/archivo.php).
	 * @return void
	 */
	public static function uninstall( $uninstalling, array $sharing = array() ) {
		if ( ! is_multisite() ) {
			if ( ! self::still_used( $uninstalling, $sharing ) ) {
				self::cancel_tasks();
				self::forget_everything();
			}

			return;
		}

		if ( ! self::still_used( $uninstalling, $sharing ) ) {
			self::cancel_tasks();
		}

		foreach ( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) {
			switch_to_blog( (int) $site_id );

			if ( ! self::still_used( $uninstalling, $sharing ) ) {
				self::forget_everything();
			}

			restore_current_blog();
		}
	}

	/**
	 * Si en el sitio actual sigue activo otro plugin que usa estos teléfonos.
	 *
	 * Es la misma pregunta para todo lo que las dos ediciones del plugin
	 * guardan en el mismo sitio: también la hace APSW_App_Uploads, por las
	 * fotos pendientes de la app.
	 *
	 * @param string   $uninstalling El plugin que se desinstala.
	 * @param string[] $sharing      Nombres de archivo principal, o plugins enteros.
	 * @return bool
	 */
	public static function still_used( $uninstalling, array $sharing ) {
		$active = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}

		foreach ( $active as $plugin ) {
			if ( ! is_string( $plugin ) || $plugin === $uninstalling ) {
				continue;
			}

			if ( in_array( $plugin, $sharing, true ) || in_array( basename( $plugin ), $sharing, true ) || self::carries_notifications( $plugin ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Si un plugin trae los avisos: si en su carpeta está este mismo archivo,
	 * que las dos ediciones llevan en la misma ruta.
	 *
	 * Así se reconoce a quien usa los teléfonos sin saber cómo se llama ni
	 * tenerlo cargado: mirando sus archivos. Al desinstalar un plugin,
	 * WordPress corre su `uninstall.php` antes de borrar nada.
	 *
	 * @param string $plugin Un plugin, como está en la lista de activos: carpeta/archivo.php.
	 * @return bool
	 */
	private static function carries_notifications( $plugin ) {
		if ( ! defined( 'WP_PLUGIN_DIR' ) || false === strpos( $plugin, '/' ) ) {
			return false;
		}

		return is_file( WP_PLUGIN_DIR . '/' . dirname( $plugin ) . '/includes/app/' . basename( __FILE__ ) );
	}

	/**
	 * Borra los teléfonos de todos los usuarios, la lista de la tienda y lo que
	 * esperaba su recibo, en el sitio actual.
	 *
	 * @return void
	 */
	private static function forget_everything() {
		delete_metadata( 'user', 0, self::meta_key(), '', true );
		delete_option( self::USERS_OPTION );
		delete_option( self::TICKETS_OPTION );
	}

	/**
	 * Cancela las tareas encoladas, si Action Scheduler está cargado.
	 *
	 * @return void
	 */
	private static function cancel_tasks() {
		if ( function_exists( 'as_unschedule_all_actions' ) && did_action( 'action_scheduler_init' ) ) {
			// Sin gancho ni argumentos: todas las del grupo, que son las dos tareas.
			as_unschedule_all_actions( '', array(), self::GROUP );
		}
	}
}
