<?php
/**
 * Las fotos que la app móvil sube para un producto nuevo.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Guarda en la biblioteca de medios de la tienda las fotos que el comerciante
 * elige en el formulario de «Nuevo producto» de la app, y borra las que no
 * llegan a ser de ningún producto.
 *
 * Cada foto se sube en cuanto se elige, antes de que el producto exista: por
 * eso queda **pendiente**, con una marca en el adjunto que dice de quién es y
 * cuándo se subió. Al crearse el producto, el formulario se queda con sus
 * fotos (claim()): la marca pasa a decir también de qué formulario son, y
 * solo uno lo consigue. Cuando el producto está hecho dejan de estar
 * pendientes y quedan adjuntas a él (attach()). Las que se quedan en un
 * formulario que nadie guardó las borra, pasado un día, una tarea programada
 * (clean()).
 *
 * Qué se acepta, mirando el archivo y no su nombre ni lo que diga quien lo
 * envía:
 *
 * - JPEG, PNG o WebP, que es lo que el archivo tiene que ser por dentro: lo
 *   dice su cabecera (`wp_get_image_mime()`), tiene unas medidas que PHP sabe
 *   leer (`wp_getimagesize()`) y, si el servidor tiene con qué abrir
 *   imágenes, se abre como imagen (`wp_get_image_editor()`). Un SVG, un GIF,
 *   un PDF o un programa con nombre de foto, o con los primeros bytes de una,
 *   no pasan.
 * - Los tipos que además deje subir la tienda: si un plugin ha quitado alguno
 *   de la lista de WordPress (`upload_mimes`), aquí tampoco entra.
 * - 10 MB como mucho, o lo que deje subir el servidor si es menos
 *   (`wp_max_upload_size()`): se comprueba antes de mover el archivo, con el
 *   tamaño que PHP dice que recibió, y otra vez después, con el que tiene.
 * - 25 megapíxeles como mucho (MAX_PIXELS), y menos si la memoria que PHP
 *   tiene para abrir imágenes no da para tanto (fits()): se mira en la
 *   cabecera, antes de abrir la imagen. Una foto de pocos bytes puede tener
 *   unas medidas enormes, y abrirla acabaría con PHP.
 *
 * **El archivo temporal de PHP no se lee**: solo se mueve. En un servidor con
 * `open_basedir`, la carpeta temporal de PHP puede quedar fuera de lo que PHP
 * deja leer, y ahí leerlo falla aunque moverlo no (`move_uploaded_file()` no
 * mira `open_basedir` en el origen). Así que el orden es:
 *
 * 1. Con lo que PHP dice de la subida —su error y su tamaño—, lo que no puede
 *    valer se rechaza sin tocar nada.
 * 2. WordPress lo saca de la carpeta temporal (`wp_handle_upload()`, que
 *    comprueba que el archivo llegó de verdad en esta petición con
 *    `is_uploaded_file()` y pasa por `wp_handle_upload_prefilter`), sin mirar
 *    su tipo —tendría que leerlo allí— y con un nombre generado aquí, de
 *    imagen: en la carpeta de subidas no entra nunca un nombre que venga de
 *    fuera, ni una extensión que el servidor pueda ejecutar.
 * 3. Ya donde PHP puede leerlo, se mira por dentro (inspect()). Lo que no
 *    vale se borra en el momento: no queda nada.
 * 4. WordPress lo deja con su nombre definitivo, generado también aquí, con
 *    la extensión del tipo que el archivo es de verdad
 *    (`wp_handle_sideload()`): ahí vuelve a comparar el contenido con la
 *    extensión (`wp_check_filetype_and_ext()`), con solo estos tipos, y pasa
 *    por los filtros de los demás plugins con el tipo ya sabido.
 *
 * Después se inserta el adjunto, a nombre de quien lo sube, y se generan sus
 * tamaños y sus metadatos (`wp_generate_attachment_metadata()`), con lo que
 * WordPress haga con los datos EXIF de la foto: lo mismo que hace la ruta de
 * medios de WordPress (`WP_REST_Attachments_Controller::insert_attachment()`).
 * Si generar los tamaños falla, o PHP se muere ahí, el adjunto se borra con
 * sus archivos (discard()): no queda una foto a medias.
 *
 * Estas fotos no tienen nada que ver con las que se adjuntan en el Asistente
 * del otro plugin de Mosley Digital, que llevan su propia marca y su propia
 * limpieza: ni una foto de allí vale aquí, ni la limpieza de un lado mira las
 * del otro. Esta clase no nombra nada del Asistente.
 *
 * Los textos que devuelve van por gettext, con el inglés de base
 * (`mosley-digital-for-woocommerce`).
 *
 * No comprueba los permisos de la ruta: eso es cosa de APSW_App_Rest.
 */
class APSW_App_Uploads {

	/**
	 * La marca de una foto pendiente, en una meta del adjunto:
	 * «usuario:instante», y «usuario:instante:formulario» desde que un
	 * formulario se queda con ella para su producto (claim()). Sin ella, un
	 * adjunto no es de aquí: ni se puede poner en un producto nuevo ni lo toca
	 * la limpieza.
	 */
	const PENDING_META = '_apsw_app_pending_upload';

	/** El tamaño más grande que se acepta, en bytes: 10 MB. */
	const MAX_BYTES = 10485760;

	/**
	 * Los píxeles que una foto puede tener como mucho, ancho por alto: 25
	 * millones.
	 *
	 * La app manda las fotos reducidas a 2048 px de lado mayor: 4,2 millones
	 * como mucho. Caben seis veces, y también una foto de 24 megapíxeles tal
	 * como sale de una cámara (6000 × 4000) o de un teléfono (5712 × 4284).
	 * No una de 48 (8000 × 6000): GD la abre con 4 bytes por píxel, 192 MB, y
	 * con los 256 MB que WordPress le da a PHP para las imágenes no cabe junto
	 * a lo demás. Una de 25 millones son 100 MB abierta, más la copia reducida
	 * que WordPress saca de ella: cabe.
	 */
	const MAX_PIXELS = 25000000;

	/**
	 * El lado a partir del cual WordPress guarda una copia reducida de una
	 * imagen y trabaja con ella (`big_image_size_threshold`, image.php): 2560 px.
	 */
	const BIG_SIDE = 2560;

	/** Memoria que se deja libre al calcular si una foto cabe: 16 MB. */
	const MEMORY_MARGIN = 16777216;

	/**
	 * Los tipos que se aceptan, como los escribe WordPress: extensiones => tipo.
	 */
	const MIMES = array(
		'jpg|jpeg' => 'image/jpeg',
		'png'      => 'image/png',
		'webp'     => 'image/webp',
	);

	/** La extensión con la que se guarda cada tipo. */
	const EXTENSIONS = array(
		'image/jpeg' => 'jpg',
		'image/png'  => 'png',
		'image/webp' => 'webp',
	);

	/** La tarea que borra las fotos pendientes que nadie usó: cada día, y otra vez enseguida mientras quede trabajo. */
	const CLEANUP_HOOK = 'apsw_app_uploads_cleanup';

	/** Segundos que una foto puede estar pendiente antes de borrarse: un día. */
	const CLEANUP_AGE = 86400;

	/** Fotos pendientes que mira, como mucho, cada pasada de la limpieza. */
	const CLEANUP_BATCH = 50;

	/** Segundos que una pasada puede dedicar a borrar: las que no le dé tiempo quedan para la siguiente. */
	const CLEANUP_SECONDS = 20;

	/** Segundos que tarda en volver a pasar la limpieza cuando le queda trabajo. */
	const CLEANUP_AGAIN = 60;

	/** Posts que lee de una vez al buscar en los contenidos. */
	const CONTENT_PAGE = 100;

	/**
	 * La foto que se está guardando: array( id, archivos ), con el id en 0
	 * mientras su adjunto no existe. Si la petición se acaba sin terminarla,
	 * lo que queda de ella se borra.
	 *
	 * @var array|null
	 */
	private static $unfinished = null;

	/**
	 * Si lo que borra una foto a medias ya está enganchado al cierre.
	 *
	 * @var bool
	 */
	private static $watching = false;

	/**
	 * Un poco de memoria reservada mientras se guarda una foto: si PHP se
	 * queda sin ella, se suelta para poder borrar lo que quedó.
	 *
	 * @var string|null
	 */
	private static $reserve = null;

	/**
	 * Guarda una foto subida y la deja pendiente.
	 *
	 * @param mixed  $file           El archivo, como PHP lo deja en `$_FILES`: array( name, type, tmp_name, error, size ). Otra cosa es que no llegó ninguno.
	 * @param mixed  $content_length El tamaño de la petición entera, de su cabecera `Content-Length`.
	 * @param int    $user_id        Quien la sube.
	 * @return array|WP_Error array( id, thumb ), o invalid_image, image_too_large (400) / upload_failed (500).
	 */
	public static function upload( $file, $content_length, $user_id ) {
		$limit = self::max_bytes();

		// En una red de sitios, el sitio ha agotado el espacio que tiene para
		// sus archivos.
		if ( $limit < 1 ) {
			return new WP_Error( 'upload_failed', __( 'This store has no space left for more photos.', 'mosley-digital-for-woocommerce' ), array( 'status' => 500 ) );
		}

		if ( ! is_array( $file ) || ! isset( $file['tmp_name'] ) || ! is_string( $file['tmp_name'] ) ) {
			// Una petición más grande que el `post_max_size` de PHP llega sin
			// archivos y sin campos: PHP la descarta entera antes de que
			// WordPress la vea. Lo que falló ahí es el tamaño, no que no se
			// adjuntara nada.
			if ( is_numeric( $content_length ) && (int) $content_length > $limit ) {
				return self::too_large( $limit );
			}

			return self::invalid_image( __( 'Attach a photo to upload it.', 'mosley-digital-for-woocommerce' ) );
		}

		$error = isset( $file['error'] ) && is_numeric( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_OK;

		// PHP corta por tamaño (`upload_max_filesize`, o el `MAX_FILE_SIZE` de un
		// formulario) antes de guardar nada, y deja el archivo sin ruta.
		if ( UPLOAD_ERR_INI_SIZE === $error || UPLOAD_ERR_FORM_SIZE === $error ) {
			return self::too_large( $limit );
		}

		if ( UPLOAD_ERR_NO_FILE === $error ) {
			return self::invalid_image( __( 'Attach a photo to upload it.', 'mosley-digital-for-woocommerce' ) );
		}

		// Lo demás que PHP puede decir —llegó a medias, no hay carpeta temporal,
		// no se pudo escribir— no depende de la foto.
		if ( UPLOAD_ERR_OK !== $error || '' === $file['tmp_name'] ) {
			return self::failed();
		}

		// El tamaño que PHP dice que recibió: lo contó él al guardar el archivo.
		// El temporal no se mira hasta que WordPress lo haya movido: puede
		// estar donde PHP no deja leer (`open_basedir`).
		$size = isset( $file['size'] ) && is_numeric( $file['size'] ) ? (int) $file['size'] : 0;

		if ( $size > $limit ) {
			return self::too_large( $limit );
		}

		$allowed = self::allowed_mimes();

		// Un archivo vacío no es una foto, y una tienda que no deja subir ninguno
		// de los tres tipos no acepta ninguna.
		if ( $size < 1 || ! $allowed ) {
			return self::not_a_photo();
		}

		// wp_handle_upload() y wp_handle_sideload() están en file.php, y lo que
		// lee y genera los metadatos de una imagen, en image.php, que cuenta con
		// media.php: fuera del wp-admin no están cargados. Son los tres que
		// carga la ruta de medios de WordPress.
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// 1. WordPress lo saca de la carpeta temporal de PHP. El nombre se
		// genera: el que traía no se usa para nada. `test_form` va en false
		// porque no es un formulario del wp-admin, y `test_type` también: mirar
		// el tipo es leer el archivo, y ahí todavía no se puede. WordPress
		// comprueba aquí que el archivo se subió en esta petición
		// (`is_uploaded_file()`).
		$arrived = array(
			'name'     => self::new_name( 'jpg' ),
			'type'     => '',
			'tmp_name' => $file['tmp_name'],
			'error'    => UPLOAD_ERR_OK,
			'size'     => $size,
		);

		$moved = wp_handle_upload(
			$arrived,
			array(
				'test_form' => false,
				'test_type' => false,
			)
		);

		// Lo que falle aquí es del servidor (la carpeta de subidas, el disco) o
		// de otro plugin que la rechazó. Su mensaje puede venir en otro idioma y
		// nombrar rutas del servidor: a la app le llega siempre el de aquí.
		if ( ! is_array( $moved ) || isset( $moved['error'] ) || empty( $moved['file'] ) ) {
			return self::failed();
		}

		// Desde aquí hay un archivo en la carpeta de subidas, y hasta que la
		// foto esté hecha del todo se vigila (watch()): si algo falla se borra
		// aquí, y si PHP se muere —sin memoria, sin tiempo, o porque otro plugin
		// corta la petición—, al cerrarla. No queda un archivo suelto ni un
		// adjunto a medias que la app no llegó a conocer.
		self::watch( 0, array( (string) $moved['file'] ) );

		try {
			$saved = self::store( (string) $moved['file'], $limit, $allowed, (int) $user_id );
		} catch ( Throwable $error ) {
			$saved = self::failed();
		}

		if ( is_wp_error( $saved ) ) {
			self::discard_unfinished();
		} else {
			self::$unfinished = null;
			self::$reserve    = null;
		}

		return $saved;
	}

	/**
	 * Lo que se hace con una foto que WordPress ya sacó de la carpeta temporal
	 * de PHP: mirarla, dejarla con su nombre definitivo, insertar su adjunto y
	 * generar sus tamaños.
	 *
	 * Lo que deje a medias —un error que devuelve, o una excepción— lo borra
	 * quien la llama, que sabe por watch() hasta dónde llegó.
	 *
	 * @param string $path    El archivo, con su nombre provisional.
	 * @param int    $limit   El tamaño más grande que se acepta, en bytes.
	 * @param array  $allowed Los tipos que se aceptan: extensiones => tipo.
	 * @param int    $user_id Quien la sube.
	 * @return array|WP_Error array( id, thumb ), o invalid_image, image_too_large (400) / upload_failed (500).
	 */
	private static function store( $path, $limit, array $allowed, $user_id ) {
		// 2. Ya se puede leer: qué es por dentro, cuánto ocupa y cuánto mide.
		$photo = self::inspect( $path, $limit, $allowed );

		if ( is_wp_error( $photo ) ) {
			return $photo;
		}

		// 3. WordPress la deja con su nombre definitivo, con la extensión del
		// tipo que es de verdad. Ahora sí compara el contenido con la extensión
		// (`test_type`), con solo estos tipos (`mimes`).
		$named = array(
			'name'     => self::new_name( self::EXTENSIONS[ $photo['type'] ] ),
			'type'     => $photo['type'],
			'tmp_name' => $path,
			'error'    => UPLOAD_ERR_OK,
			'size'     => $photo['size'],
		);

		// El archivo que va a salir de aquí también se vigila, desde antes de
		// que exista: WordPress lo deja en la misma carpeta.
		self::watch( 0, array( $path, dirname( $path ) . '/' . $named['name'] ) );

		$kept = wp_handle_sideload(
			$named,
			array(
				'test_form' => false,
				'test_type' => true,
				'mimes'     => $allowed,
			)
		);

		if ( ! is_array( $kept ) || isset( $kept['error'] ) || empty( $kept['file'] ) || empty( $kept['url'] ) ) {
			return self::failed();
		}

		$stored = (string) $kept['file'];

		// WordPress borra el primer archivo al copiarlo.
		self::remove_file( $path );
		self::watch( 0, array( $stored ) );

		$title   = pathinfo( $stored, PATHINFO_FILENAME );
		$caption = '';
		$alt     = '';

		// Lo que WordPress saca de los datos EXIF e IPTC de cualquier foto que
		// se sube: su título, su leyenda y su texto alternativo, si los trae.
		$exif = $photo['exif'];

		if ( isset( $exif['title'] ) && '' !== trim( (string) $exif['title'] ) && ! is_numeric( sanitize_title( $exif['title'] ) ) ) {
			$title = (string) $exif['title'];
		}

		if ( isset( $exif['caption'] ) && '' !== trim( (string) $exif['caption'] ) ) {
			$caption = (string) $exif['caption'];
		}

		if ( isset( $exif['alt'] ) && '' !== trim( (string) $exif['alt'] ) ) {
			$alt = (string) $exif['alt'];
		}

		// La marca va en `meta_input`: wp_insert_post() la escribe al insertar
		// el adjunto, antes de generar sus tamaños. Pase lo que pase después, el
		// adjunto la lleva y la limpieza lo encuentra.
		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => isset( $kept['type'] ) && '' !== (string) $kept['type'] ? (string) $kept['type'] : $photo['type'],
				'guid'           => (string) $kept['url'],
				'post_parent'    => 0,
				'post_title'     => $title,
				'post_content'   => '',
				'post_excerpt'   => $caption,
				'post_author'    => $user_id,
				'meta_input'     => array(
					self::PENDING_META => $user_id . ':' . time(),
				),
			),
			$stored,
			0,
			true
		);

		if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
			return self::failed();
		}

		$attachment_id = (int) $attachment_id;

		self::watch( $attachment_id, array( $stored ) );

		// Hay algo que limpiar: la tarea tiene que estar programada.
		self::schedule_cleanup();

		if ( '' !== $alt ) {
			update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
		}

		// Generar los tamaños es abrir la imagen y sacar copias de ella: lo
		// lento, y donde otro plugin puede fallar.
		wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $stored ) );

		$thumb = wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
		$thumb = is_string( $thumb ) && '' !== $thumb ? $thumb : wp_get_attachment_url( $attachment_id );

		return array(
			'id'    => $attachment_id,
			'thumb' => is_string( $thumb ) && '' !== $thumb ? $thumb : null,
		);
	}

	/**
	 * Borra la foto que se estaba guardando, si no se terminó: la llama
	 * upload() cuando algo falla, y WordPress al cerrar la petición
	 * (`shutdown`), que es lo único que corre cuando PHP se muere.
	 *
	 * @return void
	 */
	public static function discard_unfinished() {
		if ( null === self::$unfinished ) {
			return;
		}

		list( $attachment_id, $files ) = self::$unfinished;

		self::$unfinished = null;
		self::$reserve    = null;

		self::discard( $attachment_id, $files );
	}

	/**
	 * Si un adjunto es una foto pendiente de un usuario que un formulario
	 * puede poner en su producto: la subió él por upload(), todavía no es de
	 * ningún producto y no se la ha quedado otro formulario.
	 *
	 * @param int    $attachment_id Id del adjunto.
	 * @param int    $user_id       Id del usuario.
	 * @param string $form          Identificador del formulario que la quiere.
	 * @return bool
	 */
	public static function is_pending_of( $attachment_id, $user_id, $form = '' ) {
		$attachment_id = (int) $attachment_id;
		$mark          = $attachment_id > 0 ? self::mark( $attachment_id ) : null;

		if ( null === $mark || $mark['user'] !== (int) $user_id || $mark['user'] < 1 ) {
			return false;
		}

		if ( null !== $mark['form'] && $mark['form'] !== (string) $form ) {
			return false;
		}

		return 'attachment' === get_post_type( $attachment_id ) && wp_attachment_is_image( $attachment_id );
	}

	/**
	 * Un formulario se queda con sus fotos, antes de crear su producto.
	 *
	 * Dos formularios distintos pueden llegar a la vez con la misma foto, y
	 * los dos la verían libre. Así que quedársela es **cambiar su marca de
	 * «libre» a «de este formulario» en una sola escritura que solo vale si la
	 * marca sigue siendo la que se leyó** (swap()): de todas las peticiones
	 * que lo intentan a la vez, la base de datos se lo concede a una. La que
	 * pierde una foto suelta las que ya tenía y no crea nada.
	 *
	 * La marca no se borra: la foto sigue pendiente —la limpieza la sigue
	 * viendo— hasta que el producto está hecho (attach()), y lleva el instante
	 * en que se la quedó el formulario, que es desde cuando cuenta su día. Si
	 * la petición se muere a medias, el mismo formulario, al repetirse, la
	 * encuentra suya y sigue.
	 *
	 * @param int[]  $attachment_ids Ids de los adjuntos.
	 * @param int    $user_id        Id del usuario.
	 * @param string $form           Identificador del formulario.
	 * @return bool false si alguna ya no está libre: no se queda con ninguna.
	 */
	public static function claim( array $attachment_ids, $user_id, $form ) {
		$user_id = (int) $user_id;
		$form    = (string) $form;
		$won     = array();

		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			$mark          = self::mark( $attachment_id );

			// Ya era suya: se la quedó un intento anterior que no terminó.
			if ( null !== $mark && $mark['user'] === $user_id && $mark['form'] === $form ) {
				continue;
			}

			if ( null === $mark || $mark['user'] !== $user_id || null !== $mark['form'] || ! self::swap( $attachment_id, $mark['value'], $user_id . ':' . time() . ':' . $form ) ) {
				self::release( $won, $user_id, $form );

				return false;
			}

			$won[] = $attachment_id;
		}

		return true;
	}

	/**
	 * Suelta las fotos con las que se quedó un formulario cuyo producto no se
	 * pudo crear: vuelven a estar libres, para ese formulario o para otro.
	 *
	 * @param int[]  $attachment_ids Ids de los adjuntos.
	 * @param int    $user_id        Id del usuario.
	 * @param string $form           Identificador del formulario.
	 * @return void
	 */
	public static function release( array $attachment_ids, $user_id, $form ) {
		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			$mark          = self::mark( $attachment_id );

			if ( null !== $mark && $mark['user'] === (int) $user_id && $mark['form'] === (string) $form ) {
				self::swap( $attachment_id, $mark['value'], $mark['user'] . ':' . $mark['time'] );
			}
		}
	}

	/**
	 * De unas fotos, las que un formulario tiene para su producto y todavía
	 * no dejó adjuntas: las de una petición que se murió con el producto ya
	 * hecho.
	 *
	 * @param int[]  $attachment_ids Ids de los adjuntos.
	 * @param int    $user_id        Id del usuario.
	 * @param string $form           Identificador del formulario.
	 * @return int[]
	 */
	public static function claimed( array $attachment_ids, $user_id, $form ) {
		$claimed = array();

		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;
			$mark          = $attachment_id > 0 ? self::mark( $attachment_id ) : null;

			if ( null !== $mark && $mark['user'] === (int) $user_id && $mark['form'] === (string) $form ) {
				$claimed[] = $attachment_id;
			}
		}

		return $claimed;
	}

	/**
	 * Las fotos de un producto recién creado dejan de estar pendientes y
	 * quedan adjuntas a él, como las que se suben en la pantalla de un
	 * producto del wp-admin.
	 *
	 * @param int[] $attachment_ids Ids de los adjuntos.
	 * @param int   $product_id     Id del producto.
	 * @return void
	 */
	public static function attach( array $attachment_ids, $product_id ) {
		foreach ( $attachment_ids as $attachment_id ) {
			$attachment_id = (int) $attachment_id;

			// Primero la marca: sin ella la limpieza ya no la mira, pase lo que
			// pase con lo demás.
			delete_post_meta( $attachment_id, self::PENDING_META );

			wp_update_post(
				array(
					'ID'          => $attachment_id,
					'post_parent' => (int) $product_id,
				)
			);
		}
	}

	/**
	 * La limpieza: borra las fotos que llevan más de un día pendientes y que
	 * nada usa.
	 *
	 * Mira, como mucho, CLEANUP_BATCH por pasada, las más antiguas primero. De
	 * cada una:
	 *
	 * - Si lleva pendiente menos de un día, se deja: su formulario puede
	 *   seguir abierto.
	 * - Si algo la usa (used()) —alguien la puso en un producto desde el
	 *   wp-admin, o en una entrada—, ya no es una foto pendiente: se le quita
	 *   la marca y no se borra, ni ahora ni nunca.
	 * - Si no, se borra, con sus archivos. Antes se le quita la marca, y solo
	 *   si sigue siendo la que se leyó al empezar la pasada
	 *   (`delete_post_meta()` con su valor): si entre tanto un formulario se
	 *   quedó con la foto (claim()), la marca ya es otra, no se quita y la
	 *   foto no se borra.
	 *
	 * **Lo que cuesta no crece con las fotos.** Saber si algo usa una foto es
	 * buscar en toda la tienda, y eso se hace una vez por pasada para todas
	 * las del lote (used()), no una vez por foto. Borrar sí va de una en una,
	 * y tiene un tiempo (CLEANUP_SECONDS): las que no dé tiempo a borrar
	 * quedan para la pasada siguiente.
	 *
	 * **Y cuando queda trabajo, la siguiente pasada no espera un día**: si el
	 * lote estaba lleno o se acabó el tiempo, y esta pasada sirvió de algo, se
	 * programa otra para dentro de un minuto (CLEANUP_AGAIN). Quinientas fotos
	 * pendientes se van en diez pasadas seguidas, no en diez días.
	 *
	 * Ninguna se queda pendiente para siempre, así que una pasada no se llena
	 * con las mismas de la anterior. Si una consulta falla, la pasada se corta
	 * sin borrar nada ni quitar ninguna marca: ante la duda, se conserva.
	 *
	 * @param float|int|null $seconds Tiempo para borrar; null, CLEANUP_SECONDS. Con 0 borra una y lo deja.
	 * @return int Cuántas se borraron.
	 */
	public static function clean( $seconds = null ) {
		$seconds = is_numeric( $seconds ) ? (float) $seconds : (float) self::CLEANUP_SECONDS;
		$started = microtime( true );
		$cutoff  = time() - self::CLEANUP_AGE;
		$deleted = 0;
		$settled = 0;
		$more    = false;

		// Los posts enteros y no solo sus ids: WordPress deja leídas, con dos
		// consultas para todo el lote, sus filas y sus metas, que es lo que se
		// mira de cada una.
		$pending = get_posts(
			array(
				'post_type'              => 'attachment',
				'post_status'            => 'inherit',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- The mark of a pending photo is the only way to find them; the query is limited to CLEANUP_BATCH rows.
				'meta_key'               => self::PENDING_META,
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'posts_per_page'         => self::CLEANUP_BATCH,
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
			)
		);
		$pending = is_array( $pending ) ? array_values( array_filter( $pending, 'is_object' ) ) : array();
		$old     = array();
		$marks   = array();

		// La marca de cada una se lee aquí, una vez: con ella se decide si ya
		// lleva un día, y con ella, y no con otra, se borra después.
		foreach ( $pending as $post ) {
			$value       = get_post_meta( (int) $post->ID, self::PENDING_META, true );
			$uploaded_at = self::uploaded_at( $post, $value );

			if ( null !== $uploaded_at && $uploaded_at <= $cutoff ) {
				$old[ (int) $post->ID ]   = $post;
				$marks[ (int) $post->ID ] = $value;
			}
		}

		if ( ! $old ) {
			return 0;
		}

		$used = self::used( $old );

		if ( null === $used ) {
			return 0;
		}

		foreach ( $old as $attachment_id => $post ) {
			// Siempre se avanza al menos una: una pasada que no hiciera nada se
			// repetiría igual.
			if ( $settled > 0 && microtime( true ) - $started >= $seconds ) {
				$more = true;

				break;
			}

			$in_use = isset( $used[ $attachment_id ] );

			if ( ! $in_use ) {
				/**
				 * Filters whether a pending photo of the app is in use by something the
				 * cleanup cannot see: a custom field that stores its id, a page builder.
				 * Returning true keeps the photo, for good.
				 *
				 * @since 1.0.0
				 *
				 * @param bool $in_use        false: nothing the cleanup looks at uses it.
				 * @param int  $attachment_id Attachment id.
				 */
				$in_use = (bool) apply_filters( 'apsw_app_pending_upload_in_use', false, $attachment_id );
			}

			if ( $in_use ) {
				delete_post_meta( $attachment_id, self::PENDING_META );

				++$settled;

				continue;
			}

			if ( ! delete_post_meta( $attachment_id, self::PENDING_META, $marks[ $attachment_id ] ) ) {
				continue;
			}

			++$settled;

			if ( wp_delete_attachment( $attachment_id, true ) ) {
				++$deleted;
			}
		}

		// El lote venía lleno, y hasta su última foto llevaba ya un día: detrás
		// puede haber más.
		if ( ! $more && count( $pending ) >= self::CLEANUP_BATCH ) {
			$last = end( $pending );
			$more = isset( $old[ (int) $last->ID ] );
		}

		if ( $more && $settled > 0 ) {
			wp_schedule_single_event( time() + self::CLEANUP_AGAIN, self::CLEANUP_HOOK );
		}

		return $deleted;
	}

	/**
	 * Programa la tarea de cada día, si no hay ninguna programada. (La pasada
	 * que sigue a una que dejó trabajo la programa clean().)
	 *
	 * Se llama al guardar una foto, que es cuando hay algo que limpiar, y al
	 * arrancar la API REST, para que vuelva a estar tras desactivar y activar
	 * el plugin. `wp_next_scheduled()` lee una opción que WordPress ya tiene
	 * cargada: no cuesta ninguna consulta.
	 *
	 * @return void
	 */
	public static function schedule_cleanup() {
		if ( false === wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK );
		}
	}

	/**
	 * Quita la tarea —la de cada día y, si la hay, la siguiente pasada—: al
	 * desactivar el plugin.
	 *
	 * @return void
	 */
	public static function unschedule_cleanup() {
		wp_clear_scheduled_hook( self::CLEANUP_HOOK );
	}

	/**
	 * Al desinstalar: quita la tarea y las marcas de las fotos pendientes. Las
	 * fotos no se borran: las de un producto son de la tienda, y las que
	 * estaban pendientes se quedan en la biblioteca de medios como cualquier
	 * otra imagen. Los productos tampoco se tocan: cada uno conserva la meta
	 * con el identificador del formulario del que salió
	 * (`APSW_App_Products::CLIENT_META`), como un pedido conserva la marca de
	 * que ya avisó.
	 *
	 * Salvo que otro plugin activo use estas mismas fotos —la otra edición, u
	 * otra copia de esta—: la misma pregunta, y la misma respuesta, que para
	 * los teléfonos de los avisos (APSW_App_Push::still_used()). La tarea es de
	 * WP-Cron, no de Action Scheduler: se puede quitar con WooCommerce
	 * desactivado.
	 *
	 * En una red de sitios, en todos los sitios en los que nadie más las usa.
	 *
	 * @param string   $uninstalling El plugin que se desinstala (`WP_UNINSTALL_PLUGIN`).
	 * @param string[] $sharing      Quién más usa estas fotos: nombres de archivo principal, o plugins enteros.
	 * @return void
	 */
	public static function uninstall( $uninstalling, array $sharing = array() ) {
		if ( ! is_multisite() ) {
			if ( ! APSW_App_Push::still_used( $uninstalling, $sharing ) ) {
				self::forget_everything();
			}

			return;
		}

		foreach ( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) {
			switch_to_blog( (int) $site_id );

			if ( ! APSW_App_Push::still_used( $uninstalling, $sharing ) ) {
				self::forget_everything();
			}

			restore_current_blog();
		}
	}

	/**
	 * Quita la tarea y las marcas, en el sitio actual.
	 *
	 * @return void
	 */
	private static function forget_everything() {
		wp_clear_scheduled_hook( self::CLEANUP_HOOK );
		delete_post_meta_by_key( self::PENDING_META );
	}

	/**
	 * El tamaño más grande que se acepta en este servidor: 10 MB, o lo que
	 * WordPress deje subir si es menos (`wp_max_upload_size()`: lo que PHP
	 * admite y, en una red de sitios, el tope por archivo de la red y el
	 * espacio que le queda al sitio).
	 *
	 * Un 0 de WordPress no es un límite: es lo que sale cuando PHP no tiene
	 * ninguno (`post_max_size = 0`). Salvo en una red de sitios en la que el
	 * sitio ya no tiene espacio: ahí sí es que no cabe nada.
	 *
	 * @return int 0 si no cabe nada.
	 */
	private static function max_bytes() {
		$server = function_exists( 'wp_max_upload_size' ) ? (int) wp_max_upload_size() : 0;

		if ( $server > 0 ) {
			return min( self::MAX_BYTES, $server );
		}

		return is_multisite() && function_exists( 'is_upload_space_available' ) && ! is_upload_space_available() ? 0 : self::MAX_BYTES;
	}

	/**
	 * De los tipos que se aceptan, los que la tienda deja subir
	 * (`get_allowed_mime_types()`, después del filtro `upload_mimes`).
	 *
	 * @return array extensiones => tipo.
	 */
	private static function allowed_mimes() {
		$site    = function_exists( 'get_allowed_mime_types' ) ? (array) get_allowed_mime_types() : array();
		$allowed = array();

		foreach ( self::MIMES as $extensions => $mime ) {
			if ( in_array( $mime, $site, true ) ) {
				$allowed[ $extensions ] = $mime;
			}
		}

		return $allowed;
	}

	/**
	 * Un nombre de archivo generado: «photo-», doce cifras hexadecimales al
	 * azar y la extensión. Nada de lo que mandó quien sube la foto entra en él.
	 *
	 * @param string $extension La extensión, sin punto.
	 * @return string
	 */
	private static function new_name( $extension ) {
		return 'photo-' . bin2hex( random_bytes( 6 ) ) . '.' . $extension;
	}

	/**
	 * Borra un archivo de la carpeta de subidas, si está.
	 *
	 * @param string $path Ruta del archivo.
	 * @return void
	 */
	private static function remove_file( $path ) {
		if ( is_string( $path ) && '' !== $path && file_exists( $path ) ) {
			wp_delete_file( $path );
		}
	}

	/**
	 * Lo que una foto es por dentro, una vez donde PHP puede leerla.
	 *
	 * - Su tamaño de verdad, que no puede pasar del límite.
	 * - Su tipo: `wp_get_image_mime()` lee su cabecera, y `wp_getimagesize()`
	 *   sus medidas. Lo que no tiene las dos cosas, o no dice lo mismo en las
	 *   dos, no es una imagen.
	 * - Sus medidas, que tienen que caber (fits()). Se leen de la cabecera: la
	 *   imagen todavía no se ha abierto.
	 * - Y, si el servidor tiene con qué abrir imágenes de ese tipo (GD o
	 *   Imagick), se abre: la cabecera y las medidas se conforman con el
	 *   principio del archivo, y un programa puede empezar como una foto. Lo
	 *   que no se deja abrir como imagen no lo es. Es lo que WordPress va a
	 *   hacer de todos modos, un momento después, para sacar sus tamaños.
	 *
	 * @param string $path    Ruta del archivo.
	 * @param int    $limit   El tamaño más grande que se acepta, en bytes.
	 * @param array  $allowed Los tipos que se aceptan: extensiones => tipo.
	 * @return array|WP_Error array( type, size, exif ), o invalid_image / image_too_large (400).
	 */
	private static function inspect( $path, $limit, array $allowed ) {
		clearstatcache( true, $path );

		$size = is_file( $path ) ? (int) filesize( $path ) : 0;

		if ( $size > $limit ) {
			return self::too_large( $limit );
		}

		$mime = $size > 0 ? wp_get_image_mime( $path ) : false;

		if ( ! is_string( $mime ) || ! isset( self::EXTENSIONS[ $mime ] ) || ! in_array( $mime, $allowed, true ) ) {
			return self::not_a_photo();
		}

		$measures = wp_getimagesize( $path );

		if ( ! is_array( $measures ) || empty( $measures[0] ) || empty( $measures[1] ) || (int) $measures[0] < 1 || (int) $measures[1] < 1 ) {
			return self::not_a_photo();
		}

		if ( isset( $measures['mime'] ) && is_string( $measures['mime'] ) && '' !== $measures['mime'] && $measures['mime'] !== $mime ) {
			return self::not_a_photo();
		}

		// Lo que la foto dice de sí misma (EXIF, IPTC): de ahí salen su título,
		// su leyenda y su texto alternativo, y si WordPress la va a girar, que
		// es abrirla dos veces.
		$exif  = wp_read_image_metadata( $path );
		$exif  = is_array( $exif ) ? $exif : array();
		$turns = 'image/jpeg' === $mime && isset( $exif['orientation'] ) && is_numeric( $exif['orientation'] ) && (int) $exif['orientation'] > 1;

		if ( ! self::fits( (int) $measures[0], (int) $measures[1], $size, $turns ) ) {
			return self::too_many_pixels( (int) $measures[0], (int) $measures[1] );
		}

		// El tipo se dice aquí: el archivo lleva todavía un nombre provisional.
		if ( function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => $mime ) ) ) {
			$opened = wp_get_image_editor( $path, array( 'mime_type' => $mime ) );

			if ( is_wp_error( $opened ) ) {
				return self::not_a_photo();
			}

			unset( $opened );
		}

		return array(
			'type' => $mime,
			'size' => $size,
			'exif' => $exif,
		);
	}

	/**
	 * Si una imagen de esas medidas se puede abrir en este servidor sin que
	 * PHP se quede sin memoria.
	 *
	 * Lo primero, el tope: MAX_PIXELS. Después, la memoria. WordPress no
	 * calcula si una imagen cabe: antes de abrirla sube el límite de PHP hasta
	 * el que tenga para imágenes (`wp_raise_memory_limit( 'image' )`: 256 MB
	 * salvo que la tienda diga otra cosa con `WP_MAX_MEMORY_LIMIT` o con el
	 * filtro `image_memory_limit`, y solo si el servidor deja cambiarlo), y la
	 * abre. Aquí se sube igual y se cuenta lo que va a hacer falta, con lo que
	 * GD gasta, que es quien usa la memoria de PHP (Imagick tiene la suya):
	 *
	 * - La imagen abierta: 4 bytes por píxel
	 *   (`wp_imagecreatetruecolor()` → `imagecreatetruecolor()`).
	 * - La copia que WordPress tiene a la vez (wp_create_image_subsizes() y
	 *   _wp_make_subsizes(), image.php): la reducida a 2560 px de una imagen
	 *   grande, que sigue abierta mientras se sacan los tamaños del original;
	 *   o, si la foto dice que está girada, otra entera, la ya girada.
	 * - Lo que se añade mientras tanto, de una en una: el archivo leído
	 *   entero, la copia al girarla —otra entera— o el tamaño más grande que
	 *   se saca de ella.
	 * - Y un margen (MEMORY_MARGIN) sobre lo que la petición ya gasta.
	 *
	 * @param int  $width  Ancho, en píxeles.
	 * @param int  $height Alto, en píxeles.
	 * @param int  $bytes  Lo que ocupa el archivo.
	 * @param bool $turns  Si WordPress la va a girar.
	 * @return bool
	 */
	private static function fits( $width, $height, $bytes, $turns ) {
		$pixels = $width * $height;

		if ( $pixels > self::MAX_PIXELS ) {
			return false;
		}

		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'image' );
		}

		$limit = function_exists( 'wp_convert_hr_to_bytes' ) ? (int) wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) ) : -1;

		// Sin límite (-1).
		if ( $limit < 1 ) {
			return true;
		}

		$open  = 4 * $pixels;
		$long  = max( $width, $height );
		$small = $long > self::BIG_SIDE ? (int) ceil( $open * ( self::BIG_SIDE / $long ) * ( self::BIG_SIDE / $long ) ) : 0;
		$held  = $turns ? $open : $small;
		$extra = max( (int) $bytes, $turns ? $open : 0, min( $open, 4 * self::BIG_SIDE * self::BIG_SIDE ) );

		return memory_get_usage( true ) + $open + $held + $extra + self::MEMORY_MARGIN <= $limit;
	}

	/**
	 * Vigila la foto que se está guardando: si la petición se acaba sin
	 * haberla terminado, discard_unfinished() borra lo que haya de ella.
	 *
	 * Va en el gancho `shutdown` de WordPress, que corre también cuando PHP se
	 * muere por un error fatal o cuando otro plugin corta la petición con
	 * `exit`, y antes de que WordPress cierre su caché de objetos.
	 *
	 * upload() la llama cada vez que la foto avanza: con el archivo que
	 * WordPress sacó de la carpeta temporal, con el que ya tiene su nombre
	 * definitivo y, cuando existe, con su adjunto.
	 *
	 * @param int      $attachment_id Id del adjunto; 0 si todavía no existe.
	 * @param string[] $files         Rutas de sus archivos: el que hay y, si WordPress va a dejar otro, el que va a haber.
	 * @return void
	 */
	private static function watch( $attachment_id, array $files ) {
		self::$unfinished = array( (int) $attachment_id, $files );

		if ( null === self::$reserve ) {
			self::$reserve = str_repeat( ' ', 1048576 );
		}

		if ( ! self::$watching ) {
			self::$watching = true;

			add_action( 'shutdown', array( __CLASS__, 'discard_unfinished' ), 0 );
		}
	}

	/**
	 * Borra una foto que no llegó a estar hecha: el adjunto, si lo había, con
	 * los archivos que WordPress sabe que tiene (`wp_delete_attachment()`); su
	 * archivo; y los que WordPress estaba escribiendo cuando se cortó, que
	 * todavía no constaban en sus metadatos. Estos se buscan por el nombre que
	 * se generó aquí, que no se repite: `photo-1a2b3c4d5e6f-300x300.jpg`,
	 * `photo-1a2b3c4d5e6f-scaled.jpg`.
	 *
	 * La carpeta se lee entrada a entrada, sin cargarla entera: esto corre
	 * también cuando PHP se ha quedado sin memoria.
	 *
	 * @param int      $attachment_id Id del adjunto; 0 si no llegó a existir.
	 * @param string[] $files         Rutas de sus archivos.
	 * @return void
	 */
	private static function discard( $attachment_id, array $files ) {
		if ( $attachment_id > 0 ) {
			wp_delete_attachment( $attachment_id, true );
		}

		foreach ( $files as $file ) {
			self::remove_file( $file );

			$folder = dirname( $file );
			$name   = pathinfo( $file, PATHINFO_FILENAME );

			// Solo con un nombre de los de aquí: si otro plugin lo cambió, no se
			// busca nada por parecido.
			if ( 1 !== preg_match( '/\Aphoto-[0-9a-f]{12}\z/', $name ) || ! is_dir( $folder ) || ! is_readable( $folder ) ) {
				continue;
			}

			$handle = opendir( $folder );
			$left   = array();

			if ( false === $handle ) {
				continue;
			}

			do {
				$entry = readdir( $handle );

				if ( is_string( $entry ) && ( 0 === strpos( $entry, $name . '.' ) || 0 === strpos( $entry, $name . '-' ) ) ) {
					$left[] = $entry;
				}
			} while ( false !== $entry );

			closedir( $handle );

			foreach ( $left as $entry ) {
				self::remove_file( $folder . '/' . $entry );
			}
		}
	}

	/**
	 * Cambia la marca de una foto de un valor a otro, **solo si sigue siendo
	 * el primero**.
	 *
	 * `update_post_meta()` con el valor anterior es un solo
	 * `UPDATE … WHERE post_id = … AND meta_key = … AND meta_value = <anterior>`
	 * (`update_metadata()`, meta.php): si otra petición la cambió antes, no
	 * toca ninguna fila y devuelve false. De dos que lo intentan a la vez, la
	 * base de datos se lo concede a una.
	 *
	 * Si la marca ya no está —la foto se usó o se borró entre tanto—,
	 * `update_metadata()` no cambia nada: la **añade**, y devuelve el id de la
	 * meta nueva. Eso tampoco es haberla conseguido: la que añadió se quita.
	 *
	 * @param int    $attachment_id Id del adjunto.
	 * @param string $from          El valor que tiene que tener.
	 * @param string $to            El valor que se le pone.
	 * @return bool Si se cambió.
	 */
	private static function swap( $attachment_id, $from, $to ) {
		$done = update_post_meta( $attachment_id, self::PENDING_META, $to, $from );

		if ( true === $done ) {
			return true;
		}

		if ( is_int( $done ) && $done > 0 ) {
			delete_metadata_by_mid( 'post', $done );
		}

		return false;
	}

	/**
	 * La marca de una foto pendiente.
	 *
	 * @param int $attachment_id Id del adjunto.
	 * @return array|null array( user, time, form, value ): de quién es, desde cuándo, qué formulario se la quedó (null si ninguno) y la marca tal cual. null si no la lleva, o no es una marca.
	 */
	private static function mark( $attachment_id ) {
		return self::read_mark( get_post_meta( $attachment_id, self::PENDING_META, true ) );
	}

	/**
	 * Lo que dice una marca.
	 *
	 * @param mixed $value El valor de la meta.
	 * @return array|null array( user, time, form, value ); null si no es una marca.
	 */
	private static function read_mark( $value ) {
		if ( ! is_string( $value ) || 1 !== preg_match( '/\A(\d{1,18}):(\d{1,11})(?::([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}))?\z/', $value, $parts ) ) {
			return null;
		}

		return array(
			'user'  => (int) $parts[1],
			'time'  => (int) $parts[2],
			'form'  => isset( $parts[3] ) && '' !== $parts[3] ? $parts[3] : null,
			'value' => $value,
		);
	}

	/**
	 * Desde cuándo está pendiente una foto: lo que dice su marca. Si la marca
	 * no se entiende —alguien la tocó—, la fecha del adjunto.
	 *
	 * @param WP_Post|object $post  El adjunto.
	 * @param mixed          $value Su marca.
	 * @return int|null null si no es un adjunto.
	 */
	private static function uploaded_at( $post, $value ) {
		$mark = self::read_mark( $value );

		if ( null !== $mark ) {
			return $mark['time'];
		}

		$date = 'attachment' === $post->post_type ? strtotime( $post->post_date_gmt . ' UTC' ) : false;

		return false === $date ? null : (int) $date;
	}

	/**
	 * De un lote de fotos pendientes, las que algo usa, y por eso no se
	 * pueden borrar.
	 *
	 * Usa una foto: el post al que está adjunta; cualquier post —un producto,
	 * una variación, una entrada, una página— que la tenga de imagen
	 * destacada; un producto que la tenga en su galería; una categoría u otro
	 * término que la tenga de imagen; el sitio, de icono, de logo o de imagen
	 * de muestra de WooCommerce; y un contenido, un widget o un ajuste del
	 * tema que enlace su archivo. (Lo que diga un plugin con el filtro
	 * `apsw_app_pending_upload_in_use` lo mira clean().)
	 *
	 * **No la usa**, para la limpieza, lo que solo la nombra en otro sitio: un
	 * campo personalizado de otro plugin que guarde su id o su dirección, o un
	 * maquetador que guarde su contenido en metas. Para eso está el filtro.
	 *
	 * El borrado no tiene vuelta atrás: ante la duda, se conserva. Lo que no
	 * es un adjunto, o no tiene archivo, se da por usado. Y una consulta que
	 * falla devuelve lo mismo que una que no encuentra nada, que es justo lo
	 * que no se puede dar por bueno: tras cada una se mira si falló, y
	 * entonces no se contesta que no las usa nadie, sino que no se sabe.
	 *
	 * Las consultas van a la base de datos directamente, y no por WP_Query: la
	 * imagen destacada puede ser de un post de cualquier tipo y en cualquier
	 * estado, registrado o no, y una búsqueda de WP_Query deja fuera, para
	 * quien no ha iniciado sesión —esta tarea—, lo que está protegido con
	 * contraseña.
	 *
	 * **Son cinco para todo el lote**, no cinco por foto. La cara es la de los
	 * contenidos, que recorre la tabla de posts entera: se hace una vez, con
	 * un patrón por cada carpeta de la que haya fotos —`/2026/10/photo-`, lo
	 * que tienen en común todas las de un mes— y otro para los
	 * `[gallery ids="…"]`, y lo que encuentra se repasa aquí, foto por foto.
	 * Si encuentra muchos posts, los lee de CONTENT_PAGE en CONTENT_PAGE.
	 *
	 * @param array $photos Los adjuntos, por su id.
	 * @return array|null Los ids de las que algo usa, como claves. null si no se pudo saber.
	 */
	private static function used( array $photos ) {
		global $wpdb;

		$used  = array();
		$stems = array();

		$site = array( (int) get_option( 'site_icon' ), (int) get_theme_mod( 'custom_logo' ), (int) get_option( 'woocommerce_placeholder_image' ) );

		foreach ( $photos as $attachment_id => $post ) {
			$stem = 'attachment' === $post->post_type && 0 === (int) $post->post_parent ? self::stem( $attachment_id ) : '';

			if ( '' === $stem || in_array( $attachment_id, $site, true ) ) {
				$used[ $attachment_id ] = true;
			} else {
				$stems[ $attachment_id ] = $stem;
			}
		}

		if ( ! $stems ) {
			return $used;
		}

		$ids   = array_map( 'strval', array_keys( $stems ) );
		$marks = implode( ', ', array_fill( 0, count( $ids ), '%s' ) );

		// La imagen destacada de cualquier post.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Read-only check before deleting files for good: it must see posts of every type and status, which WP_Query does not; only the table name from $wpdb and a list of %s placeholders are interpolated.
		$featured = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value IN ( {$marks} )", $ids ) );

		if ( '' !== (string) $wpdb->last_error ) {
			return null;
		}

		foreach ( (array) $featured as $attachment_id ) {
			$used[ (int) $attachment_id ] = true;
		}

		// La galería de un producto son sus ids separados por comas: el LIKE
		// solo acerca (12 casa con «5,123,7»), y lo que decide es la lista.
		$likes = implode( ' OR ', array_fill( 0, count( $ids ), 'meta_value LIKE %s' ) );
		$near  = array();

		foreach ( $ids as $attachment_id ) {
			$near[] = '%' . $wpdb->esc_like( $attachment_id ) . '%';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Read-only check before deleting files for good; only the table name from $wpdb and a list of LIKE %s conditions are interpolated.
		$galleries = $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_product_image_gallery' AND ( {$likes} )", $near ) );

		if ( '' !== (string) $wpdb->last_error ) {
			return null;
		}

		foreach ( (array) $galleries as $gallery ) {
			foreach ( array_map( 'intval', explode( ',', str_replace( ' ', '', (string) $gallery ) ) ) as $attachment_id ) {
				if ( isset( $stems[ $attachment_id ] ) ) {
					$used[ $attachment_id ] = true;
				}
			}
		}

		// La imagen de una categoría de productos, o de cualquier otro término.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Read-only check before deleting files for good; only the table name from $wpdb and a list of %s placeholders are interpolated.
		$terms = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT meta_value FROM {$wpdb->termmeta} WHERE meta_key = 'thumbnail_id' AND meta_value IN ( {$marks} )", $ids ) );

		if ( '' !== (string) $wpdb->last_error ) {
			return null;
		}

		foreach ( (array) $terms as $attachment_id ) {
			$used[ (int) $attachment_id ] = true;
		}

		// Los contenidos. Lo que tienen en común las fotos de una carpeta: su
		// ruta hasta donde empieza lo que el nombre tiene de único.
		$folders = array();

		foreach ( $stems as $stem ) {
			$folders[ 1 === preg_match( '/\A(.*photo-)[0-9a-f]{12}(?:-[0-9]+)?\z/', $stem, $parts ) ? $parts[1] : $stem ] = true;
		}

		$where = array();
		$args  = array( 0 );

		foreach ( array_keys( $folders ) as $folder ) {
			$where[] = 'post_content LIKE %s OR post_excerpt LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( '/' . $folder ) . '%';
			$args[]  = '%' . $wpdb->esc_like( '/' . $folder ) . '%';
		}

		$where  = implode( ' OR ', $where );
		$args[] = '%' . $wpdb->esc_like( '[gallery' ) . '%' . $wpdb->esc_like( 'ids=' ) . '%';
		$args[] = self::CONTENT_PAGE;

		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Read-only check before deleting files for good: it must also see password-protected and private content, which a WP_Query search leaves out; only the table name from $wpdb and a list of LIKE %s conditions are interpolated.
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE ID > %d AND post_type NOT IN ( 'attachment', 'revision' ) AND ( {$where} OR post_content LIKE %s ) ORDER BY ID ASC LIMIT %d", $args ) );

			if ( '' !== (string) $wpdb->last_error ) {
				return null;
			}

			$rows = is_array( $rows ) ? $rows : array();

			foreach ( $rows as $row ) {
				$args[0] = (int) $row->ID;

				foreach ( $stems as $attachment_id => $stem ) {
					if ( ! isset( $used[ $attachment_id ] ) && ( self::links( $row->post_content, $stem ) || self::links( $row->post_excerpt, $stem ) || self::in_gallery( $row->post_content, $attachment_id ) ) ) {
						$used[ $attachment_id ] = true;
					}
				}
			}
		} while ( count( $rows ) >= self::CONTENT_PAGE );

		// Los widgets (`widget_block`, `widget_media_image`…) y los ajustes del
		// tema (`theme_mods_<tema>`: la cabecera, el fondo) viven en opciones:
		// son pocas, y se leen todas.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Read-only check before deleting files for good; there is no API to search option values; only the table name from $wpdb is interpolated.
		$options = $wpdb->get_col( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( 'widget_' ) . '%', $wpdb->esc_like( 'theme_mods_' ) . '%' ) );

		if ( '' !== (string) $wpdb->last_error ) {
			return null;
		}

		foreach ( (array) $options as $option ) {
			foreach ( $stems as $attachment_id => $stem ) {
				if ( ! isset( $used[ $attachment_id ] ) && self::links( $option, $stem ) ) {
					$used[ $attachment_id ] = true;
				}
			}
		}

		return $used;
	}

	/**
	 * La ruta del archivo de una foto, sin extensión y desde su carpeta del
	 * año (`2026/10/photo-1a2b3c4d5e6f`): casa con el original y con sus
	 * tamaños (`photo-1a2b3c4d5e6f-300x300.jpg`), sin lo que WordPress le
	 * añade al nombre cuando reduce, gira o edita la imagen (`-scaled`,
	 * `-rotated`, `-e1727000000000`).
	 *
	 * @param int $attachment_id Id del adjunto.
	 * @return string '' si no tiene archivo.
	 */
	private static function stem( $attachment_id ) {
		$file = str_replace( '\\', '/', (string) get_post_meta( $attachment_id, '_wp_attached_file', true ) );
		$path = implode( '/', array_slice( array_values( array_filter( explode( '/', $file ), 'strlen' ) ), -3 ) );
		$stem = (string) preg_replace( '/\.[A-Za-z0-9]+$/', '', $path );
		$stem = (string) preg_replace( '/-e[0-9]+$/', '', $stem );

		return (string) preg_replace( '/-(?:scaled|rotated)$/', '', $stem );
	}

	/**
	 * Si un texto enlaza el archivo de una foto. Es una búsqueda gruesa a
	 * propósito, sin mirar mayúsculas, como el LIKE de la base de datos: casar
	 * de más solo conserva una foto.
	 *
	 * @param mixed  $text El contenido de un post, o el valor de una opción.
	 * @param string $stem La ruta de la foto (stem()).
	 * @return bool
	 */
	private static function links( $text, $stem ) {
		return is_string( $text ) && '' !== $text && false !== stripos( $text, '/' . $stem );
	}

	/**
	 * Si un contenido nombra una foto en un `[gallery ids="…"]`: después de un
	 * `[gallery` hay un `ids=` y, después, las cifras de su id. Igual de
	 * grueso que lo demás: 12 casa con «5,123,7».
	 *
	 * @param mixed $content       El contenido de un post.
	 * @param int   $attachment_id Id del adjunto.
	 * @return bool
	 */
	private static function in_gallery( $content, $attachment_id ) {
		if ( ! is_string( $content ) ) {
			return false;
		}

		$gallery = stripos( $content, '[gallery' );
		$ids     = false === $gallery ? false : stripos( $content, 'ids=', $gallery + 8 );

		return false !== $ids && false !== strpos( $content, (string) $attachment_id, $ids + 4 );
	}

	/**
	 * El error de un archivo que no es una foto que se pueda guardar.
	 *
	 * @param string $message Mensaje listo para mostrar.
	 * @return WP_Error
	 */
	private static function invalid_image( $message ) {
		return new WP_Error( 'invalid_image', $message, array( 'status' => 400 ) );
	}

	/**
	 * El error de un archivo que no es un JPEG, un PNG o un WebP que la tienda
	 * deje subir.
	 *
	 * @return WP_Error
	 */
	private static function not_a_photo() {
		return self::invalid_image( __( 'That file is not a photo this store accepts. Use a JPEG, PNG or WebP image.', 'mosley-digital-for-woocommerce' ) );
	}

	/**
	 * El error de una foto que ocupa más de lo que se acepta.
	 *
	 * @param int $limit El tamaño más grande que se acepta, en bytes.
	 * @return WP_Error
	 */
	private static function too_large( $limit ) {
		return new WP_Error(
			'image_too_large',
			/* translators: %s: the largest file size the store accepts, for example "10 MB". */
			sprintf( __( 'This photo is too large. The largest this store accepts is %s.', 'mosley-digital-for-woocommerce' ), size_format( $limit ) ),
			array( 'status' => 400 )
		);
	}

	/**
	 * El error de una foto que mide más de lo que el servidor puede abrir.
	 *
	 * @param int $width  Ancho, en píxeles.
	 * @param int $height Alto, en píxeles.
	 * @return WP_Error
	 */
	private static function too_many_pixels( $width, $height ) {
		return new WP_Error(
			'image_too_large',
			/* translators: 1: width of the photo in pixels, 2: its height in pixels; both already formatted, for example "20,000". */
			sprintf( __( 'The dimensions of this photo are too large for this store: %1$s by %2$s pixels. Use a smaller one.', 'mosley-digital-for-woocommerce' ), number_format_i18n( $width ), number_format_i18n( $height ) ),
			array( 'status' => 400 )
		);
	}

	/**
	 * El error de una subida que falló por algo que no es la foto.
	 *
	 * @return WP_Error
	 */
	private static function failed() {
		return new WP_Error( 'upload_failed', __( 'The photo could not be saved in the store. Try again.', 'mosley-digital-for-woocommerce' ), array( 'status' => 500 ) );
	}
}
