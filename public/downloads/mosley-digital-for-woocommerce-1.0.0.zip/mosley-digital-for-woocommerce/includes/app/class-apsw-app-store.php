<?php
/**
 * Lo que la app móvil lee de la tienda en bloque: las ventas de un rango de
 * fechas y los productos con poco stock.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Las dos consultas de fondo de Inicio y de Productos, con las funciones de
 * WooCommerce (`wc_get_orders()` y `wc_get_products()`): la suma de los
 * pedidos pagados de un rango y la lista de productos agotados o por debajo
 * del umbral de pocas existencias de la tienda.
 *
 * No da forma a nada para pintar ni devuelve textos: eso es cosa de
 * APSW_App_Home y de APSW_App_Products.
 */
class APSW_App_Store {

	/**
	 * Pedidos que se traen por consulta al sumar las ventas.
	 *
	 * @var int
	 */
	const ORDERS_PAGE_SIZE = 200;

	/**
	 * Páginas de pedidos que se recorren como mucho.
	 *
	 * Es la red de seguridad del bucle —un almacén de pedidos que ignorara
	 * `offset` devolvería siempre una página llena— y el techo de memoria del
	 * recorrido: 200 páginas son 40.000 pedidos, unos 79 MB medidos en una
	 * tienda con un 10 % de reembolsos, por debajo de la mitad de un
	 * `WP_MAX_MEMORY_LIMIT` de 256 MB. Quien llama puede pedir menos, nunca más.
	 *
	 * @var int
	 */
	const MAX_ORDER_PAGES = 200;

	/**
	 * Tope de caracteres del nombre de un producto en la lista de stock bajo.
	 * Un producto personalizado puede llevar un texto largo en el nombre.
	 *
	 * @var int
	 */
	const MAX_PRODUCT_NAME_CHARS = 120;

	/**
	 * Filas que llega a pedir la consulta de `low_stock()`, desplazamiento
	 * incluido. Sin techo, un desplazamiento de siete cifras sería una consulta
	 * de siete cifras de filas.
	 *
	 * @var int
	 */
	const MAX_LOW_STOCK_WINDOW = 500;

	/**
	 * Estados de un producto que la tienda enseña en su lista: lo mismo que la
	 * lista de productos del wp-admin, que deja fuera la papelera y los
	 * borradores automáticos.
	 *
	 * Una variación solo cuenta si su producto está en uno de ellos: ver
	 * `products_with_listed_parent()`.
	 *
	 * @var array
	 */
	const LISTED_PRODUCT_STATUSES = array( 'publish', 'draft', 'pending', 'private', 'future' );

	/**
	 * Variable de consulta con la que `products_with_listed_parent()` marca la
	 * suya, para que la cláusula que añade no caiga en ninguna otra.
	 *
	 * @var string
	 */
	const LISTED_PARENT_QUERY_VAR = 'apsw_listed_parent';

	/**
	 * Totales de ventas de un rango de fechas, contando solo pedidos pagados.
	 *
	 * @param string $from      Inicio del rango en hora local, `AAAA-MM-DD HH:MM:SS`.
	 * @param string $to        Fin del rango en hora local, `AAAA-MM-DD HH:MM:SS`.
	 * @param int    $max_pages Páginas de ORDERS_PAGE_SIZE pedidos que se recorren como mucho.
	 * @return array array{net_sales: float, orders: int, refunds: float, partial: bool}
	 */
	public static function sales_totals( $from, $to, $max_pages = self::MAX_ORDER_PAGES ) {
		$totals = self::paid_orders( (string) $from, (string) $to, $max_pages );

		return array(
			'net_sales' => round( $totals['net'], 2 ),
			'orders'    => $totals['orders'],
			'refunds'   => round( $totals['refunds'], 2 ),
			// `true` si se llegó al tope de páginas: la cifra no cubre todo el
			// rango.
			'partial'   => $totals['partial'],
		);
	}

	/**
	 * Recorre los pedidos pagados de un rango de fechas local y los suma.
	 *
	 * Es el único bucle que suma ventas, así que todo el que pregunta por
	 * ellas recibe los mismos números.
	 *
	 * El rango se le pasa a WooCommerce como dos timestamps UTC, no como las
	 * dos fechas locales. Con texto, WooCommerce solo mira el día y tira la
	 * hora, en los dos almacenes (`OrdersTableQuery::local_time_to_gmt_date_query()`
	 * con HPOS, `WC_Data_Store_WP::parse_date_for_wp_query()` con los pedidos
	 * en wp_posts): «ayer de 00:00 a esta hora» era ayer entero. Con los dos
	 * extremos numéricos compara al segundo contra la fecha UTC del pedido, y
	 * los dos extremos entran en el rango.
	 *
	 * @param string        $from      Inicio del rango en hora local, `AAAA-MM-DD HH:MM:SS`.
	 * @param string        $to        Fin del rango en hora local, `AAAA-MM-DD HH:MM:SS`.
	 * @param int           $max_pages Páginas que se recorren como mucho. Nunca más de MAX_ORDER_PAGES, que es el techo de memoria, ni menos de una.
	 * @param callable|null $each_page Quien quiera leer algo más de cada página
	 *                                 de pedidos antes de que se suelte: recibe
	 *                                 los pedidos de la página y devuelve los ids
	 *                                 de las líneas que haya leído.
	 * @return array array{net: float, refunds: float, orders: int, partial: bool}
	 */
	public static function paid_orders( $from, $to, $max_pages = self::MAX_ORDER_PAGES, $each_page = null ) {
		$max_pages = max( 1, min( self::MAX_ORDER_PAGES, (int) $max_pages ) );
		$each_page = is_callable( $each_page ) ? $each_page : null;

		$net     = 0.0;
		$refunds = 0.0;
		$count   = 0;
		$offset  = 0;
		$pages   = 0;
		$range   = self::utc_range( $from, $to );

		// Se suma paginando. Con 'limit' => -1 la consulta traía a memoria todos
		// los pedidos del rango, y en una tienda con volumen eso mataba el
		// proceso.
		do {
			$orders = wc_get_orders(
				array(
					// Solo pedidos. Sin `type` la consulta trae también los
					// reembolsos (`wc_get_order_types( 'view-orders' )` los
					// incluye, y se guardan en estado `completed`): contaban
					// como un pedido más y, como no tienen
					// get_total_refunded(), acababan en un fatal.
					'type'         => 'shop_order',
					// Mismo criterio que Analytics de WooCommerce: pedidos pagados.
					'status'       => array( 'processing', 'completed' ),
					'date_created' => $range,
					'limit'        => self::ORDERS_PAGE_SIZE,
					'offset'       => $offset,
					'orderby'      => 'ID',
					'order'        => 'ASC',
					'return'       => 'objects',
				)
			);

			$orders    = is_array( $orders ) ? $orders : array();
			$count    += count( $orders );
			$order_ids = array();

			foreach ( $orders as $order ) {
				$refunded = (float) $order->get_total_refunded();
				$net     += (float) $order->get_total() - $refunded;
				$refunds += $refunded;

				$order_ids[] = (int) $order->get_id();
			}

			$item_ids  = null !== $each_page ? array_map( 'intval', (array) call_user_func( $each_page, $orders ) ) : null;
			$page_size = count( $orders );
			$offset   += self::ORDERS_PAGE_SIZE;
			++$pages;

			// Los objetos de la página se sueltan antes de pedir la siguiente,
			// y con ellos lo que su lectura dejó en la caché de objetos.
			unset( $orders );

			// Sin leer las líneas no se conocen sus ids, pero en la caché están
			// igual: las ceba la consulta, no `get_items()`.
			if ( null === $item_ids ) {
				$item_ids = self::primed_item_ids( $order_ids );
			}

			self::forget_page_caches( $order_ids, $item_ids );

			// Se para cuando una página viene vacía, no cuando viene corta:
			// que una página traiga menos de las pedidas no quiere decir que
			// se acabaron los pedidos —WooCommerce no lo garantiza, y un
			// filtro de terceros puede devolver menos— y darlo por hecho
			// dejaba la suma incompleta sin decirlo, que es peor que un
			// error. Cuesta una consulta más.
		} while ( $page_size > 0 && $pages < $max_pages );

		return array(
			'net'     => $net,
			'refunds' => $refunds,
			'orders'  => $count,
			// Se llegó al tope de páginas y todavía quedaban pedidos: la cifra
			// no cubre todo el rango.
			'partial' => $pages >= $max_pages && $page_size > 0,
		);
	}

	/**
	 * Un rango de fechas locales de la tienda, como lo entiende WooCommerce al
	 * segundo: `<timestamp UTC>...<timestamp UTC>`.
	 *
	 * Con la zona horaria de la tienda y no con su desfase de ahora: cada
	 * extremo lleva el desfase de su propio día, así que un rango que cruza un
	 * cambio de horario sigue empezando en su medianoche.
	 *
	 * @param string $from Inicio en hora local, `AAAA-MM-DD HH:MM:SS`.
	 * @param string $to   Fin en hora local, `AAAA-MM-DD HH:MM:SS`.
	 * @return string
	 */
	private static function utc_range( $from, $to ) {
		$zone  = wp_timezone();
		$start = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', (string) $from, $zone );
		$end   = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', (string) $to, $zone );

		// Una fecha que no se entiende no abre el rango: da uno en el que no
		// hay pedidos. Y no «0...0»: el almacén clásico toma un extremo «0» por
		// vacío, descarta el filtro y devuelve los pedidos de toda la tienda.
		if ( ! $start || ! $end ) {
			return '1...1';
		}

		return $start->getTimestamp() . '...' . $end->getTimestamp();
	}

	/**
	 * Ids de las líneas que la consulta de una página dejó en la caché, sin
	 * leerlas del pedido.
	 *
	 * `wc_get_orders()` ceba las líneas de toda la página aunque nadie llame a
	 * `get_items()`: `prime_order_item_caches_for_orders()`
	 * (abstract-wc-order-data-store-cpt.php:594, que llama
	 * `prime_caches_for_orders()` en los dos almacenamientos) deja por pedido la
	 * lista de filas en `orders` / `order-items-<id>`, y por línea su fila, su
	 * meta y su blob de meta. Esa lista es de donde salen aquí los ids, y hay
	 * que leerla antes de que `forget_page_caches()` la borre.
	 *
	 * @param array $order_ids Ids de los pedidos de la página.
	 * @return array
	 */
	private static function primed_item_ids( array $order_ids ) {
		if ( ! function_exists( 'wp_cache_get' ) ) {
			return array();
		}

		$item_ids = array();

		foreach ( $order_ids as $order_id ) {
			$rows = wp_cache_get( 'order-items-' . $order_id, 'orders' );

			foreach ( is_array( $rows ) ? $rows : array() as $row ) {
				if ( is_object( $row ) && isset( $row->order_item_id ) ) {
					$item_ids[] = (int) $row->order_item_id;
				}
			}
		}

		return $item_ids;
	}

	/**
	 * Suelta de la caché de objetos lo que la lectura de una página de pedidos
	 * acaba de dejar dentro.
	 *
	 * Paginar acota los objetos vivos, no la caché: WP_Object_Cache no desaloja
	 * nada, así que sin esto cada página se queda para siempre y el pico crece
	 * con el total de pedidos del rango.
	 *
	 * El reparto real de lo que se queda por pedido, medido: tres cuartas
	 * partes son el objeto del pedido que cachea OrderCache, y otra sexta el
	 * blob de meta de sus líneas. Las claves de reembolso, que parecían el
	 * problema, son el 2%.
	 *
	 * Se borra en vez de suspender la adición: wp_suspend_cache_addition() solo
	 * frena wp_cache_add() (WP_Object_Cache::add() lo comprueba, set() no), y
	 * las líneas de pedido se guardan con wp_cache_set()
	 * (Abstract_WC_Order_Data_Store_CPT::read_items(), que HPOS también hereda).
	 * Suspender, además, dejaría sin cebar la meta que WP_Query trae en una sola
	 * consulta y cada lectura posterior volvería a la base de datos.
	 *
	 * @param array $order_ids Ids de los pedidos de la página.
	 * @param array $item_ids  Ids de sus líneas.
	 * @return void
	 */
	private static function forget_page_caches( array $order_ids, array $item_ids ) {
		if ( ! function_exists( 'wp_cache_delete' ) ) {
			return;
		}

		$orders_prefix = self::cache_prefix( 'orders' );
		$object_group  = self::order_cache_group();
		$object_prefix = self::cache_prefix( $object_group );

		foreach ( $order_ids as $order_id ) {
			// Líneas del pedido, en los dos almacenamientos.
			wp_cache_delete( 'order-items-' . $order_id, 'orders' );
			// Almacenamiento clásico: el post del pedido y su meta, que ceba WP_Query.
			wp_cache_delete( $order_id, 'posts' );
			wp_cache_delete( $order_id, 'post_meta' );

			// El objeto del pedido entero, que es la entrada grande: tres
			// cuartas partes de lo que se queda por pedido. Lo guarda
			// OrderCache desde WC_Order_Factory::get_orders(), y basta con que
			// HPOS esté en uso —no hace falta su caché de almacén— así que en
			// la configuración por defecto está siempre.
			if ( '' !== $object_prefix ) {
				wp_cache_delete( $object_prefix . $order_id, $object_group );
			}

			// El blob de meta del pedido, que guarda WC_Data::read_meta_data().
			self::forget_meta_cache( $order_id, 'orders' );

			// Y las tres claves de reembolso que ceban
			// prime_refund_caches_for_orders() y su hermana de totales:
			// pequeñas, pero una por pedido también.
			if ( '' !== $orders_prefix ) {
				wp_cache_delete( $orders_prefix . 'refund_ids' . $order_id, 'orders' );
				wp_cache_delete( $orders_prefix . 'total_refunded' . $order_id, 'orders' );
				wp_cache_delete( $orders_prefix . 'total_tax_refunded' . $order_id, 'orders' );
			}
		}

		foreach ( $item_ids as $item_id ) {
			wp_cache_delete( 'item-' . $item_id, 'order-items' );
			wp_cache_delete( $item_id, 'order_item_meta' );
			self::forget_meta_cache( $item_id, 'order-items' );
		}

		self::forget_order_store_caches( $order_ids );
	}

	/**
	 * Grupo donde WooCommerce guarda el objeto del pedido.
	 *
	 * Misma decisión que `OrderCache::get_object_type()`: con la caché del
	 * almacén HPOS encendida el objeto va a `order_objects` y si no, a
	 * `orders`.
	 *
	 * @return string
	 */
	private static function order_cache_group() {
		return 'yes' === get_option( 'woocommerce_hpos_datastore_caching_enabled' ) ? 'order_objects' : 'orders';
	}

	/**
	 * Prefijo con el que WooCommerce versiona las claves de un grupo, o cadena
	 * vacía si WooCommerce no está cargado.
	 *
	 * `WC_Cache_Helper::get_cache_prefix()` es público y estático, así que la
	 * clave se puede construir desde fuera y borrar una a una. Eso evita
	 * `wp_cache_flush_group()`, que para invalidar una entrada se llevaría por
	 * delante el grupo entero —incluidos los pedidos que otra parte de la
	 * petición sí necesita— y además cambia el prefijo para todo el mundo.
	 *
	 * @param string $group Grupo de caché.
	 * @return string
	 */
	private static function cache_prefix( $group ) {
		if ( ! is_callable( array( 'WC_Cache_Helper', 'get_cache_prefix' ) ) ) {
			return '';
		}

		return (string) WC_Cache_Helper::get_cache_prefix( $group );
	}

	/**
	 * Suelta el blob de meta que WC_Data::read_meta_data() deja por objeto.
	 *
	 * La clave la arma `WC_Data::generate_meta_cache_key()`, que también es
	 * pública y estática: `get_cache_prefix($grupo) .
	 * get_cache_prefix('object_'.$id) . 'object_meta_'.$id`
	 * (abstract-wc-data.php:653).
	 *
	 * **Lo que no se toca es el prefijo `object_<id>`**, y es a propósito.
	 * `CacheNameSpaceTrait::get_cache_prefix()` no devuelve vacío cuando la
	 * clave no está: **acuña un prefijo nuevo y lo persiste**. Y ese espacio de
	 * nombres es de un *id*, no de un grupo: lo comparten la meta del pedido, la
	 * de la línea y la del producto que tengan ese mismo número, y el núcleo lo
	 * invalida entero cuando cambia la meta de cualquiera de ellos
	 * (wc-order-item-functions.php:107, class-wc-post-data.php:653). Borrarlo
	 * dejaba blobs inalcanzables: los de un id que es a la vez de pedido y de
	 * línea, y el del producto que otra parte de la misma petición está
	 * leyendo.
	 *
	 * Lo que se queda vivo a cambio es una clave de ~120 B por objeto, con el
	 * valor que el propio WooCommerce escribe al leer su meta en cualquier otra
	 * pantalla, y se reutiliza igual la vez siguiente: es un residuo estable,
	 * no uno que crece.
	 *
	 * @param int    $object_id Id del pedido o de la línea.
	 * @param string $group     Grupo de caché del objeto.
	 * @return void
	 */
	private static function forget_meta_cache( $object_id, $group ) {
		if ( ! is_callable( array( 'WC_Data', 'generate_meta_cache_key' ) ) ) {
			return;
		}

		wp_cache_delete( WC_Data::generate_meta_cache_key( $object_id, $group ), $group );
	}

	/**
	 * Pide al almacén de pedidos que suelte su propia caché.
	 *
	 * Sólo hace algo con la caché del almacén HPOS encendida
	 * (`woocommerce_hpos_datastore_caching_enabled` en `yes`, que **no** es el
	 * valor por defecto): `OrdersTableDataStore::clear_cached_data()` sale en
	 * su primera línea si `custom_orders_table_datastore_cache_enabled()` es
	 * falso. Ahí guarda las filas del pedido y su meta en el grupo
	 * `orders_data`, con claves que desde fuera no se pueden reconstruir sin
	 * saber el grupo, así que esto sigue haciendo falta.
	 *
	 * @param array $order_ids Ids de los pedidos de la página.
	 * @return void
	 */
	private static function forget_order_store_caches( array $order_ids ) {
		if ( empty( $order_ids ) || ! class_exists( 'WC_Data_Store' ) ) {
			return;
		}

		try {
			$store = WC_Data_Store::load( 'order' );
		} catch ( Exception $e ) {
			return;
		}

		if ( method_exists( $store, 'has_callable' ) && $store->has_callable( 'clear_cached_data' ) ) {
			$store->clear_cached_data( $order_ids );
		}
	}

	/**
	 * Los tipos de producto que registra la tienda más las variaciones.
	 *
	 * `variation` no es un tipo del selector —`wc_get_product_types()` devuelve
	 * `simple, grouped, external, variable`— pero sí es el valor que abre el
	 * `post_type` de una consulta a `product_variation`. La lista sale de
	 * `wc_get_product_types()` y no de una copia escrita aquí para no dejar
	 * fuera los tipos que registren otros plugins.
	 *
	 * @return array
	 */
	public static function product_types_with_variations() {
		$types = function_exists( 'wc_get_product_types' )
			? array_keys( (array) wc_get_product_types() )
			: array( 'simple', 'grouped', 'external', 'variable' );

		$types[] = 'variation';

		return $types;
	}

	/**
	 * Productos agotados o por debajo del umbral de pocas existencias, del que
	 * menos tiene al que más.
	 *
	 * Son productos publicados que controlan su cantidad, y también
	 * variaciones, que es donde vive el inventario de una tienda de moda: cada
	 * una es una entrada.
	 *
	 * @param array $args `threshold`, para usar otro umbral que el de la
	 *                    tienda, y `offset`, las entradas que se saltan. Los
	 *                    dos pueden llegar como texto.
	 * @param int   $max  Entradas que se devuelven como mucho.
	 * @return array array{threshold: int, offset: int, products: array, more: bool, managing_stock: bool}
	 *               Cada producto es array{id: int, name: string, stock: int, status: string}.
	 */
	public static function low_stock( array $args, $max ) {
		$threshold = isset( $args['threshold'] ) && '' !== $args['threshold']
			? absint( $args['threshold'] )
			: absint( get_option( 'woocommerce_notify_low_stock_amount', 2 ) );

		// Con el control de stock desactivado en WooCommerce (Ajustes →
		// Productos → Inventario) ningún producto controla su cantidad, diga lo
		// que diga su `_manage_stock`: `WC_Product::managing_stock()` contesta
		// que no, y la tienda ni descuenta ni avisa. La consulta de abajo no lo
		// sabe —mira el meta de cada producto— y devolvía una lista de
		// «agotados» que la tienda no trata como tales. No hay stock bajo que
		// contar.
		if ( 'yes' !== get_option( 'woocommerce_manage_stock' ) ) {
			return array(
				'threshold'      => $threshold,
				'offset'         => 0,
				'products'       => array(),
				'more'           => false,
				'managing_stock' => false,
			);
		}

		$max = max( 1, (int) $max );

		// El desplazamiento llega de fuera, quizá como texto. Se acota en coma
		// flotante y se convierte a entero al final, a propósito: `absint()` —y
		// cualquier `(int)` sobre el valor crudo— avisa o devuelve un float
		// cuando el número no cabe en un entero, y `array_slice()` sólo acepta
		// int. El techo es la ventana, que es lo máximo que esta consulta llega
		// a pedir de todos modos.
		$raw_offset = isset( $args['offset'] ) && is_numeric( $args['offset'] ) ? (float) $args['offset'] : 0.0;
		$offset     = (int) min( max( 0.0, $raw_offset ), (float) self::MAX_LOW_STOCK_WINDOW );

		// Se ordena por existencias en la propia consulta: si hay más productos
		// que controlan su cantidad que los que caben, el límite debe quedarse
		// con los de menos existencias, y no con los primeros por orden
		// alfabético.
		//
		// Y se excluyen los de `_stock` vacío (importaciones CSV, alta por
		// API): ordenan como 0 y se colaban en la ventana delante de los que
		// sí están agotados, que luego descartaba el filtro de abajo por
		// get_stock_quantity() === null. Se excluyen con el comodín, que es el
		// idioma que WooCommerce entiende: `'stock_quantity' => '*'` se mapea a
		// `stock` (WC_Product_Data_Store_CPT::get_wp_query_args()), `_stock`
		// está en internal_meta_keys, y el padre lo convierte en un meta_query
		// de EXISTS + `!= ''` (WC_Data_Store_WP::get_wp_query_args()).
		// `_stock` = '0' sí entra: es un agotado de verdad.
		//
		// De las variaciones, solo las que tienen dónde verse: la de un producto
		// que se borró o está en la papelera se queda fuera **en la consulta**,
		// antes de cortar la ventana, para que ni la cuenta ni el «hay más»
		// cuenten filas que nadie puede abrir. WooCommerce, además, le borra el
		// título a una variación sin producto en cuanto la lee
		// (`WC_Product_Variation_Data_Store_CPT::read()`): salía en la lista
		// como una fila en blanco.
		$products = self::products_with_listed_parent(
			array(
				'manage_stock'   => true,
				'status'         => 'publish',
				// Con las variaciones. El `type` por defecto de
				// `WC_Product_Query::get_default_query_vars()` son las claves
				// de `wc_get_product_types()`, sin `variation`, y con ese array
				// `WC_Product_Data_Store_CPT::get_wp_query_args()` consulta
				// solo `post_type = 'product'`: una tienda con cuatro tallas
				// agotándose leía una lista vacía.
				'type'           => self::product_types_with_variations(),
				// Uno más que los que caben, y contando desde el principio:
				// ese uno de más es lo que distingue «éstos son todos» de «hay
				// más», sin una segunda consulta, y el desplazamiento tiene
				// que entrar en la ventana o la segunda página volvería a
				// traer la primera. El filtro por umbral vive en PHP —la
				// consulta ordena por existencias pero no sabe cuál es el
				// umbral— así que el recorte de la página se hace después.
				'limit'          => min( self::MAX_LOW_STOCK_WINDOW, $offset + $max + 1 ),
				// Por existencias y, entre los que tienen las mismas, por id.
				// Cada página es otra consulta con otro `limit`, y sin un
				// segundo criterio MySQL devuelve los empatados en un orden
				// que cambia con él: en una tienda con cientos de agotados las
				// páginas repetían unas filas y se saltaban otras.
				//
				// Con `orderby` como array cada columna lleva su sentido, y
				// WP_Query no mira `order` (class-wp-query.php:2522).
				// `meta_value_num` ordena por el meta de `meta_key`, que es la
				// primera cláusula de la consulta de metas
				// (WP_Meta_Query::parse_query_vars()), y WooCommerce pasa el
				// array tal cual (WC_Data_Store_WP::get_wp_query_args()).
				'orderby'        => array(
					'meta_value_num' => 'ASC',
					'ID'             => 'ASC',
				),
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Ordering by stock quantity is the purpose of this query; it is limited to MAX_LOW_STOCK_WINDOW rows.
				'meta_key'       => '_stock',
				'stock_quantity' => '*',
			)
		);

		$low = array();

		foreach ( (array) $products as $product ) {
			$stock = $product->get_stock_quantity();

			if ( null === $stock || (int) $stock > $threshold ) {
				continue;
			}

			$low[] = array(
				'id'     => (int) $product->get_id(),
				'name'   => mb_substr( (string) $product->get_name(), 0, self::MAX_PRODUCT_NAME_CHARS ),
				'stock'  => (int) $stock,
				'status' => (string) $product->get_stock_status(),
			);
		}

		// El mismo orden que la consulta, con su mismo desempate.
		usort(
			$low,
			static function ( $a, $b ) {
				return array( $a['stock'], $a['id'] ) <=> array( $b['stock'], $b['id'] );
			}
		);

		return array(
			'threshold'      => $threshold,
			'offset'         => $offset,
			'products'       => array_slice( $low, $offset, $max ),
			// Hay más que las que caben: se dice, en vez de devolver una lista
			// corta con cara de completa.
			'more'           => count( $low ) > $offset + $max,
			'managing_stock' => true,
		);
	}

	/**
	 * `wc_get_products()` sin las variaciones que no tienen dónde verse.
	 *
	 * Una variación se ve dentro de su producto. La de un producto que ya no
	 * existe, o que está en la papelera, sigue en la base de datos con su
	 * stock y su estado, y una consulta que pide variaciones la trae: una fila
	 * que nadie puede abrir. Tampoco tiene dónde verse la que está
	 * desactivada (`private`): la tienda no la vende.
	 *
	 * Se apartan en la propia consulta, con una cláusula en `posts_where`, y no
	 * después: así `limit` y `offset` cuentan solo filas que se enseñan, y una
	 * página ni repite, ni se salta, ni sale vacía diciendo que hay más. La
	 * cláusula se engancha solo mientras dura esta llamada y solo actúa sobre
	 * la consulta que lleva la marca LISTED_PARENT_QUERY_VAR —WooCommerce pasa
	 * a WP_Query los argumentos que no conoce
	 * (`WC_Data_Store_WP::get_wp_query_args()`)—, así que ninguna otra consulta
	 * de la petición la ve.
	 *
	 * Sin ningún estado no hay consulta: WooCommerce descarta un argumento que
	 * es un array vacío, la marca no llegaría a WP_Query y la consulta saldría
	 * sin la cláusula, con todas las variaciones. Pedir las de «ningún estado»
	 * es no pedir nada.
	 *
	 * @param array $args            Argumentos de `wc_get_products()`.
	 * @param array $parent_statuses Estados en los que tiene que estar el producto de una variación.
	 * @return array|object Lo que devuelva `wc_get_products()`; array() si no se da ningún estado.
	 */
	public static function products_with_listed_parent( array $args, array $parent_statuses = self::LISTED_PRODUCT_STATUSES ) {
		$parent_statuses = array_values( array_filter( array_map( 'strval', array_filter( $parent_statuses, 'is_scalar' ) ), 'strlen' ) );

		if ( ! $parent_statuses ) {
			return array();
		}

		$args[ self::LISTED_PARENT_QUERY_VAR ] = $parent_statuses;

		add_filter( 'posts_where', array( __CLASS__, 'listed_parent_where' ), 10, 2 );

		try {
			return wc_get_products( $args );
		} finally {
			remove_filter( 'posts_where', array( __CLASS__, 'listed_parent_where' ), 10 );
		}
	}

	/**
	 * La cláusula de `products_with_listed_parent()`: de las variaciones, solo
	 * las activadas cuyo producto existe, es un producto y está en uno de los
	 * estados pedidos. Lo que no es una variación pasa.
	 *
	 * @param string        $where La cláusula WHERE de la consulta.
	 * @param WP_Query|null $query La consulta.
	 * @return string
	 */
	public static function listed_parent_where( $where, $query = null ) {
		$statuses = is_object( $query ) && is_callable( array( $query, 'get' ) ) ? $query->get( self::LISTED_PARENT_QUERY_VAR ) : null;

		if ( ! is_array( $statuses ) || ! $statuses ) {
			return $where;
		}

		global $wpdb;

		// Un marcador por estado: los valores van todos por prepare().
		$placeholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		$clause = $wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Only the posts table name from $wpdb and a generated list of %s placeholders (one per status) are interpolated; every value is passed to prepare().
			" AND ( {$wpdb->posts}.post_type <> %s OR ( {$wpdb->posts}.post_status = %s AND EXISTS ( SELECT 1 FROM {$wpdb->posts} AS apsw_parent WHERE apsw_parent.ID = {$wpdb->posts}.post_parent AND apsw_parent.post_type = %s AND apsw_parent.post_status IN ( {$placeholders} ) ) ) )",
			array_merge( array( 'product_variation', 'publish', 'product' ), array_values( $statuses ) )
		);

		return $where . $clause;
	}
}
