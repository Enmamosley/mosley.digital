<?php
/**
 * La pantalla de Inicio de la app móvil.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Arma la respuesta de `GET /app/home`: las ventas del periodo comparadas con
 * el periodo anterior, los pedidos por atender y los productos con poco stock.
 * Las cifras de ventas y el stock bajo salen de APSW_App_Store.
 *
 * Dice además, en `features`, qué más ofrece esta tienda a la
 * app: hoy, si tiene disponible su pestaña de chat.
 *
 * Los textos que devuelve van por gettext, con el inglés de base
 * (`mosley-digital-for-woocommerce`).
 */
class APSW_App_Home {

	const PERIODS = array( 'today', 'yesterday', 'last_7_days', 'last_30_days', 'this_month' );

	/**
	 * Prefijo del transient que guarda los totales de ventas de un periodo.
	 *
	 * @var string
	 */
	const CACHE_PREFIX = 'apsw_app_sales_';

	/**
	 * Segundos que se guardan los totales de ventas.
	 *
	 * @var int
	 */
	const CACHE_TTL = 60;

	/**
	 * Páginas de pedidos que se recorren como mucho por ventana: 25 páginas de
	 * `APSW_App_Store::ORDERS_PAGE_SIZE` son 5.000 pedidos.
	 *
	 * Muy por debajo del tope de `APSW_App_Store::MAX_ORDER_PAGES`, que es el
	 * techo de memoria. Inicio es lo primero que abre la app y se recarga sola: en una
	 * tienda grande contesta enseguida con `partial: true` en vez de agotar el
	 * tiempo de la petición recorriendo dos ventanas de 40.000 pedidos.
	 *
	 * @var int
	 */
	const MAX_SALES_PAGES = 25;

	/**
	 * Estados que Inicio enseña como «por atender», en el orden en que salen.
	 *
	 * @var array
	 */
	private const ORDER_STATUSES = array( 'processing', 'on-hold', 'pending' );

	/**
	 * Productos con poco stock que se llegan a contar. Si hay más, se dice.
	 *
	 * @var int
	 */
	private const LOW_STOCK_LIMIT = 100;

	/**
	 * Productos con poco stock que viajan en la respuesta: los de menos
	 * existencias.
	 *
	 * @var int
	 */
	private const LOW_STOCK_SHOWN = 5;

	/**
	 * A quién se le pregunta si la tienda tiene disponible la pestaña de chat
	 * de la app: algo que se puede llamar y contesta
	 * `array( 'available' => bool, … )`. null si no hay a quién preguntar.
	 *
	 * No es una clase a propósito. Inicio, Pedidos y Productos funcionan en
	 * cualquier tienda con este plugin, y este plugin no trae ese chat: no se
	 * pasa nada, e Inicio contesta que no lo hay. Lo pasa quien sí lo traiga.
	 *
	 * @var callable|null
	 */
	private $chat_availability;

	/**
	 * Constructor.
	 *
	 * @param callable|null $chat_availability Quien dice si el chat está
	 *                                         disponible. Lo que no se puede
	 *                                         llamar cuenta como no pasar nada.
	 */
	public function __construct( $chat_availability = null ) {
		$this->chat_availability = is_callable( $chat_availability ) ? $chat_availability : null;
	}

	/**
	 * La respuesta de Inicio para un periodo.
	 *
	 * @param mixed $period Uno de PERIODS.
	 * @return array|WP_Error
	 */
	public function home( $period ) {
		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested -- The periods are days of the store's local calendar: windows() needs the local wall clock written as a timestamp, which is what this returns.
		$windows = self::windows( $period, (int) current_time( 'timestamp' ) );
		if ( is_wp_error( $windows ) ) {
			return $windows;
		}

		$totals   = $this->sales_totals( $period, $windows );
		$current  = $totals['current'];
		$previous = $totals['previous'];

		// Una cifra que se quedó a medias no se compara: el porcentaje contra
		// (o desde) una ventana recortada no dice nada de las ventas.
		$comparable = ! $current['partial'] && ! $previous['partial'];

		return array(
			'period'       => array( 'key' => $period, 'label' => $windows['label'] ),
			'sales'        => array(
				'net'     => $this->money( $current['net_sales'] ),
				'orders'  => (int) $current['orders'],
				'average' => $this->money( $current['orders'] > 0 ? $current['net_sales'] / $current['orders'] : 0 ),
				// Sin reembolsos no hay línea que pintar: null, no «$0.00».
				'refunds' => $current['refunds'] > 0 ? $this->money( $current['refunds'] ) : null,
				'partial' => (bool) $current['partial'],
			),
			'comparison'   => array(
				'label'         => $windows['comparison_label'],
				'net_change'    => $comparable ? self::change( $current['net_sales'], $previous['net_sales'] ) : null,
				'orders_change' => $comparable ? self::change( $current['orders'], $previous['orders'] ) : null,
			),
			'order_counts' => $this->order_counts(),
			'low_stock'    => $this->low_stock(),
			'features'     => $this->features(),
		);
	}

	/**
	 * Lo que esta tienda ofrece a la app además de Inicio, Pedidos y
	 * Productos.
	 *
	 * Inicio es lo primero que la app pide, así que aquí se entera de si
	 * enseñar su pestaña de chat: la clave lleva el `available` de quien se
	 * pasó al constructor, y `false` si no se pasó a nadie.
	 *
	 * No se guarda con las ventas: se pregunta en cada petición, para que un
	 * cambio en los ajustes de la tienda se vea al recargar.
	 *
	 * @return array Una clave por cosa que la tienda puede ofrecer, con su sí o su no.
	 */
	private function features() {
		$availability = null !== $this->chat_availability ? call_user_func( $this->chat_availability ) : null;

		return array(
			// Solo un sí rotundo: en la duda, la app no enseña el chat.
			'assistant' => is_array( $availability ) && isset( $availability['available'] ) && true === $availability['available'],
		);
	}

	/**
	 * Borra los totales de ventas guardados de los cinco periodos.
	 *
	 * La llama la ruta que cambia el estado de un pedido: uno que acaba de
	 * pasar a pagado tiene que verse al recargar Inicio, no un minuto después.
	 *
	 * @return void
	 */
	public static function forget_sales_cache() {
		foreach ( self::PERIODS as $period ) {
			delete_transient( self::CACHE_PREFIX . $period );
		}
	}

	/**
	 * Las dos ventanas de un periodo: la actual y la inmediatamente anterior,
	 * de la misma duración.
	 *
	 * Todo se calcula en la hora local de la tienda: `$now` es esa hora escrita como
	 * si fuera UTC, así que restarle días enteros da la misma hora de otro día
	 * sin que un cambio de horario la mueva.
	 *
	 * @param mixed $period Uno de PERIODS.
	 * @param int   $now    Timestamp local (`current_time( 'timestamp' )`).
	 * @return array|WP_Error array( 'label', 'comparison_label', 'current' => array( 'from', 'to' ), 'previous' => array( 'from', 'to' ) ), con fechas `AAAA-MM-DD HH:MM:SS`.
	 */
	public static function windows( $period, $now ) {
		if ( ! is_string( $period ) || ! in_array( $period, self::PERIODS, true ) ) {
			return new WP_Error( 'invalid_params', __( 'Invalid period.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$now = (int) $now;

		// El día de hace N días, y esta misma hora de ese día.
		$day = static function ( $days_ago ) use ( $now ) {
			return gmdate( 'Y-m-d', $now - $days_ago * DAY_IN_SECONDS );
		};
		$moment = static function ( $days_ago ) use ( $now ) {
			return gmdate( 'Y-m-d H:i:s', $now - $days_ago * DAY_IN_SECONDS );
		};

		switch ( $period ) {
			case 'today':
				$current  = array( $day( 0 ) . ' 00:00:00', $moment( 0 ) );
				$previous = array( $day( 1 ) . ' 00:00:00', $moment( 1 ) );
				break;
			case 'yesterday':
				$current  = array( $day( 1 ) . ' 00:00:00', $day( 1 ) . ' 23:59:59' );
				$previous = array( $day( 2 ) . ' 00:00:00', $day( 2 ) . ' 23:59:59' );
				break;
			case 'last_7_days':
				$current  = array( $day( 6 ) . ' 00:00:00', $moment( 0 ) );
				$previous = array( $day( 13 ) . ' 00:00:00', $moment( 7 ) );
				break;
			case 'last_30_days':
				$current  = array( $day( 29 ) . ' 00:00:00', $moment( 0 ) );
				$previous = array( $day( 59 ) . ' 00:00:00', $moment( 30 ) );
				break;
			default:
				$current  = array( gmdate( 'Y-m-01', $now ) . ' 00:00:00', $moment( 0 ) );
				$previous = self::last_month_to_date( $now );
		}

		$labels = self::labels( $period );

		return array(
			'label'            => $labels[0],
			'comparison_label' => $labels[1],
			'current'          => array( 'from' => $current[0], 'to' => $current[1] ),
			'previous'         => array( 'from' => $previous[0], 'to' => $previous[1] ),
		);
	}

	/**
	 * La etiqueta de un periodo y la de su comparación. La app las pinta tal
	 * cual.
	 *
	 * @param string $period Uno de PERIODS.
	 * @return array array( etiqueta, etiqueta de la comparación ).
	 */
	private static function labels( $period ) {
		switch ( $period ) {
			case 'today':
				return array( __( 'Today', 'mosley-digital-for-woocommerce' ), __( 'vs yesterday at this time', 'mosley-digital-for-woocommerce' ) );
			case 'yesterday':
				return array( __( 'Yesterday', 'mosley-digital-for-woocommerce' ), __( 'vs the day before', 'mosley-digital-for-woocommerce' ) );
			case 'last_7_days':
				return array( __( '7 days', 'mosley-digital-for-woocommerce' ), __( 'vs the previous 7 days', 'mosley-digital-for-woocommerce' ) );
			case 'last_30_days':
				return array( __( '30 days', 'mosley-digital-for-woocommerce' ), __( 'vs the previous 30 days', 'mosley-digital-for-woocommerce' ) );
			default:
				return array( __( 'This month', 'mosley-digital-for-woocommerce' ), __( 'vs the same days last month', 'mosley-digital-for-woocommerce' ) );
		}
	}

	/**
	 * El mes pasado, del día 1 al mismo día y hora de hoy.
	 *
	 * Si el mes pasado no tiene ese día —el 31 frente a febrero—, acaba en su
	 * último día a las 23:59:59: es el mes pasado entero, que es lo más parecido
	 * a «hasta esta fecha» que tiene.
	 *
	 * @param int $now Timestamp local.
	 * @return array array( from, to ).
	 */
	private static function last_month_to_date( $now ) {
		// gmmktime() normaliza el mes 0 a diciembre del año anterior.
		$first = gmmktime( 0, 0, 0, (int) gmdate( 'n', $now ) - 1, 1, (int) gmdate( 'Y', $now ) );
		$day   = (int) gmdate( 'j', $now );

		$to = $day > (int) gmdate( 't', $first )
			? gmdate( 'Y-m-t', $first ) . ' 23:59:59'
			: gmdate( 'Y-m-', $first ) . gmdate( 'd H:i:s', $now );

		return array( gmdate( 'Y-m-01', $first ) . ' 00:00:00', $to );
	}

	/**
	 * Totales de ventas de las dos ventanas de un periodo.
	 *
	 * Recorrer los pedidos de dos ventanas en cada recarga de la pantalla es
	 * caro, así que se guardan CACHE_TTL segundos en un transient por periodo.
	 * Leerlo no lo renueva: caduca al minuto de haberse contado.
	 *
	 * El transient va por periodo, no por día, así que con los totales se
	 * guardan los días que cubren. Si ya no son los de las ventanas de ahora
	 * —pasó la medianoche— no valen: unos totales contados a las 23:59:30 no
	 * son «Hoy» medio minuto después.
	 *
	 * @param string $period  Periodo, ya validado.
	 * @param array  $windows Lo que devuelve windows().
	 * @return array array( 'days' => días, 'current' => totales, 'previous' => totales ), con los totales en la forma de APSW_App_Store::sales_totals().
	 */
	private function sales_totals( $period, array $windows ) {
		$key    = self::CACHE_PREFIX . $period;
		$days   = self::days( $windows );
		$cached = get_transient( $key );

		if (
			is_array( $cached )
			&& isset( $cached['days'], $cached['current'], $cached['previous'] )
			&& $days === $cached['days']
			&& self::is_totals( $cached['current'] )
			&& self::is_totals( $cached['previous'] )
		) {
			return $cached;
		}

		$totals = array(
			'days'     => $days,
			'current'  => APSW_App_Store::sales_totals( $windows['current']['from'], $windows['current']['to'], self::MAX_SALES_PAGES ),
			'previous' => APSW_App_Store::sales_totals( $windows['previous']['from'], $windows['previous']['to'], self::MAX_SALES_PAGES ),
		);

		set_transient( $key, $totals, self::CACHE_TTL );

		return $totals;
	}

	/**
	 * Los días que cubren las dos ventanas de un periodo: el primero y el
	 * último de cada una. La hora no cuenta, que cambia a cada segundo.
	 *
	 * @param array $windows Lo que devuelve windows().
	 * @return array Cuatro fechas `AAAA-MM-DD`.
	 */
	private static function days( array $windows ) {
		return array(
			substr( $windows['current']['from'], 0, 10 ),
			substr( $windows['current']['to'], 0, 10 ),
			substr( $windows['previous']['from'], 0, 10 ),
			substr( $windows['previous']['to'], 0, 10 ),
		);
	}

	/**
	 * Si un valor guardado tiene la forma de los totales de una ventana.
	 *
	 * @param mixed $totals Valor leído del transient.
	 * @return bool
	 */
	private static function is_totals( $totals ) {
		return is_array( $totals ) && isset( $totals['net_sales'], $totals['orders'], $totals['refunds'], $totals['partial'] );
	}

	/**
	 * Cambio porcentual frente al valor anterior, con un decimal; null si el
	 * anterior fue 0, que no tiene porcentaje.
	 *
	 * @param float|int $current  Valor de la ventana actual.
	 * @param float|int $previous Valor de la ventana anterior.
	 * @return float|null
	 */
	private static function change( $current, $previous ) {
		if ( 0.0 === (float) $previous ) {
			return null;
		}

		$change = round( ( $current - $previous ) / $previous * 100, 1 );

		// round() conserva el signo de un cambio que se queda en nada, y un
		// `-0.0` viajaría tal cual en el JSON.
		return 0.0 === $change ? 0.0 : $change;
	}

	/**
	 * Cuántos pedidos hay en cada estado por atender. No se guarda: es lo que
	 * el comerciante mira para saber si entró algo.
	 *
	 * Solo `shop_order`, como las fichas de la pestaña Pedidos: sin decir el
	 * tipo, `wc_orders_count()` suma los de todos los tipos que se cuentan como
	 * pedidos, y las dos pantallas darían números distintos.
	 *
	 * @return array Lista de array( 'slug', 'label', 'count' ).
	 */
	private function order_counts() {
		$counts = array();

		foreach ( self::ORDER_STATUSES as $slug ) {
			$counts[] = array(
				'slug'  => $slug,
				'label' => (string) wc_get_order_status_name( $slug ),
				'count' => (int) wc_orders_count( $slug, 'shop_order' ),
			);
		}

		return $counts;
	}

	/**
	 * Productos agotados o por debajo del umbral de la tienda.
	 *
	 * @return array array( 'threshold', 'count', 'more', 'products' ).
	 */
	private function low_stock() {
		$low      = APSW_App_Store::low_stock( array(), self::LOW_STOCK_LIMIT );
		$products = array();

		// Llegan ordenados por existencias, así que los primeros son los de menos.
		foreach ( array_slice( $low['products'], 0, self::LOW_STOCK_SHOWN ) as $product ) {
			$products[] = array(
				'id'    => (int) $product['id'],
				// Como se guardó, con sus entidades («Café &amp; Té»): aquí se
				// deja en el mismo texto que los nombres de las líneas de un
				// pedido.
				'name'  => APSW_App_Text::plain( $product['name'] ),
				'stock' => (int) $product['stock'],
				'thumb' => $this->thumbnail( (int) $product['id'] ),
			);
		}

		return array(
			'threshold' => (int) $low['threshold'],
			'count'     => count( $low['products'] ),
			// low_stock() pide uno más de los que caben y, si lo hay, lo avisa.
			'more'      => (bool) $low['more'],
			'products'  => $products,
		);
	}

	/**
	 * URL de la miniatura de un producto; null si no tiene imagen.
	 *
	 * @param int $product_id Id del producto o de la variación.
	 * @return string|null
	 */
	private function thumbnail( $product_id ) {
		$product  = wc_get_product( $product_id );
		$image_id = is_object( $product ) ? (int) $product->get_image_id() : 0;
		$url      = $image_id > 0 ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : false;

		return is_string( $url ) && '' !== $url ? $url : null;
	}

	/**
	 * Un importe con la moneda de la tienda ("$1,480.00"), como los de los
	 * pedidos. La app no formatea dinero.
	 *
	 * @param float $amount Importe.
	 * @return string
	 */
	private function money( $amount ) {
		return APSW_App_Text::plain( wc_price( $amount ) );
	}
}
