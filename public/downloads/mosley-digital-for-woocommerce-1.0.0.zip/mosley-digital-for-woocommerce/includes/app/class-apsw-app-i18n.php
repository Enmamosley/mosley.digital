<?php
/**
 * El idioma de los textos que las clases de la app devuelven.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Carga la traducción del dominio `mosley-digital-for-woocommerce`, que es el
 * de todos los textos de includes/app/. Su idioma de base es el inglés, y el
 * plugin trae una traducción, la de `es_ES`, en su carpeta `languages/`.
 *
 * Qué traducción se carga lo decide quien registra la carpeta:
 *
 * - Con `$always_bundled` en false: una tienda en cualquier español (`es_ES`,
 *   `es_MX`, `es_AR`…) recibe la traducción que trae el plugin, salvo que
 *   WordPress tenga ya un paquete de idioma para ese mismo idioma en
 *   `WP_LANG_DIR/plugins`, que entonces es el que vale. Los demás idiomas
 *   reciben el suyo si WordPress lo tiene, y si no, el inglés.
 * - Con `$always_bundled` en true: siempre la traducción que trae el plugin,
 *   sea cual sea el idioma de la tienda.
 *
 * Cómo se hace, y por qué así (WordPress 6.4 a 7.1, `wp-includes/l10n.php`):
 *
 * - Toda carga de traducciones pasa por `load_textdomain()`, que deja cambiar
 *   el archivo con el filtro `load_textdomain_mofile`. Ahí se decide: el
 *   archivo pedido, si existe, o el que trae el plugin.
 * - WordPress carga solo, la primera vez que hace falta, las traducciones que
 *   encuentra en `WP_LANG_DIR/plugins` (`_load_textdomain_just_in_time()`). Lo
 *   que no encuentra no lo intenta, así que en `init`, y cada vez que cambia
 *   el idioma (`change_locale`), se pide aquí una carga para el idioma del
 *   momento. `init` es el primer gancho en el que WordPress admite cargar
 *   traducciones sin su aviso de «carga demasiado temprana» (6.7), y antes de
 *   él ninguna clase de la app devuelve un texto.
 * - El idioma es el de `determine_locale()`: el de la tienda en una petición
 *   REST, que es lo que lee la app, y el del usuario en el wp-admin.
 * - No se llama a `load_plugin_textdomain()`: no hace falta desde WordPress
 *   4.6 para un plugin del directorio, y no sabría elegir entre un paquete de
 *   idioma y la traducción que trae el plugin.
 */
class APSW_App_I18n {

	/**
	 * El dominio de los textos de la app.
	 *
	 * @var string
	 */
	const DOMAIN = 'mosley-digital-for-woocommerce';

	/**
	 * El idioma de la traducción que trae el plugin.
	 *
	 * @var string
	 */
	const BUNDLED_LOCALE = 'es_ES';

	/**
	 * La carpeta `languages/` del plugin, con su barra final; '' si nadie la
	 * ha registrado.
	 *
	 * @var string
	 */
	private static $languages_dir = '';

	/**
	 * Si se usa siempre la traducción que trae el plugin.
	 *
	 * @var bool
	 */
	private static $always_bundled = false;

	/**
	 * Si los ganchos ya están puestos.
	 *
	 * @var bool
	 */
	private static $hooked = false;

	/**
	 * Registra la carpeta de traducciones del plugin y engancha la carga.
	 *
	 * Se puede llamar más de una vez: vale la última.
	 *
	 * @param string $languages_dir  Ruta de la carpeta `languages/` del plugin.
	 * @param bool   $always_bundled true para usar siempre la traducción que trae el plugin.
	 * @return void
	 */
	public static function register( $languages_dir, $always_bundled = false ) {
		self::$languages_dir  = rtrim( (string) $languages_dir, '/\\' ) . '/';
		self::$always_bundled = (bool) $always_bundled;

		if ( self::$hooked ) {
			return;
		}

		self::$hooked = true;

		add_filter( 'load_textdomain_mofile', array( __CLASS__, 'translation_file' ), 10, 2 );
		add_action( 'change_locale', array( __CLASS__, 'load' ) );

		// Antes que nadie en `init`. Y si `init` ya pasó —el plugin se activó a
		// mitad de la petición—, ahora.
		if ( did_action( 'init' ) ) {
			self::load();
		} else {
			add_action( 'init', array( __CLASS__, 'load' ), 0 );
		}
	}

	/**
	 * Pide a WordPress la traducción del idioma del momento.
	 *
	 * Se pide siempre el archivo del paquete de idioma de WordPress, exista o
	 * no: translation_file() lo cambia por el del plugin cuando toca, y si al
	 * final no hay ninguno la carga no hace nada y los textos salen en inglés.
	 *
	 * @param mixed $locale El idioma al que se acaba de cambiar, cuando llama
	 *                      `change_locale`; cualquier otra cosa es «el de ahora».
	 * @return void
	 */
	public static function load( $locale = null ) {
		if ( '' === self::$languages_dir || ! defined( 'WP_LANG_DIR' ) ) {
			return;
		}

		$locale = is_string( $locale ) && '' !== $locale ? $locale : determine_locale();

		load_textdomain( self::DOMAIN, WP_LANG_DIR . '/plugins/' . self::DOMAIN . '-' . $locale . '.mo', $locale );
	}

	/**
	 * El archivo de traducción que se carga para el dominio de la app.
	 *
	 * Filtro de `load_textdomain_mofile`, que ve todas las cargas: las que pide
	 * load() y las que WordPress hace solo.
	 *
	 * @param mixed $mofile Ruta del archivo `.mo` que se iba a cargar.
	 * @param mixed $domain Dominio de traducción.
	 * @return mixed
	 */
	public static function translation_file( $mofile, $domain = '' ) {
		if ( self::DOMAIN !== $domain || ! is_string( $mofile ) || '' === self::$languages_dir ) {
			return $mofile;
		}

		$bundled = self::$languages_dir . self::DOMAIN . '-' . self::BUNDLED_LOCALE . '.mo';

		if ( self::$always_bundled ) {
			return $bundled;
		}

		// El archivo pedido existe —un paquete de idioma de WordPress, o el del
		// propio plugin—: es el que vale. WordPress carga la versión `.l10n.php`
		// de un `.mo` si la hay, así que cuenta igual.
		if ( is_readable( $mofile ) || is_readable( substr( $mofile, 0, -3 ) . '.l10n.php' ) ) {
			return $mofile;
		}

		// No existe. Si el idioma es algún español, el del plugin.
		$locale = substr( basename( $mofile, '.mo' ), strlen( self::DOMAIN ) + 1 );

		return self::is_spanish( $locale ) ? $bundled : $mofile;
	}

	/**
	 * Si un idioma de WordPress es español: `es`, o `es_` y un país.
	 *
	 * @param mixed $locale Idioma (`es_MX`, `fr_FR`…).
	 * @return bool
	 */
	public static function is_spanish( $locale ) {
		return is_string( $locale ) && 1 === preg_match( '/^es(_[A-Za-z0-9_]+)?$/', $locale );
	}
}
