<?php
/**
 * Los productos de la app móvil: lista, detalle, edición rápida y alta.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Da forma a lo que pintan la pestaña Productos y el detalle de un producto, y
 * ejecuta las escrituras: el precio, el stock y si está publicado, y crear
 * un producto simple con sus fotos (create()). Todo
 * sale listo para mostrar: los importes ya formateados con la moneda de la
 * tienda, las etiquetas en el idioma de la tienda y los nombres sin HTML. Los
 * únicos números que viajan como número guardado son `regular` y `sale`, para
 * rellenar los campos de la pantalla de precio.
 *
 * Las consultas van por `wc_get_products()` y las escrituras por los métodos
 * del producto y `save()`, así que WooCommerce hace lo de siempre: recalcula
 * el estado del stock a partir de la cantidad y sincroniza un producto
 * variable con sus variaciones. Guardar una cantidad desde aquí no manda los
 * correos de pocas existencias ni de sin existencias: en WooCommerce 11.1 solo
 * los manda un pedido que descuenta stock
 * (`wc_trigger_stock_change_notifications()`).
 *
 * Una escritura que WooCommerce desharía al guardar se rechaza: nunca se
 * contesta 200 con otra cosa guardada. Es el caso del estado de stock de una
 * variación cuyo producto controla el stock (`WC_Product::validate_props()` lo
 * recalcula con la cantidad del producto) y el de publicar un producto
 * programado (WordPress lo deja en `future` mientras su fecha no llegue).
 *
 * «Stock bajo» no tiene consulta propia: sale de
 * `APSW_App_Store::low_stock()`, la misma que alimenta la tarjeta de
 * Inicio, para que el filtro y la tarjeta cuenten lo mismo. «Agotados» sí la
 * tiene: es todo lo que WooCommerce da por agotado, controle su cantidad o
 * no, para que una fila que dice «Agotado» en «Todos» esté también ahí.
 *
 * Límites conocidos, que se dejan como están:
 *
 * - El umbral de pocas existencias es el de la tienda. El que un producto
 *   tenga puesto para él solo (`_low_stock_amount`) no se mira, ni aquí ni en
 *   Inicio: los dos usan el criterio de `APSW_App_Store::low_stock()`.
 * - Una variación publicada de un producto en borrador cuenta en Inicio y en
 *   «Stock bajo»: lo que se pide de su producto es que esté en la lista de la
 *   tienda, no que esté publicado.
 * - Un producto variable que se convirtió en simple conserva los posts de sus
 *   variaciones, y las consultas que piden variaciones los traen (no tienen
 *   tipo de producto, y WooCommerce las deja entrar por eso): pueden seguir
 *   saliendo como filas en «Stock bajo» y «Agotados». Abren ese producto, que
 *   ya no las enseña.
 *
 * Los textos que devuelve van por gettext, con el inglés de base
 * (`mosley-digital-for-woocommerce`).
 *
 * No comprueba los permisos de las rutas: eso es cosa de APSW_App_Rest.
 */
class APSW_App_Products {

	const PER_PAGE         = 20;
	const MAX_SEARCH_CHARS = 100;

	/**
	 * Caracteres que tiene como poco una búsqueda que no es un número, como en
	 * los pedidos: una letra suelta casa con media tienda.
	 */
	const MIN_SEARCH_CHARS = 2;

	/**
	 * Productos a los que llega una búsqueda por cada camino (el nombre y el
	 * SKU): 25 páginas.
	 */
	const MAX_SEARCH_RESULTS = 500;

	/** Variaciones que viajan en el detalle de un producto variable. */
	const MAX_VARIATIONS = 50;

	/** La cantidad más alta que se puede guardar desde la app. */
	const MAX_QUANTITY = 1000000;

	/** Fotos que puede llevar un producto que se crea desde la app. */
	const MAX_IMAGES = 8;

	/**
	 * La meta del producto que se creó desde la app, con el identificador del
	 * formulario del que salió: «usuario:identificador». Con ella, repetir el
	 * mismo formulario devuelve ese producto en vez de crear otro.
	 *
	 * Mientras el producto se está creando lleva detrás UNFINISHED
	 * («usuario:identificador:creating»): se escribe con el post, antes que
	 * nada más, y pasa a ser la definitiva cuando WooCommerce ha terminado de
	 * guardarlo. Un producto que la tiene así no llegó a estar hecho.
	 */
	const CLIENT_META = '_apsw_app_client_id';

	/** Lo que lleva detrás el identificador de un producto que se está creando. */
	const UNFINISHED = ':creating';

	/** Segundos que tienen que pasar para dar por abandonado un producto a medio crear: una hora. */
	const UNFINISHED_AGE = 3600;

	/**
	 * Los filtros de la lista, en el orden en que la app los enseña. Sus
	 * etiquetas, en filter_labels().
	 *
	 * @var array
	 */
	const FILTERS = array( 'all', 'publish', 'draft', 'low_stock', 'out_of_stock' );

	/** Tope del nombre de un producto, el mismo que el de una línea de pedido. */
	private const MAX_NAME_CHARS = 120;

	/** Caracteres que puede tener el nombre de un producto que se crea. */
	private const MAX_NEW_NAME_CHARS = 200;

	/** Caracteres que puede tener su descripción. */
	private const MAX_DESCRIPTION_CHARS = 5000;

	/**
	 * Segundos que un formulario queda reservado mientras se crea su producto,
	 * y veces que otra petición con el mismo formulario mira si ya está creado
	 * antes de rendirse: una cada cuarto de segundo. Ver create().
	 */
	private const CREATE_LOCK_SECONDS = 60;
	private const CREATE_WAIT_TRIES   = 20;

	/** Última página que se sirve, como en los pedidos. */
	private const MAX_PAGE = 5000;

	/**
	 * Lo que enseña «Todos»: lo mismo que la lista de productos del wp-admin,
	 * que deja fuera la papelera y los borradores automáticos.
	 */
	private const LISTED_STATUSES = APSW_App_Store::LISTED_PRODUCT_STATUSES;

	/**
	 * Estados con los que `wc_get_product()` devuelve un producto que para la
	 * app no existe: lo que está en la papelera, y el borrador que el wp-admin
	 * crea al abrir «Añadir producto» y nadie ha guardado todavía.
	 */
	private const NOT_A_PRODUCT = array( 'trash', 'auto-draft' );

	/** Estados a los que la app manda un producto. */
	private const TARGET_STATUSES = array( 'publish', 'draft' );

	/** El estado de un producto programado: se publica solo cuando llegue su fecha. */
	private const SCHEDULED = 'future';

	/** Tipos a los que la app les cambia el precio. */
	private const PRICE_TYPES = array( 'simple', 'variation', 'external' );

	/** Tipos a los que la app les cambia el stock. */
	private const STOCK_TYPES = array( 'simple', 'variation' );

	/**
	 * El producto que esta petición está creando, mientras lo crea:
	 * array( user, form, images, lock, post, done, stamped ) — de quién es, de
	 * qué formulario, con qué fotos, con qué reserva, qué post es (0 mientras
	 * no se sepa), si WooCommerce terminó de guardarlo y si su post ya salió
	 * con el identificador. null el resto del tiempo. Ver create().
	 *
	 * @var array|null
	 */
	private static $making = null;

	/**
	 * Si abandon() ya está enganchado al cierre de la petición.
	 *
	 * @var bool
	 */
	private static $watching = false;

	/**
	 * Un poco de memoria reservada mientras se crea un producto: si PHP se
	 * queda sin ella ahí, se suelta para poder deshacer lo que quedó a medias.
	 *
	 * @var string|null
	 */
	private static $reserve = null;

	/**
	 * La etiqueta de cada filtro de la lista.
	 *
	 * @return array clave => etiqueta, en el orden de FILTERS.
	 */
	public static function filter_labels() {
		return array(
			'all'          => _x( 'All', 'products filter', 'mosley-digital-for-woocommerce' ),
			'publish'      => _x( 'Published', 'products filter', 'mosley-digital-for-woocommerce' ),
			'draft'        => _x( 'Drafts', 'products filter', 'mosley-digital-for-woocommerce' ),
			'low_stock'    => _x( 'Low stock', 'products filter', 'mosley-digital-for-woocommerce' ),
			'out_of_stock' => _x( 'Out of stock', 'products filter', 'mosley-digital-for-woocommerce' ),
		);
	}

	/**
	 * La etiqueta de cada estado de un producto.
	 *
	 * @return array estado => etiqueta.
	 */
	private static function status_labels() {
		return array(
			'publish' => _x( 'Published', 'product status', 'mosley-digital-for-woocommerce' ),
			'draft'   => _x( 'Draft', 'product status', 'mosley-digital-for-woocommerce' ),
			'pending' => _x( 'Pending review', 'product status', 'mosley-digital-for-woocommerce' ),
			'private' => _x( 'Private', 'product status', 'mosley-digital-for-woocommerce' ),
			'future'  => _x( 'Scheduled', 'product status', 'mosley-digital-for-woocommerce' ),
		);
	}

	/**
	 * La etiqueta de cada tipo de producto de WooCommerce. Los de otros
	 * plugins salen con la que les dio su plugin.
	 *
	 * @return array tipo => etiqueta.
	 */
	private static function type_labels() {
		return array(
			'simple'   => _x( 'Simple', 'product type', 'mosley-digital-for-woocommerce' ),
			'variable' => _x( 'Variable', 'product type', 'mosley-digital-for-woocommerce' ),
			'external' => _x( 'External', 'product type', 'mosley-digital-for-woocommerce' ),
			'grouped'  => _x( 'Grouped', 'product type', 'mosley-digital-for-woocommerce' ),
		);
	}

	/**
	 * Lo que se puede elegir cuando no se controla la cantidad, en el orden
	 * en que la app lo enseña.
	 *
	 * @return array estado de stock => etiqueta.
	 */
	private static function stock_statuses() {
		return array(
			'instock'     => _x( 'In stock', 'stock status', 'mosley-digital-for-woocommerce' ),
			'outofstock'  => _x( 'Out of stock', 'stock status', 'mosley-digital-for-woocommerce' ),
			'onbackorder' => _x( 'On backorder', 'stock status', 'mosley-digital-for-woocommerce' ),
		);
	}

	/**
	 * La lista de productos.
	 *
	 * @param array $args array( page, search, filter ), todos opcionales.
	 * @return array|WP_Error array( products, page, has_more, filters ), o invalid_params (400).
	 */
	public function products( array $args ) {
		$page = $this->page( isset( $args['page'] ) ? $args['page'] : null );

		if ( is_wp_error( $page ) ) {
			return $page;
		}

		$filter = isset( $args['filter'] ) && '' !== $args['filter'] ? $args['filter'] : 'all';

		if ( ! is_string( $filter ) || ! in_array( $filter, self::FILTERS, true ) ) {
			return new WP_Error( 'invalid_params', __( 'That filter does not exist.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$search = $this->search_term( isset( $args['search'] ) ? $args['search'] : '' );
		$offset = ( $page - 1 ) * self::PER_PAGE;

		if ( false === $search ) {
			// Una búsqueda demasiado corta no busca: no encuentra nada.
			$found  = array( array(), false );
			$search = '';
		} elseif ( 'low_stock' === $filter ) {
			$found = $this->low_stock_rows( $search, $offset );
		} elseif ( 'out_of_stock' === $filter ) {
			$found = $this->catalog_rows( self::LISTED_STATUSES, $search, $offset, true );
		} else {
			$found = $this->catalog_rows( 'all' === $filter ? self::LISTED_STATUSES : array( $filter ), $search, $offset, false );
		}

		$filters = array();

		foreach ( self::filter_labels() as $key => $label ) {
			$filters[] = array(
				'key'   => $key,
				'label' => $label,
			);
		}

		return array(
			'products' => array_map( array( $this, 'row' ), $found[0] ),
			'page'     => $page,
			'has_more' => $found[1],
			'filters'  => $filters,
			// Lo que el formulario de «Nuevo producto» necesita saber, o
			// null si este usuario no puede crear productos. Una app anterior no
			// lo lee.
			'create'   => self::create_info(),
		);
	}

	/**
	 * Lo que la app necesita saber antes de crear un producto: la nota de
	 * impuestos de la tienda, si controla el stock, si este usuario puede
	 * publicar, los estados de stock que se pueden elegir y cuántas fotos
	 * caben.
	 *
	 * @return array|null null si el usuario no puede crear productos: le falta el permiso de editarlos o el de subir archivos.
	 */
	private static function create_info() {
		if ( ! current_user_can( 'edit_products' ) || ! current_user_can( 'upload_files' ) ) {
			return null;
		}

		$statuses = array();

		foreach ( self::stock_statuses() as $slug => $label ) {
			$statuses[] = array(
				'slug'  => $slug,
				'label' => $label,
			);
		}

		return array(
			'tax_note'         => self::tax_note(),
			'can_manage_stock' => self::store_manages_stock(),
			'can_publish'      => (bool) current_user_can( 'publish_products' ),
			'stock_statuses'   => $statuses,
			'max_images'       => self::MAX_IMAGES,
		);
	}

	/**
	 * El detalle de un producto.
	 *
	 * Una variación no tiene detalle propio: se ve dentro de su producto. Con
	 * el id de una variación sale el detalle de su producto, con el id de él:
	 * así la fila de una variación —en «Stock bajo», en «Agotados» o en la
	 * tarjeta de Inicio— abre el producto en el que se la ve. `can_edit` y
	 * `can_publish` son los de ese producto, que es el que se devuelve.
	 *
	 * @param int|string $product_id Id del producto, o de una de sus variaciones.
	 * @return array|WP_Error product_not_found (404) si no existe o está en la papelera, o si es una variación cuyo producto no existe o está en la papelera.
	 */
	public function product( $product_id ) {
		$product = $this->find( $product_id );
		$shown   = is_wp_error( $product ) ? $product : $this->shown_product( $product );

		return is_wp_error( $shown ) ? $shown : $this->detail( $shown );
	}

	/**
	 * Cambia el precio de un producto simple, de uno externo o de una variación.
	 *
	 * @param int|string $product_id Id del producto o de la variación.
	 * @param array      $params     Lo que llegó en el cuerpo: `regular` y `sale`.
	 * @return array|WP_Error El detalle actualizado (el del producto, si era una variación), o product_not_found (404) / not_editable, invalid_params, invalid_sale_price (400).
	 */
	public function set_price( $product_id, array $params ) {
		$product = $this->find( $product_id );
		$shown   = is_wp_error( $product ) ? $product : $this->shown_product( $product );

		if ( is_wp_error( $shown ) ) {
			return $shown;
		}

		$type = (string) $product->get_type();

		if ( ! in_array( $type, self::PRICE_TYPES, true ) ) {
			return new WP_Error(
				'not_editable',
				'variable' === $type ? __( 'The price of a variable product is changed in each of its variations.', 'mosley-digital-for-woocommerce' ) : __( 'The price of this type of product cannot be changed from the app.', 'mosley-digital-for-woocommerce' ),
				array( 'status' => 400 )
			);
		}

		// Sin `regular` en el cuerpo no hay nada que guardar. Vacío sí vale, y
		// deja el producto sin precio: por eso un cuerpo que no lo trae no puede
		// contar como vacío.
		if ( ! array_key_exists( 'regular', $params ) ) {
			return new WP_Error( 'invalid_params', __( 'The regular price is missing.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$prices = self::price_pair( $params['regular'], isset( $params['sale'] ) ? $params['sale'] : null, $product->get_regular_price( 'edit' ), $product->get_sale_price( 'edit' ) );

		if ( is_wp_error( $prices ) ) {
			return $prices;
		}

		list( $regular, $sale ) = $prices;

		// Lo mismo que ya hay: no se guarda, y no corre ningún gancho.
		if ( self::same_number( $regular, $product->get_regular_price( 'edit' ) ) && self::same_number( $sale, $product->get_sale_price( 'edit' ) ) ) {
			return $this->detail( $shown );
		}

		$product->set_regular_price( $regular );

		// La rebaja que se pone desde la app empieza ya y no caduca. Si el
		// producto traía fechas de rebaja —una programada para más adelante, o
		// una que caducó y dejó las suyas—, WooCommerce guardaría el precio
		// rebajado pero seguiría vendiendo al normal
		// (`WC_Product::is_on_sale()` mira las fechas, y
		// `WC_Product_Data_Store_CPT::handle_updated_props()` deja en `_price`
		// el normal): el comerciante vería su rebaja y el cliente no. Al quitar
		// la rebaja, sus fechas tampoco pintan nada. Si la rebaja no se toca,
		// sus fechas tampoco.
		if ( ! self::same_number( $sale, $product->get_sale_price( 'edit' ) ) ) {
			$product->set_sale_price( $sale );
			$product->set_date_on_sale_from( null );
			$product->set_date_on_sale_to( null );
		}

		return $this->save( array( $product ), $product, $shown );
	}

	/**
	 * Cambia el stock de un producto simple o de una variación: la cantidad,
	 * si se controla, o el estado, si no.
	 *
	 * @param int|string $product_id Id del producto o de la variación.
	 * @param array      $params     Lo que llegó en el cuerpo: `manage`, `quantity`, `expected` y `status`.
	 * @return array|WP_Error El detalle actualizado (el del producto, si era una variación), o product_not_found (404) / not_editable, invalid_params, invalid_status, stock_management_disabled (400) / stock_changed (409).
	 */
	public function set_stock( $product_id, array $params ) {
		$product = $this->find( $product_id );
		$shown   = is_wp_error( $product ) ? $product : $this->shown_product( $product );

		if ( is_wp_error( $shown ) ) {
			return $shown;
		}

		$type = (string) $product->get_type();

		if ( ! in_array( $type, self::STOCK_TYPES, true ) ) {
			if ( 'variable' === $type ) {
				$message = __( 'The stock of a variable product is changed in each of its variations.', 'mosley-digital-for-woocommerce' );
			} else {
				$message = 'external' === $type ? __( 'An external product has no stock.', 'mosley-digital-for-woocommerce' ) : __( 'The stock of this type of product cannot be changed from the app.', 'mosley-digital-for-woocommerce' );
			}

			return new WP_Error( 'not_editable', $message, array( 'status' => 400 ) );
		}

		$manage = self::flag( isset( $params['manage'] ) ? $params['manage'] : null );

		if ( null === $manage ) {
			return new WP_Error( 'invalid_params', __( 'Specify whether stock is managed.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$mode     = $this->stock_mode( $product );
		$quantity = null;
		$status   = null;

		// Si es una variación, y su producto controla el stock. Se mira el
		// ajuste del producto y no el de la tienda, que es lo que mira
		// WooCommerce al guardar.
		$parent_tracks = self::is_variation( $product ) && self::tracks_stock( $shown );

		if ( $manage ) {
			if ( ! self::store_manages_stock() ) {
				return new WP_Error( 'stock_management_disabled', __( 'Stock management is disabled in the WooCommerce settings.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}

			$quantity = self::whole( isset( $params['quantity'] ) ? $params['quantity'] : null );

			if ( null === $quantity || $quantity < 0 || $quantity > self::MAX_QUANTITY ) {
				return new WP_Error( 'invalid_params', __( 'The quantity must be a whole number between 0 and 1,000,000.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}
		} else {
			// Una variación no puede dejar de controlar el stock, ni tener un
			// estado puesto a mano, mientras su producto lo controle: en cuanto
			// no lo controla ella, hereda el de él
			// (`WC_Product_Variation::get_manage_stock()` contesta 'parent'), y
			// al guardar WooCommerce recalcula su estado con la cantidad del
			// producto (`WC_Product::validate_props()`). El estado pedido no
			// quedaría guardado, y el siguiente cambio de cantidad caería en el
			// producto, que es el de todas sus variaciones. Vale igual para la
			// que ya lo hereda y para la que tiene su propia cantidad.
			if ( $parent_tracks ) {
				return new WP_Error( 'not_editable', __( 'This variation cannot stop managing stock while its product manages it: it would take the stock of the product. Change it in the product, from the WordPress dashboard.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}

			$status = isset( $params['status'] ) ? $params['status'] : null;

			if ( ! is_string( $status ) || ! isset( self::stock_statuses()[ $status ] ) ) {
				return new WP_Error( 'invalid_status', __( 'That stock status does not exist.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}
		}

		$expected = null;

		if ( isset( $params['expected'] ) ) {
			$expected = self::whole( $params['expected'] );

			if ( null === $expected ) {
				return new WP_Error( 'invalid_params', __( 'The quantity the screen was showing is not valid.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}
		}

		// La cantidad que la pantalla mostraba tiene que ser la de la tienda: si
		// entró una venta mientras se editaba, no se pisa. Al guardar una
		// cantidad se compara siempre, también si la pantalla no mostraba
		// ninguna; al dejar de controlarla, solo si mostraba alguna. Un producto
		// que no controla su cantidad no tiene ninguna que pisar.
		$current = 'none' === $mode ? null : self::quantity( $product );

		if ( null !== $current && ( $manage || null !== $expected ) && $expected !== $current ) {
			return new WP_Error(
				'stock_changed',
				/* translators: %d: current stock quantity of the product. */
				sprintf( __( 'The stock changed while you were editing it: there are now %d.', 'mosley-digital-for-woocommerce' ), $current ),
				array(
					'status'   => 409,
					'quantity' => $current,
				)
			);
		}

		if ( $manage ) {
			// Lo mismo que ya hay: no se guarda.
			if ( $quantity === $current ) {
				return $this->detail( $shown );
			}

			// La cantidad que comparten las variaciones es la de su producto.
			$owner = 'parent' === $mode ? $shown : $product;

			$owner->set_manage_stock( true );
			$owner->set_stock_quantity( $quantity );

			return $this->save( array( $owner ), $product, $shown );
		}

		// Lo mismo que ya hay: no se guarda. Se mira el ajuste del propio
		// producto y no el de la tienda: con el control de stock desactivado en
		// la tienda, un producto que lo tiene activado seguiría sacando su
		// estado de su cantidad la próxima vez que se guarde.
		if ( ! self::tracks_stock( $product ) && $status === (string) $product->get_stock_status() ) {
			return $this->detail( $shown );
		}

		$product->set_manage_stock( false );
		$product->set_stock_status( $status );

		return $this->save( array( $product ), $product, $shown );
	}

	/**
	 * Publica un producto o lo pasa a borrador.
	 *
	 * @param int|string $product_id Id del producto.
	 * @param mixed      $status     `publish` o `draft`.
	 * @return array|WP_Error El detalle actualizado, o product_not_found (404) / not_editable, invalid_status (400).
	 */
	public function set_status( $product_id, $status ) {
		$product = $this->find( $product_id );

		if ( is_wp_error( $product ) ) {
			return $product;
		}

		if ( self::is_variation( $product ) ) {
			return new WP_Error( 'not_editable', __( 'A variation is not published on its own: its product is.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( ! is_string( $status ) || ! in_array( $status, self::TARGET_STATUSES, true ) ) {
			return new WP_Error( 'invalid_status', __( 'A product can only be published or moved to draft.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		// Un producto programado no se publica con decirlo: mientras su fecha
		// no llegue, WordPress vuelve a dejarlo en `future`
		// (`wp_insert_post()`), y la respuesta diría que sí con el producto
		// igual que estaba. Su estado depende de su fecha, y la fecha no se
		// cambia desde la app.
		if ( self::SCHEDULED === (string) $product->get_status() ) {
			return new WP_Error( 'not_editable', __( 'This product is scheduled: it will be published automatically on its date. Change the date in the WordPress dashboard.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		// Ya está en ese estado: una repetición no vuelve a guardar.
		if ( $status === (string) $product->get_status() ) {
			return $this->detail( $product );
		}

		$product->set_status( $status );

		return $this->save( array( $product ), $product, $product );
	}

	/**
	 * Crea un producto simple, publicado o en borrador, con sus fotos.
	 *
	 * El producto sale como lo dejaría WooCommerce al crearlo en el wp-admin
	 * con solo estos campos: se crea con `WC_Product_Simple` y su `save()`, así
	 * que el almacén de WooCommerce le pone lo de siempre
	 * (`WC_Product_Data_Store_CPT::create()`): la categoría por defecto de la
	 * tienda, visible en el catálogo, sujeto a impuestos con la clase estándar,
	 * sin clase de envío, con las reseñas abiertas, su precio vigente
	 * (`_price`), sus términos de visibilidad y su fila en la tabla de
	 * consulta de productos. Y dispara los ganchos de un producto nuevo.
	 *
	 * **El formulario.** Cada formulario de la app lleva un identificador
	 * propio (`client_id`). Si este usuario ya creó un producto con él, se
	 * devuelve ese y no se crea otro: cuando la app no llega a saber si el
	 * producto se guardó —se corta la red—, el comerciante puede volver a
	 * pulsar. Lo demás que traiga esa repetición no se mira: el producto es el
	 * que se creó la primera vez.
	 *
	 * Dos peticiones con el mismo identificador pueden llegar casi a la vez
	 * —la primera sigue en marcha cuando el comerciante vuelve a pulsar—, y las
	 * dos verían que el producto aún no existe. Por eso crear reserva el
	 * identificador mientras dura (lock()): la segunda espera unos segundos a
	 * que la primera termine y devuelve su producto; si no termina, contesta
	 * que se vuelva a intentar.
	 *
	 * **Las fotos.** Dos formularios distintos pueden llegar a la vez con la
	 * misma foto. Antes de crear nada, el formulario se queda con las suyas
	 * (`APSW_App_Uploads::claim()`), y de cada foto solo se la queda uno: el
	 * que pierde contesta `invalid_image` y no crea nada.
	 *
	 * **Los textos.** El nombre y la descripción llegan como texto llano y se
	 * guardan como texto llano: WordPress trata esos dos campos como HTML, así
	 * que los signos que en HTML significan algo se guardan escritos como
	 * entidades (stored_text()), y la tienda enseña lo que el comerciante
	 * escribió. La descripción conserva sus saltos de línea. Y las barras
	 * invertidas («C:\tienda»): `wp_insert_post()` cuenta con que lo que
	 * recibe trae las barras escapadas y se las quita (`wp_unslash()`), y el
	 * almacén de WooCommerce le pasa el nombre y la descripción tal cual. Se
	 * las pone new_product_data(), justo antes, y solo a lo que va a
	 * `wp_insert_post()`: el producto que ven los demás plugins lleva los
	 * textos como son.
	 *
	 * **Si algo falla a medias.** Guardar un producto son muchas escrituras
	 * —el post, sus metas, sus términos— con los ganchos de los demás plugins
	 * por medio, y cualquiera puede lanzar una excepción o acabar con la
	 * petición. Para que no quede un producto a medias, ni dos:
	 *
	 * - El identificador del formulario se escribe **con el post**
	 *   (`meta_input`, lo primero que `wp_insert_post()` hace tras insertarlo),
	 *   con UNFINISHED detrás. En cuanto el post existe, se le puede encontrar.
	 * - Cuando WooCommerce ha terminado de guardarlo avisa
	 *   (`woocommerce_new_product`), y el primero en enterarse es
	 *   product_saved(), que deja el identificador definitivo. Desde ahí el
	 *   producto está hecho, pase lo que pase en los ganchos que vienen detrás.
	 * - Si save() lanza una excepción, se mira hasta dónde llegó (settle()):
	 *   con el producto hecho, se termina lo de aquí —sus fotos— y se contesta
	 *   que se creó; sin hacer, se borra lo que hubiera, se sueltan las fotos y
	 *   se contesta el error.
	 * - Si PHP se muere, o un plugin corta la petición con `exit`, eso mismo lo
	 *   hace abandon() al cerrarla.
	 * - Si ni eso llega a correr —al proceso lo matan—, queda un producto con
	 *   el identificador sin terminar. El mismo formulario, al repetirse, lo
	 *   borra y lo crea de nuevo; si no se repite, sweep() lo deja en borrador.
	 *
	 * Nada se guarda si algo no vale: todo se comprueba antes de crear.
	 *
	 * @param array $params Lo que llegó en el cuerpo: `client_id`, `name`, `regular`, `sale`, `description`, `manage`, `quantity`, `stock_status`, `status` e `images`.
	 * @return array|WP_Error array( created, product ): si se creó ahora, y su detalle. O invalid_params, invalid_image, invalid_sale_price, invalid_status, stock_management_disabled (400) / cannot_publish (403) / product_not_found (404) / product_being_created (409) / product_create_failed (500).
	 */
	public function create( array $params ) {
		$user_id   = (int) get_current_user_id();
		$client_id = self::client_id( isset( $params['client_id'] ) ? $params['client_id'] : null );

		if ( null === $client_id || $user_id < 1 ) {
			return new WP_Error( 'invalid_params', __( 'The form could not be identified. Close it and open it again.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$existing = self::created_with( $user_id, $client_id );

		if ( $existing > 0 ) {
			return $this->found( $existing, $user_id, $client_id );
		}

		$name = self::plain_line( isset( $params['name'] ) ? $params['name'] : null );

		if ( null === $name || '' === $name ) {
			return new WP_Error( 'invalid_params', __( 'The product needs a name.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( mb_strlen( $name ) > self::MAX_NEW_NAME_CHARS ) {
			/* translators: %d: maximum number of characters of a product name. */
			return new WP_Error( 'invalid_params', sprintf( __( 'The name is too long: %d characters at most.', 'mosley-digital-for-woocommerce' ), self::MAX_NEW_NAME_CHARS ), array( 'status' => 400 ) );
		}

		$status = isset( $params['status'] ) ? $params['status'] : null;

		if ( ! is_string( $status ) || ! in_array( $status, self::TARGET_STATUSES, true ) ) {
			return new WP_Error( 'invalid_status', __( 'A product is saved as published or as a draft.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		// Publicar pide además el permiso de publicar productos, como al
		// publicar uno que ya existe. En borrador lo puede dejar igual, y por
		// eso el error lleva su propio código y no el `rest_forbidden` de quien
		// no puede usar la ruta: la app enseña el mensaje y deja el formulario
		// como está, para que el comerciante lo guarde como borrador.
		if ( 'publish' === $status && ! current_user_can( 'publish_products' ) ) {
			return new WP_Error( 'cannot_publish', __( 'You are not allowed to publish products. Save it as a draft.', 'mosley-digital-for-woocommerce' ), array( 'status' => 403 ) );
		}

		// Las reglas del precio de un producto que ya existe, con una
		// diferencia: aquí no hay ningún precio guardado que respetar, así que
		// los dos son nuevos y los dos pasan por la de los decimales.
		$prices = self::price_pair( isset( $params['regular'] ) ? $params['regular'] : null, isset( $params['sale'] ) ? $params['sale'] : null, '', '' );

		if ( is_wp_error( $prices ) ) {
			return $prices;
		}

		// Las reglas del stock, sin la cantidad que la pantalla mostraba: un
		// producto nuevo no tiene ninguna. Sin `manage`, lo que WooCommerce le
		// pone a un producto nuevo: no controla la cantidad, y hay existencias.
		$manage   = isset( $params['manage'] ) ? self::flag( $params['manage'] ) : false;
		$quantity = null;
		$stock    = 'instock';

		if ( null === $manage ) {
			return new WP_Error( 'invalid_params', __( 'Specify whether stock is managed.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( $manage ) {
			if ( ! self::store_manages_stock() ) {
				return new WP_Error( 'stock_management_disabled', __( 'Stock management is disabled in the WooCommerce settings.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}

			$quantity = self::whole( isset( $params['quantity'] ) ? $params['quantity'] : null );

			if ( null === $quantity || $quantity < 0 || $quantity > self::MAX_QUANTITY ) {
				return new WP_Error( 'invalid_params', __( 'The quantity must be a whole number between 0 and 1,000,000.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}
		} elseif ( isset( $params['stock_status'] ) ) {
			$stock = $params['stock_status'];

			if ( ! is_string( $stock ) || ! isset( self::stock_statuses()[ $stock ] ) ) {
				return new WP_Error( 'invalid_status', __( 'That stock status does not exist.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
			}
		}

		$description = self::plain_text( isset( $params['description'] ) ? $params['description'] : '' );

		if ( null === $description || mb_strlen( $description ) > self::MAX_DESCRIPTION_CHARS ) {
			/* translators: %s: maximum number of characters of a product description, already formatted: "5,000". */
			return new WP_Error( 'invalid_params', sprintf( __( 'The description is too long: %s characters at most.', 'mosley-digital-for-woocommerce' ), number_format_i18n( self::MAX_DESCRIPTION_CHARS ) ), array( 'status' => 400 ) );
		}

		$images = self::new_images( isset( $params['images'] ) ? $params['images'] : array(), $user_id, $client_id );

		if ( is_wp_error( $images ) ) {
			return $images;
		}

		if ( ! class_exists( 'WC_Product_Simple' ) ) {
			return self::not_created();
		}

		$lock = 'apsw_app_creating_' . md5( $user_id . ':' . $client_id );

		if ( ! self::lock( $lock ) ) {
			return $this->wait_for( $user_id, $client_id );
		}

		// Con el identificador ya reservado se mira otra vez: otra petición pudo
		// crear el producto entre la primera mirada y la reserva.
		$existing = self::created_with( $user_id, $client_id );

		if ( $existing > 0 ) {
			self::unlock( $lock );

			return $this->found( $existing, $user_id, $client_id );
		}

		// Lo que dejó a medias una petición que se murió creando este mismo
		// formulario: con la reserva en la mano ya no la tiene nadie. Se quita,
		// y el producto se crea de nuevo.
		foreach ( self::half_made( $user_id, $client_id ) as $half ) {
			wp_delete_post( $half, true );
		}

		if ( ! APSW_App_Uploads::claim( $images, $user_id, $client_id ) ) {
			self::unlock( $lock );

			return self::photo_gone();
		}

		self::$making = array(
			'user'    => $user_id,
			'form'    => $client_id,
			'images'  => $images,
			'lock'    => $lock,
			'post'    => 0,
			'done'    => false,
			'stamped' => false,
		);

		self::watch();

		$threw = false;
		$saved = 0;

		add_filter( 'woocommerce_new_product_data', array( __CLASS__, 'new_product_data' ), PHP_INT_MAX );
		add_filter( 'pre_wp_unique_post_slug', array( __CLASS__, 'product_inserted' ), PHP_INT_MIN, 5 );
		add_action( 'woocommerce_new_product', array( __CLASS__, 'product_saved' ), PHP_INT_MIN );

		try {
			$product = new WC_Product_Simple();

			$product->set_name( self::stored_text( $name ) );
			$product->set_status( $status );
			$product->set_description( self::stored_text( $description ) );
			$product->set_regular_price( $prices[0] );
			$product->set_sale_price( $prices[1] );
			$product->set_manage_stock( $manage );

			if ( $manage ) {
				$product->set_stock_quantity( $quantity );
			} else {
				$product->set_stock_status( $stock );
			}

			if ( $images ) {
				$product->set_image_id( $images[0] );
				$product->set_gallery_image_ids( array_slice( $images, 1 ) );
			}

			$product->save();

			$saved = (int) $product->get_id();
		} catch ( Throwable $error ) {
			$threw = true;
			$saved = isset( $product ) && is_object( $product ) ? (int) $product->get_id() : 0;
		} finally {
			remove_filter( 'woocommerce_new_product_data', array( __CLASS__, 'new_product_data' ), PHP_INT_MAX );
			remove_filter( 'pre_wp_unique_post_slug', array( __CLASS__, 'product_inserted' ), PHP_INT_MIN );
			remove_filter( 'woocommerce_new_product', array( __CLASS__, 'product_saved' ), PHP_INT_MIN );
		}

		return $this->settle( $saved, $threw );
	}

	/**
	 * Lo que queda por hacer cuando save() ha vuelto, bien o con una
	 * excepción: terminar lo de aquí si el producto está hecho, o deshacerlo
	 * si no.
	 *
	 * Está hecho si WooCommerce avisó de que lo guardó (product_saved()). Un
	 * almacén de productos que no sea el de WooCommerce puede no avisar: si
	 * save() volvió sin excepción y con un id, también lo está.
	 *
	 * @param int  $saved El id que save() le dejó al producto, o 0.
	 * @param bool $threw Si save() lanzó una excepción.
	 * @return array|WP_Error
	 */
	private function settle( $saved, $threw ) {
		$state = self::$making;

		if ( null === $state ) {
			return self::not_created();
		}

		$product_id = $state['done'] ? (int) $state['post'] : 0;

		if ( $product_id < 1 && ! $threw && $saved > 0 && self::finish( $saved, $state['user'], $state['form'] ) ) {
			$product_id = $saved;
		}

		if ( $product_id < 1 ) {
			if ( $saved > 0 && $state['post'] < 1 ) {
				self::$making['post'] = $saved;
			}

			self::abandon();

			return self::not_created();
		}

		// Las fotos dejan de estar pendientes y quedan adjuntas al producto.
		APSW_App_Uploads::attach( $state['images'], $product_id );

		self::$making  = null;
		self::$reserve = null;

		self::unlock( $state['lock'] );

		return $this->created( $product_id, true );
	}

	/**
	 * Deja como estaba lo que una creación no terminó, o termina lo que le
	 * faltaba si el producto ya estaba hecho. La llama settle() cuando save()
	 * falla, y WordPress al cerrar la petición (`shutdown`), que es lo único
	 * que corre cuando PHP se muere —sin memoria, sin tiempo— o cuando otro
	 * plugin corta la petición con `exit` en mitad de guardar.
	 *
	 * - Con el producto hecho, lo que falta es de aquí: sus fotos quedan
	 *   adjuntas. Quien repita el formulario recibirá ese producto.
	 * - Sin hacer, se borra el post que hubiera —un producto publicado sin
	 *   precio ni stock no se queda en la tienda— y se sueltan las fotos.
	 *
	 * Y suelta la reserva del formulario.
	 *
	 * @return void
	 */
	public static function abandon() {
		if ( null === self::$making ) {
			return;
		}

		$state = self::$making;

		self::$making  = null;
		self::$reserve = null;

		if ( $state['done'] ) {
			APSW_App_Uploads::attach( $state['images'], (int) $state['post'] );
		} else {
			$unfinished = $state['user'] . ':' . $state['form'] . self::UNFINISHED;
			$half       = self::half_made( $state['user'], $state['form'] );

			if ( $state['post'] > 0 ) {
				$half[] = (int) $state['post'];
			}

			foreach ( array_unique( $half ) as $post_id ) {
				// Solo un producto, y solo si no lleva el identificador de nadie
				// más: sin él —no llegó a escribirse— o con el de esta creación.
				if ( 'product' === get_post_type( $post_id ) && in_array( get_post_meta( $post_id, self::CLIENT_META, true ), array( '', $unfinished ), true ) ) {
					wp_delete_post( $post_id, true );
				}
			}

			APSW_App_Uploads::release( $state['images'], $state['user'], $state['form'] );
		}

		self::unlock( $state['lock'] );
	}

	/**
	 * Lo que el almacén de WooCommerce le va a pasar a `wp_insert_post()` para
	 * crear el producto (filtro `woocommerce_new_product_data`,
	 * class-wc-product-data-store-cpt.php), con dos cambios:
	 *
	 * - El título y el contenido, con las barras invertidas escapadas, como
	 *   `wp_insert_post()` los espera: les quita el escape antes de guardar
	 *   (`wp_unslash()`), y sin esto se llevaría las barras del texto.
	 * - El identificador del formulario, sin terminar, en `meta_input`:
	 *   `wp_insert_post()` lo escribe nada más insertar el post.
	 *
	 * Va el último de los filtros, para escapar lo que quede después de los
	 * demás, y solo una vez: el primer producto que se crea tras empezar es el
	 * de aquí; si un gancho crea otro por su cuenta, no es de este formulario.
	 *
	 * @param mixed $data Los campos del post.
	 * @return mixed
	 */
	public static function new_product_data( $data ) {
		if ( null === self::$making || self::$making['stamped'] || ! is_array( $data ) ) {
			return $data;
		}

		self::$making['stamped'] = true;

		foreach ( array( 'post_title', 'post_content' ) as $field ) {
			if ( isset( $data[ $field ] ) && is_string( $data[ $field ] ) ) {
				$data[ $field ] = wp_slash( $data[ $field ] );
			}
		}

		$meta                      = isset( $data['meta_input'] ) && is_array( $data['meta_input'] ) ? $data['meta_input'] : array();
		$meta[ self::CLIENT_META ] = self::$making['user'] . ':' . self::$making['form'] . self::UNFINISHED;
		$data['meta_input']        = $meta;

		return $data;
	}

	/**
	 * Apunta el id del post del producto en cuanto existe.
	 *
	 * Al insertar un post que no es un borrador, lo primero que hace
	 * `wp_insert_post()` después del `INSERT` es buscarle una dirección
	 * (`wp_unique_post_slug()`), y este es su primer filtro: se entera antes
	 * que ningún otro plugin, y antes incluso de que se escriba el
	 * identificador. Si algo falla justo ahí, abandon() sabe qué post borrar.
	 * No cambia nada: devuelve lo que recibe.
	 *
	 * @param mixed  $override    Lo que el filtro trae: null si nadie decidió la dirección.
	 * @param string $slug        La dirección que se quiere.
	 * @param int    $post_id     Id del post.
	 * @param string $post_status Su estado.
	 * @param string $post_type   Su tipo.
	 * @return mixed
	 */
	public static function product_inserted( $override, $slug = '', $post_id = 0, $post_status = '', $post_type = '' ) {
		if ( null !== self::$making && self::$making['stamped'] && self::$making['post'] < 1 && 'product' === $post_type && (int) $post_id > 0 ) {
			self::$making['post'] = (int) $post_id;
		}

		return $override;
	}

	/**
	 * WooCommerce avisa de que ha terminado de guardar un producto nuevo
	 * (`woocommerce_new_product`, lo último de
	 * `WC_Product_Data_Store_CPT::create()`): si es el de esta creación, su
	 * identificador pasa a ser el definitivo.
	 *
	 * Va el primero: lo que hagan —o rompan— los ganchos que vienen detrás ya
	 * no cambia que el producto está hecho.
	 *
	 * @param int $product_id Id del producto.
	 * @return void
	 */
	public static function product_saved( $product_id ) {
		if ( null === self::$making || self::$making['done'] ) {
			return;
		}

		$product_id = (int) $product_id;

		if ( $product_id < 1 || get_post_meta( $product_id, self::CLIENT_META, true ) !== self::$making['user'] . ':' . self::$making['form'] . self::UNFINISHED ) {
			return;
		}

		if ( self::finish( $product_id, self::$making['user'], self::$making['form'] ) ) {
			self::$making['post'] = $product_id;
			self::$making['done'] = true;
		}
	}

	/**
	 * Deja en borrador los productos a medio crear que nadie terminó: la
	 * petición que los creaba murió sin poder deshacerlos, y el formulario no
	 * se repitió. Les quita además el identificador: quedan como un borrador
	 * cualquiera, que el comerciante puede completar o borrar.
	 *
	 * Corre con la limpieza de las fotos. Solo toca productos que llevan el
	 * identificador sin terminar desde hace más de una hora (UNFINISHED_AGE),
	 * que es mucho más de lo que dura crear uno. No borra nada.
	 *
	 * @return int Cuántos dejó en borrador o sin identificador.
	 */
	public static function sweep() {
		$ids = get_posts(
			array(
				'post_type'              => 'product',
				'post_status'            => array( 'publish', 'future', 'pending', 'private', 'draft' ),
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Finding the products whose creation never finished is the purpose of this query; it returns a handful of rows and runs with the daily cleanup.
				'meta_key'               => self::CLIENT_META,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- See above.
				'meta_value'             => self::UNFINISHED,
				'meta_compare'           => 'LIKE',
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'posts_per_page'         => 20,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'cache_results'          => false,
				'update_post_term_cache' => false,
			)
		);
		$swept  = 0;
		$cutoff = time() - self::UNFINISHED_AGE;

		foreach ( is_array( $ids ) ? $ids : array() as $product_id ) {
			$product_id = (int) $product_id;
			$mark       = get_post_meta( $product_id, self::CLIENT_META, true );
			$created    = strtotime( (string) get_post_field( 'post_date_gmt', $product_id ) . ' UTC' );

			if ( ! is_string( $mark ) || 1 !== preg_match( '/\A\d{1,18}:[0-9a-f-]{36}' . preg_quote( self::UNFINISHED, '/' ) . '\z/', $mark ) || false === $created || $created > $cutoff ) {
				continue;
			}

			if ( 'draft' !== get_post_status( $product_id ) ) {
				wp_update_post(
					array(
						'ID'          => $product_id,
						'post_status' => 'draft',
					)
				);
			}

			delete_post_meta( $product_id, self::CLIENT_META, $mark );

			++$swept;
		}

		return $swept;
	}

	/**
	 * Lo que contesta un formulario que ya creó su producto: ese producto.
	 *
	 * Antes, termina lo que la primera petición pudo dejar sin hacer si se
	 * murió con el producto ya guardado: las fotos que el formulario tenía
	 * para él y que no llegaron a quedar adjuntas.
	 *
	 * @param int    $product_id Id del producto.
	 * @param int    $user_id    Id del usuario.
	 * @param string $client_id  Identificador del formulario.
	 * @return array|WP_Error
	 */
	private function found( $product_id, $user_id, $client_id ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;

		if ( self::is_product( $product ) ) {
			$images  = array_merge( array( (int) $product->get_image_id( 'edit' ) ), array_map( 'intval', (array) $product->get_gallery_image_ids( 'edit' ) ) );
			$waiting = APSW_App_Uploads::claimed( array_filter( $images ), $user_id, $client_id );

			if ( $waiting ) {
				APSW_App_Uploads::attach( $waiting, $product_id );
			}
		}

		return $this->created( $product_id, false );
	}

	/**
	 * Vigila la creación en marcha: si la petición se acaba sin terminarla,
	 * abandon() deshace lo que quedó. En el gancho `shutdown` de WordPress, que
	 * corre también tras un error fatal o un `exit`, y antes de que WordPress
	 * cierre su caché de objetos.
	 *
	 * @return void
	 */
	private static function watch() {
		self::$reserve = str_repeat( ' ', 1048576 );

		if ( ! self::$watching ) {
			self::$watching = true;

			add_action( 'shutdown', array( __CLASS__, 'abandon' ), 0 );
		}
	}

	/**
	 * Deja el identificador definitivo en un producto que WooCommerce terminó
	 * de guardar.
	 *
	 * Es un solo `UPDATE` que solo vale si el identificador sigue sin terminar
	 * (`update_post_meta()` con el valor anterior). Si no había ninguno —un
	 * almacén de productos que no pasó por `wp_insert_post()` con el filtro—,
	 * WordPress lo añade: vale si el producto existe.
	 *
	 * @param int    $product_id Id del producto.
	 * @param int    $user_id    Id del usuario.
	 * @param string $client_id  Identificador del formulario.
	 * @return bool Si el producto queda con el identificador definitivo.
	 */
	private static function finish( $product_id, $user_id, $client_id ) {
		$final = $user_id . ':' . $client_id;
		$done  = update_post_meta( $product_id, self::CLIENT_META, $final, $final . self::UNFINISHED );

		if ( true === $done ) {
			return true;
		}

		if ( is_int( $done ) && $done > 0 ) {
			if ( 'product' === get_post_type( $product_id ) ) {
				return true;
			}

			delete_metadata_by_mid( 'post', $done );

			return false;
		}

		return $final === get_post_meta( $product_id, self::CLIENT_META, true );
	}

	/**
	 * Lo que create() devuelve de un producto: si se creó ahora, y su detalle,
	 * leído otra vez. Al guardar, WooCommerce recalcula lo que depende de lo
	 * que se le puso (el estado del stock a partir de la cantidad, el precio
	 * vigente), y con su caché de instancias encendida un producto nuevo no
	 * está en ella: `wc_get_product()` lo lee de lo guardado.
	 *
	 * @param int  $product_id Id del producto.
	 * @param bool $created    Si se acaba de crear.
	 * @return array|WP_Error product_not_found (404) si ya no existe: quien repite un formulario cuyo producto se mandó a la papelera.
	 */
	private function created( $product_id, $created ) {
		$detail = $this->product( (int) $product_id );

		if ( is_wp_error( $detail ) ) {
			return $detail;
		}

		return array(
			'created' => (bool) $created,
			'product' => $detail,
		);
	}

	/**
	 * Lo que contesta la petición que llega mientras otra, con el mismo
	 * formulario, está creando el producto: espera a que termine y devuelve su
	 * producto. Si en unos segundos no ha terminado, que se vuelva a intentar.
	 *
	 * @param int    $user_id   Id del usuario.
	 * @param string $client_id Identificador del formulario.
	 * @return array|WP_Error
	 */
	private function wait_for( $user_id, $client_id ) {
		for ( $try = 0; $try < self::CREATE_WAIT_TRIES; $try++ ) {
			$this->pause();

			$existing = self::created_with( $user_id, $client_id );

			if ( $existing > 0 ) {
				return $this->found( $existing, $user_id, $client_id );
			}
		}

		return new WP_Error( 'product_being_created', __( 'This product is still being saved. Try again in a moment.', 'mosley-digital-for-woocommerce' ), array( 'status' => 409 ) );
	}

	/**
	 * Un cuarto de segundo de espera entre dos miradas de wait_for().
	 *
	 * @return void
	 */
	protected function pause() {
		usleep( 250000 );
	}

	/**
	 * El producto que un usuario creó con un formulario, si lo hay.
	 *
	 * Se busca también entre los que están en la papelera: ese formulario ya
	 * creó su producto, y repetirlo no crea otro.
	 *
	 * Solo el que está hecho: el que otra petición todavía está creando, o
	 * dejó a medias, lleva el identificador sin terminar (half_made()).
	 *
	 * La consulta no se guarda en ninguna caché: wait_for() la repite mientras
	 * otra petición crea el producto, y tiene que verlo en cuanto esté.
	 *
	 * @param int    $user_id   Id del usuario.
	 * @param string $client_id Identificador del formulario.
	 * @return int Id del producto, o 0.
	 */
	private static function created_with( $user_id, $client_id ) {
		$ids = self::with_mark( $user_id . ':' . $client_id, 1 );

		return $ids ? $ids[0] : 0;
	}

	/**
	 * Los productos que un formulario dejó a medio crear: los que llevan su
	 * identificador sin terminar.
	 *
	 * @param int    $user_id   Id del usuario.
	 * @param string $client_id Identificador del formulario.
	 * @return int[]
	 */
	private static function half_made( $user_id, $client_id ) {
		return self::with_mark( $user_id . ':' . $client_id . self::UNFINISHED, 5 );
	}

	/**
	 * Los productos que llevan un identificador de formulario, en cualquier
	 * estado, los más antiguos primero.
	 *
	 * @param string $mark  El valor de la meta.
	 * @param int    $limit Cuántos, como mucho.
	 * @return int[]
	 */
	private static function with_mark( $mark, $limit ) {
		$ids = get_posts(
			array(
				'post_type'              => 'product',
				'post_status'            => array_merge( self::LISTED_STATUSES, self::NOT_A_PRODUCT ),
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Finding the product a form already created is the purpose of this query; it returns a row or two and runs only when a product is created.
				'meta_key'               => self::CLIENT_META,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- See above.
				'meta_value'             => $mark,
				'orderby'                => 'ID',
				'order'                  => 'ASC',
				'posts_per_page'         => (int) $limit,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'cache_results'          => false,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return is_array( $ids ) ? array_values( array_map( 'intval', $ids ) ) : array();
	}

	/**
	 * Reserva un formulario mientras se crea su producto.
	 *
	 * Con una caché de objetos externa (Redis, Memcached), `wp_cache_add()`
	 * solo guarda si no había nada: es la reserva. Sin ella, un transient:
	 * guardarlo es un `INSERT` en la tabla de opciones, y de dos peticiones que
	 * lo intentan a la vez con el mismo valor solo una lo consigue
	 * (`add_option()` devuelve false a la que no inserta nada). Caduca sola al
	 * minuto, por si la petición que la tenía se murió sin soltarla.
	 *
	 * @param string $key Nombre de la reserva.
	 * @return bool Si se consiguió.
	 */
	private static function lock( $key ) {
		if ( wp_using_ext_object_cache() ) {
			return (bool) wp_cache_add( $key, 1, 'apsw_app', self::CREATE_LOCK_SECONDS );
		}

		if ( false !== get_transient( $key ) ) {
			return false;
		}

		return (bool) set_transient( $key, '1', self::CREATE_LOCK_SECONDS );
	}

	/**
	 * Suelta la reserva de un formulario.
	 *
	 * @param string $key Nombre de la reserva.
	 * @return void
	 */
	private static function unlock( $key ) {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_delete( $key, 'apsw_app' );
		} else {
			delete_transient( $key );
		}
	}

	/**
	 * El identificador de un formulario de la app: un UUID, en minúsculas.
	 *
	 * @param mixed $value Lo que llegó en `client_id`.
	 * @return string|null null si no lo es.
	 */
	private static function client_id( $value ) {
		return is_string( $value ) && 1 === preg_match( '/\A[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\z/i', $value ) ? strtolower( $value ) : null;
	}

	/**
	 * Las fotos de un producto nuevo, en su orden: la primera es la imagen
	 * destacada y las demás, la galería.
	 *
	 * Cada una tiene que ser una foto que este usuario subió desde la app y
	 * que todavía no es de ningún producto (APSW_App_Uploads): ni una imagen
	 * cualquiera de la biblioteca, ni la de otro usuario, ni una que ya se
	 * usó.
	 *
	 * Aquí solo se mira: quedárselas es lo siguiente (create()).
	 *
	 * @param mixed  $images    Lo que llegó en `images`.
	 * @param int    $user_id   Id del usuario.
	 * @param string $client_id Identificador del formulario.
	 * @return int[]|WP_Error invalid_params (400) si no es una lista o trae más de MAX_IMAGES; invalid_image (400) si alguna no vale.
	 */
	private static function new_images( $images, $user_id, $client_id ) {
		if ( null === $images ) {
			return array();
		}

		if ( ! is_array( $images ) || count( $images ) > self::MAX_IMAGES ) {
			/* translators: %d: maximum number of photos of a product. */
			return new WP_Error( 'invalid_params', sprintf( __( 'A product can have %d photos at most.', 'mosley-digital-for-woocommerce' ), self::MAX_IMAGES ), array( 'status' => 400 ) );
		}

		$ids = array();

		foreach ( $images as $image ) {
			$id = self::whole( $image );

			if ( null === $id || $id < 1 || ! APSW_App_Uploads::is_pending_of( $id, $user_id, $client_id ) ) {
				return self::photo_gone();
			}

			if ( ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}

		return $ids;
	}

	/**
	 * Un texto de una línea que llega de la app: sin saltos de línea ni
	 * caracteres de control, con los espacios seguidos en uno y sin los de los
	 * lados.
	 *
	 * @param mixed $value Lo que llegó.
	 * @return string|null null si no es un texto, o no es UTF-8 válido.
	 */
	private static function plain_line( $value ) {
		if ( ! is_string( $value ) || 1 !== preg_match( '//u', $value ) ) {
			return null;
		}

		return trim( (string) preg_replace( '/[\s\x{00A0}]+/u', ' ', (string) preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value ) ) );
	}

	/**
	 * Un texto de varias líneas que llega de la app: con sus saltos de línea,
	 * escritos todos igual, sin caracteres de control y sin los espacios de
	 * los lados.
	 *
	 * @param mixed $value Lo que llegó; null es que no hay texto.
	 * @return string|null null si no es un texto, o no es UTF-8 válido.
	 */
	private static function plain_text( $value ) {
		if ( null === $value ) {
			return '';
		}

		if ( ! is_string( $value ) || 1 !== preg_match( '//u', $value ) ) {
			return null;
		}

		$text = str_replace( array( "\r\n", "\r" ), "\n", $value );

		return trim( (string) preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text ) );
	}

	/**
	 * Un texto llano, como se guarda en un campo que WordPress trata como
	 * HTML —el título y el contenido de un post—: con `&`, `<` y `>` escritos
	 * como entidades. Así «Mesa <1 m» o «Tom & Jerry» se guardan y se enseñan
	 * tal cual, y lo que parezca una etiqueta no lo es.
	 *
	 * @param string $text Texto llano.
	 * @return string
	 */
	private static function stored_text( $text ) {
		return str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), $text );
	}

	/**
	 * El error de una foto que ya no se puede poner en un producto nuevo: no es
	 * una foto pendiente de este usuario, o se la quedó otro formulario.
	 *
	 * @return WP_Error
	 */
	private static function photo_gone() {
		return new WP_Error( 'invalid_image', __( 'One of the photos is no longer available. Remove it and add it again.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
	}

	/**
	 * El error de un producto que no se pudo crear.
	 *
	 * @return WP_Error
	 */
	private static function not_created() {
		return new WP_Error( 'product_create_failed', __( 'The product could not be saved.', 'mosley-digital-for-woocommerce' ), array( 'status' => 500 ) );
	}

	/**
	 * Guarda lo que se cambió y devuelve el detalle, leído otra vez.
	 *
	 * Leerlo otra vez no basta si WooCommerce devuelve lo que ya tenía leído.
	 * Con su caché de instancias de productos (`product_instance_caching`,
	 * encendida en las tiendas que se instalan con WooCommerce 11.0 o
	 * posterior), `wc_get_product()` da durante toda la petición el objeto que
	 * leyó la primera vez. WooCommerce lo olvida al guardar ese producto, y al
	 * guardar una variación olvida también el de su producto
	 * (`WC_Product_Data_Store_CPT::clear_caches()`); al guardar un producto no
	 * olvida los de sus variaciones. Y una variación que toma el stock de su
	 * producto lleva dentro la cantidad de él, copiada al leerla
	 * (`WC_Product_Variation_Data_Store_CPT::read_product_data()`).
	 *
	 * Es el caso de la variación de la ruta cuando la cantidad que se guarda
	 * es la de su producto: se leyó antes de guardar, lo que se guarda es él, y
	 * el detalle la traería con la cantidad de antes. `clean_post_cache()` hace
	 * que WooCommerce la olvide
	 * (`ProductCacheController::invalidate_product_cache_on_clean()`). No hace
	 * falta con nada más de lo que aquí se lee antes de guardar:
	 *
	 * - Lo que se guarda, y el producto de la variación que se guarda, los
	 *   olvida WooCommerce. El producto, además, se vuelve a guardar en
	 *   `WC_Product_Variable::sync()`.
	 * - Las demás variaciones del producto no se han leído todavía: se leen
	 *   en el detalle, ya con lo guardado. Y a las que el guardado les cambia
	 *   el estado del stock (`sync_managed_variation_stock_status()`),
	 *   WooCommerce las olvida al cambiárselo.
	 *
	 * @param WC_Product[] $changed Los productos con cambios por guardar.
	 * @param WC_Product   $product El producto o la variación de la ruta.
	 * @param WC_Product   $shown   El producto cuyo detalle se devuelve.
	 * @return array|WP_Error
	 */
	private function save( array $changed, $product, $shown ) {
		try {
			foreach ( $changed as $one ) {
				$one->save();
			}

			if ( ! in_array( $product, $changed, true ) ) {
				clean_post_cache( (int) $product->get_id() );
			}

			// Un producto variable saca su rango de precios y su estado de stock
			// de sus variaciones. WooCommerce lo vuelve a calcular al terminar la
			// petición; aquí se hace ya, para que el detalle que se devuelve y la
			// lista que la app recarga después lo traigan al día.
			if ( self::is_variation( $product ) && is_callable( array( 'WC_Product_Variable', 'sync' ) ) ) {
				WC_Product_Variable::sync( (int) $shown->get_id() );
			}
		} catch ( Exception $error ) {
			return new WP_Error( 'product_update_failed', __( 'The product could not be saved.', 'mosley-digital-for-woocommerce' ), array( 'status' => 500 ) );
		}

		// Se vuelve a leer: al guardar, WooCommerce recalcula lo que depende de
		// lo que se cambió (el estado del stock, el precio vigente).
		return $this->product( (int) $shown->get_id() );
	}

	/**
	 * Los productos de una página del catálogo: «Todos», «Publicados»,
	 * «Borradores» y «Agotados». Por nombre, y los que se llaman igual, por id,
	 * para que dos páginas no repitan ni se salten ninguno.
	 *
	 * «Agotados» es lo que «Todos» enseña con la etiqueta «Agotado», controle
	 * su cantidad o no, y además las variaciones agotadas, cada una en su fila:
	 * en una tienda de moda lo que se agota es una talla, no la camiseta. De
	 * las variaciones, solo las activadas cuyo producto está en la lista de la
	 * tienda: las aparta la propia consulta
	 * (`APSW_App_Store::products_with_listed_parent()`), que es también
	 * quien corta la página, como en los demás filtros.
	 *
	 * @param array  $statuses     Estados que entran.
	 * @param string $search       Texto buscado, o ''.
	 * @param int    $offset       Productos que se saltan.
	 * @param bool   $out_of_stock Solo lo agotado, con las variaciones.
	 * @return array array( WC_Product[], si hay más ).
	 */
	private function catalog_rows( array $statuses, $search, $offset, $out_of_stock ) {
		$query = array(
			'status'  => $statuses,
			// Uno más de los que se enseñan, para saber si hay otra página.
			'limit'   => self::PER_PAGE + 1,
			'offset'  => $offset,
			'orderby' => array(
				'title' => 'ASC',
				'ID'    => 'ASC',
			),
			'order'   => 'ASC',
		);

		if ( $out_of_stock ) {
			$query['stock_status'] = 'outofstock';
			$query['type']         = APSW_App_Store::product_types_with_variations();
		}

		if ( '' !== $search ) {
			$ids = $this->search_ids( $search, $statuses, $out_of_stock );

			// Un `include` vacío no filtra: WooCommerce descarta los argumentos
			// vacíos y devolvería todo el catálogo.
			if ( ! $ids ) {
				return array( array(), false );
			}

			$query['include'] = $ids;
		}

		$products = $out_of_stock ? APSW_App_Store::products_with_listed_parent( $query, self::LISTED_STATUSES ) : wc_get_products( $query );
		$products = is_array( $products ) ? array_values( array_filter( $products, array( __CLASS__, 'is_product' ) ) ) : array();

		return array( array_slice( $products, 0, self::PER_PAGE ), count( $products ) > self::PER_PAGE );
	}

	/**
	 * Los productos de una página de «Stock bajo»: los de
	 * `APSW_App_Store::low_stock()`, que son los que cuenta la tarjeta de
	 * Inicio, del que menos existencias tiene al que más. Son productos
	 * publicados que controlan su cantidad, y también variaciones: cada una
	 * tiene su fila, como en Inicio.
	 *
	 * @param string $search Texto buscado, o ''.
	 * @param int    $offset Productos que se saltan.
	 * @return array array( WC_Product[], si hay más ).
	 */
	private function low_stock_rows( $search, $offset ) {
		if ( '' === $search ) {
			// La página se la pide a low_stock(), que avisa si hay más.
			$low      = APSW_App_Store::low_stock( array( 'offset' => $offset ), self::PER_PAGE );
			$entries  = $low['products'];
			$has_more = (bool) $low['more'];
		} else {
			// Lo que casa con la búsqueda no lo sabe esa consulta: se pide la
			// ventana entera y se corta aquí.
			$low     = APSW_App_Store::low_stock( array(), APSW_App_Store::MAX_LOW_STOCK_WINDOW );
			$match   = array_flip( $this->search_ids( $search, array( 'publish' ), true ) );
			$entries = array_filter(
				$low['products'],
				static function ( $entry ) use ( $match ) {
					return isset( $match[ (int) $entry['id'] ] );
				}
			);

			$has_more = count( $entries ) > $offset + self::PER_PAGE;
			$entries  = array_slice( array_values( $entries ), $offset, self::PER_PAGE );
		}

		$products = array();

		foreach ( $entries as $entry ) {
			$product = wc_get_product( (int) $entry['id'] );

			if ( self::is_product( $product ) ) {
				$products[] = $product;
			}
		}

		return array( $products, $has_more );
	}

	/**
	 * Los ids de lo que casa con una búsqueda, por el nombre o por el SKU:
	 * como mucho MAX_SEARCH_RESULTS por cada camino.
	 *
	 * Son dos consultas porque `wc_get_products()` las junta con un «y»: una
	 * sola con `s` y `sku` pediría que el texto estuviera en los dos sitios.
	 *
	 * - Por nombre: `s`, que WordPress busca también en la descripción. Con
	 *   `search_columns` (WordPress 6.2) se queda en el título.
	 * - Por SKU: `sku`, que casa con una parte del SKU. Entran también las
	 *   variaciones, que es donde una tienda de moda tiene sus SKU.
	 *
	 * En «Todos», «Publicados» y «Borradores» una variación no tiene fila: la
	 * que casa trae a su producto. En «Stock bajo» y «Agotados» sí la tiene, y
	 * entra ella. Y entran también las variaciones de un producto que casa:
	 * una variación sin SKU propio enseña el de su producto
	 * (`WC_Product_Variation::get_sku()`), pero en la base de datos no lo
	 * tiene, y buscar ese SKU no la encontraría aunque «Todos» sí encuentre a
	 * su producto.
	 *
	 * @param string $term       Texto buscado.
	 * @param array  $statuses   Estados entre los que se busca por nombre.
	 * @param bool   $variations Si las variaciones tienen fila propia.
	 * @return int[]
	 */
	private function search_ids( $term, array $statuses, $variations ) {
		$by_name = array(
			'status'         => $statuses,
			's'              => $term,
			'search_columns' => array( 'post_title' ),
			'limit'          => self::MAX_SEARCH_RESULTS,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'return'         => 'ids',
		);

		if ( $variations ) {
			$by_name['type'] = APSW_App_Store::product_types_with_variations();
		}

		$by_sku = array(
			'status'  => self::LISTED_STATUSES,
			'type'    => APSW_App_Store::product_types_with_variations(),
			'sku'     => $term,
			'limit'   => self::MAX_SEARCH_RESULTS,
			'orderby' => 'title',
			'order'   => 'ASC',
			'return'  => 'ids',
		);

		$named = self::id_list( wc_get_products( $by_name ) );
		$coded = self::id_list( wc_get_products( $by_sku ) );

		if ( ! $variations && $coded ) {
			// De lo encontrado, qué es una variación y de quién: una consulta
			// para todos los ids, en vez de una por cada uno.
			$found = get_posts(
				array(
					'post__in'               => $coded,
					'post_type'              => array( 'product', 'product_variation' ),
					'post_status'            => self::LISTED_STATUSES,
					'posts_per_page'         => count( $coded ),
					'orderby'                => 'none',
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			);

			$parents = array();

			foreach ( is_array( $found ) ? $found : array() as $post ) {
				if ( is_object( $post ) && 'product_variation' === $post->post_type ) {
					$parents[ (int) $post->ID ] = (int) $post->post_parent;
				}
			}

			foreach ( $coded as $index => $id ) {
				if ( isset( $parents[ $id ] ) ) {
					$coded[ $index ] = $parents[ $id ];
				}
			}
		}

		$ids = self::id_list( array_merge( $named, $coded ) );

		if ( $variations && $ids ) {
			$children = wc_get_products(
				array(
					'status'          => array( 'publish' ),
					'type'            => 'variation',
					// `parent` solo admite un id; esto llega tal cual a WP_Query.
					'post_parent__in' => $ids,
					'limit'           => self::MAX_SEARCH_RESULTS,
					'orderby'         => 'title',
					'order'           => 'ASC',
					'return'          => 'ids',
				)
			);

			$ids = self::id_list( array_merge( $ids, self::id_list( $children ) ) );
		}

		return $ids;
	}

	/**
	 * Una fila de la lista.
	 *
	 * @param WC_Product $product Producto, o variación en «Stock bajo» y «Agotados».
	 * @return array
	 */
	private function row( $product ) {
		$mode     = $this->stock_mode( $product );
		$managed  = 'none' !== $mode;
		$slug     = (string) $product->get_stock_status();
		$out      = 'outofstock' === $slug;
		$quantity = $managed ? self::quantity( $product ) : null;

		return array(
			'id'     => (int) $product->get_id(),
			'name'   => self::name( $product ),
			'thumb'  => self::image( $product, 'thumbnail' ),
			'status' => self::status( $product ),
			'type'   => (string) $product->get_type(),
			'price'  => $this->row_price( $product ),
			'stock'  => array(
				'label' => self::stock_label( $product, $managed, $quantity, $slug ),
				// El criterio de Inicio: controla la cantidad, la tiene, y está en
				// el umbral de la tienda o por debajo. Un agotado no es además
				// «bajo»: la fila es de un color o del otro.
				'low'   => ! $out && $managed && null !== $product->get_stock_quantity() && $quantity <= self::low_stock_threshold(),
				'out'   => $out,
			),
		);
	}

	/**
	 * El precio de una fila: «$120.00», o «$90.00 – $150.00» en un producto
	 * variable cuyas variaciones no cuestan lo mismo. null si no tiene.
	 *
	 * @param WC_Product $product Producto.
	 * @return string|null
	 */
	private function row_price( $product ) {
		if ( 'variable' === $product->get_type() && is_callable( array( $product, 'get_variation_price' ) ) ) {
			$min = $product->get_variation_price( 'min' );
			$max = $product->get_variation_price( 'max' );

			if ( ! is_numeric( $min ) || ! is_numeric( $max ) ) {
				return null;
			}

			return (float) $min === (float) $max ? self::money( $min ) : self::money( $min ) . ' – ' . self::money( $max );
		}

		$price = self::active_price( $product );

		return null === $price ? null : self::money( $price );
	}

	/**
	 * La forma del detalle.
	 *
	 * @param WC_Product $product Producto, nunca una variación.
	 * @return array
	 */
	private function detail( $product ) {
		$id         = (int) $product->get_id();
		$type       = (string) $product->get_type();
		$sku        = trim( (string) $product->get_sku() );
		$can_edit   = (bool) current_user_can( 'edit_product', $id );
		$variations = 'variable' === $type ? array_values( array_filter( array_map( 'intval', (array) $product->get_children() ) ) ) : array();
		$shown      = array();

		foreach ( array_slice( $variations, 0, self::MAX_VARIATIONS ) as $variation_id ) {
			$variation = wc_get_product( $variation_id );

			if ( self::is_product( $variation ) && ! in_array( $variation->get_status(), self::NOT_A_PRODUCT, true ) ) {
				$shown[] = array(
					'id'    => (int) $variation->get_id(),
					'name'  => self::variation_name( $variation ),
					'thumb' => self::image( $variation, 'thumbnail' ),
					'price' => $this->price( $variation ),
					'stock' => $this->stock( $variation, $product ),
				);
			}
		}

		return array(
			'id'              => $id,
			'name'            => self::name( $product ),
			'image'           => self::image( $product, 'woocommerce_single' ),
			'status'          => self::status( $product ),
			'type'            => array(
				'slug'  => $type,
				'label' => self::type_label( $type ),
			),
			'sku'             => '' !== $sku ? $sku : null,
			'categories'      => self::categories( $id ),
			'can_edit'        => $can_edit,
			// Publicar pide además el permiso de publicar productos, que es el
			// que comprueba la ruta. Y un producto programado no se publica ni
			// se pasa a borrador desde aquí: lo decide su fecha.
			'can_publish'     => $can_edit && (bool) current_user_can( 'publish_products' ) && self::SCHEDULED !== (string) $product->get_status(),
			'price'           => in_array( $type, self::PRICE_TYPES, true ) ? $this->price( $product ) : null,
			'stock'           => in_array( $type, self::STOCK_TYPES, true ) ? $this->stock( $product, null ) : null,
			'variations'      => $shown,
			'variations_more' => count( $variations ) > self::MAX_VARIATIONS,
		);
	}

	/**
	 * El precio de un producto o de una variación.
	 *
	 * `regular` y `sale` son los números guardados, sin los filtros de la
	 * tienda: lo que el comerciante escribió y lo que va a editar.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return array array( regular, sale, display, tax_note ).
	 */
	private function price( $product ) {
		$regular = self::stored_number( $product->get_regular_price( 'edit' ) );
		$active  = self::active_price( $product );

		$sale    = self::stored_number( $product->get_sale_price( 'edit' ) );

		if ( null === $active ) {
			$display = __( 'No price', 'mosley-digital-for-woocommerce' );
		} elseif ( null !== $regular && $product->is_on_sale( 'edit' ) ) {
			/* translators: 1: price the product sells at now, 2: its regular price. */
			$display = sprintf( __( '%1$s (was %2$s)', 'mosley-digital-for-woocommerce' ), self::money( $active ), self::money( $regular ) );
		} elseif ( null !== $sale && self::sale_starts_later( $product ) ) {
			// Una rebaja guardada que todavía no ha empezado: hoy se vende al
			// precio normal, y se dice cuál es la que viene.
			/* translators: 1: price the product sells at now, 2: price of a sale that is saved but has not started yet. */
			$display = sprintf( __( '%1$s (scheduled sale: %2$s)', 'mosley-digital-for-woocommerce' ), self::money( $active ), self::money( $sale ) );
		} else {
			$display = self::money( $active );
		}

		return array(
			'regular'  => $regular,
			'sale'     => $sale,
			'display'  => $display,
			'tax_note' => self::tax_note(),
		);
	}

	/**
	 * El stock de un producto o de una variación.
	 *
	 * Una variación que toma el stock de su producto enseña esa cantidad, que
	 * comparte con sus hermanas. Y ninguna variación de un producto que
	 * controla el stock puede dejar de controlarlo ella sola —heredaría el de
	 * él—, tenga cantidad propia o no: `can_manage` va en false.
	 *
	 * @param WC_Product      $product Producto o variación.
	 * @param WC_Product|null $parent  El producto de la variación; null si no es una variación.
	 * @return array array( manage, can_manage, quantity, status, statuses, label ).
	 */
	private function stock( $product, $parent ) {
		$mode     = $this->stock_mode( $product );
		$managed  = 'none' !== $mode;
		$slug     = (string) $product->get_stock_status();
		$quantity = $managed ? self::quantity( $product ) : null;
		$labels   = self::stock_statuses();
		$statuses = array();

		foreach ( $labels as $key => $label ) {
			$statuses[] = array(
				'slug'  => $key,
				'label' => $label,
			);
		}

		return array(
			'manage'     => $managed,
			'can_manage' => self::store_manages_stock() && 'parent' !== $mode && ( null === $parent || ! self::tracks_stock( $parent ) ),
			'quantity'   => $quantity,
			'status'     => array(
				'slug'  => $slug,
				'label' => isset( $labels[ $slug ] ) ? $labels[ $slug ] : $slug,
			),
			'statuses'   => $statuses,
			'label'      => self::stock_label( $product, $managed, $quantity, $slug ),
		);
	}

	/**
	 * Quién controla la cantidad de un producto.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return string `own` si la controla él, `parent` si es una variación que
	 *                toma la de su producto, `none` si nadie la controla o la
	 *                tienda tiene el control de stock desactivado.
	 */
	private function stock_mode( $product ) {
		if ( ! self::store_manages_stock() ) {
			return 'none';
		}

		$manage = $product->get_manage_stock();

		if ( 'parent' === $manage ) {
			return 'parent';
		}

		return $manage ? 'own' : 'none';
	}

	/**
	 * La línea de stock de una fila: «12 en stock», «Agotado», «Bajo pedido» o
	 * «Sin control de stock».
	 *
	 * Un producto variable que no controla la cantidad él mismo la suele
	 * controlar en cada variación: decir que no tiene control sería mentir, así
	 * que dice lo que WooCommerce sabe de él, que hay existencias.
	 *
	 * @param WC_Product $product  Producto o variación.
	 * @param bool       $managed  Si se controla la cantidad.
	 * @param int|null   $quantity La cantidad, si se controla.
	 * @param string     $slug     Estado del stock.
	 * @return string
	 */
	private static function stock_label( $product, $managed, $quantity, $slug ) {
		$labels = self::stock_statuses();

		if ( 'outofstock' === $slug ) {
			return $labels['outofstock'];
		}

		if ( 'onbackorder' === $slug ) {
			return $labels['onbackorder'];
		}

		if ( $managed ) {
			/* translators: %d: stock quantity of a product. */
			return sprintf( __( '%d in stock', 'mosley-digital-for-woocommerce' ), (int) $quantity );
		}

		return 'variable' === $product->get_type() ? $labels['instock'] : __( 'Stock not managed', 'mosley-digital-for-woocommerce' );
	}

	/**
	 * El producto, o el error de que no existe.
	 *
	 * @param int|string $product_id Id del producto o de la variación.
	 * @return WC_Product|WP_Error
	 */
	private function find( $product_id ) {
		$id      = is_int( $product_id ) || ( is_string( $product_id ) && ctype_digit( $product_id ) && strlen( $product_id ) <= 18 ) ? (int) $product_id : 0;
		$product = $id > 0 ? wc_get_product( $id ) : false;

		if ( ! self::is_product( $product ) || in_array( $product->get_status(), self::NOT_A_PRODUCT, true ) ) {
			return self::not_found();
		}

		return $product;
	}

	/**
	 * El producto cuyo detalle se devuelve, al pedirlo o tras una escritura:
	 * él mismo, o el producto al que pertenece si es una variación.
	 *
	 * Una variación sin producto —se borró, está en la papelera— ni se abre ni
	 * se edita: no hay detalle en el que verla.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return WC_Product|WP_Error
	 */
	private function shown_product( $product ) {
		if ( ! self::is_variation( $product ) ) {
			return $product;
		}

		$parent = $this->find( (int) $product->get_parent_id() );

		return is_wp_error( $parent ) || self::is_variation( $parent ) ? self::not_found() : $parent;
	}

	/**
	 * El error de un producto que no existe.
	 *
	 * @return WP_Error
	 */
	private static function not_found() {
		return new WP_Error( 'product_not_found', __( 'This product no longer exists.', 'mosley-digital-for-woocommerce' ), array( 'status' => 404 ) );
	}

	/**
	 * Si algo es un producto de WooCommerce.
	 *
	 * @param mixed $product Lo que devolvió WooCommerce.
	 * @return bool
	 */
	private static function is_product( $product ) {
		return $product instanceof WC_Product;
	}

	/**
	 * Si un producto es una variación.
	 *
	 * @param WC_Product $product Producto.
	 * @return bool
	 */
	private static function is_variation( $product ) {
		return $product instanceof WC_Product_Variation || 'variation' === $product->get_type();
	}

	/**
	 * La página pedida, desde 1.
	 *
	 * @param mixed $page Lo que llegó en `page`; null o '' es la primera.
	 * @return int|WP_Error
	 */
	private function page( $page ) {
		if ( null === $page || '' === $page ) {
			return 1;
		}

		// Nueve cifras como mucho: una cadena más larga no cabe en un entero.
		$digits = is_string( $page ) && ctype_digit( $page ) && strlen( $page ) <= 9;
		$page   = is_int( $page ) || $digits ? (int) $page : 0;

		if ( $page < 1 || $page > self::MAX_PAGE ) {
			return new WP_Error( 'invalid_params', __( 'Invalid page.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		return $page;
	}

	/**
	 * El texto de la búsqueda, limpio y con tope.
	 *
	 * WP_Query lee un guion al principio de una palabra como «que no tenga
	 * esto» (`WP_Query::parse_search()`): buscar «-zz» devolvía todo el
	 * catálogo, que es lo que no tiene «zz». En el buscador de una tienda un
	 * guion es parte de un SKU, no un operador, así que los del principio de
	 * cada palabra se quitan. Las palabras las separa como WP_Query: espacios,
	 * tabuladores, comas, signos de más y comillas.
	 *
	 * @param mixed $search Lo que llegó en `search`.
	 * @return string|false '' si no hay búsqueda; false si la hay y no se puede
	 *                      buscar —se queda en nada, o en una sola letra—, que
	 *                      es no encontrar nada.
	 */
	private function search_term( $search ) {
		$typed = is_string( $search ) ? trim( mb_substr( trim( $search ), 0, self::MAX_SEARCH_CHARS ) ) : '';

		if ( '' === $typed ) {
			return '';
		}

		$term = $typed;

		do {
			$term = preg_replace( '/(^|[\t ",+\'])-+/u', '$1', $term, -1, $stripped );
		} while ( is_string( $term ) && $stripped > 0 );

		// preg_replace() devuelve null si el texto no es UTF-8 válido.
		$term = is_string( $term ) ? trim( $term, " \t\"',+" ) : '';

		return '' !== $term && $this->is_searchable( $term ) ? $term : false;
	}

	/**
	 * Si un texto es una búsqueda: un número, o al menos MIN_SEARCH_CHARS
	 * caracteres.
	 *
	 * @param string $search Texto de search_term(), no vacío.
	 * @return bool
	 */
	private function is_searchable( $search ) {
		return ctype_digit( $search ) || mb_strlen( $search ) >= self::MIN_SEARCH_CHARS;
	}

	/**
	 * Una lista de ids sin repetidos ni ceros.
	 *
	 * @param mixed $ids Lo que devolvió una consulta.
	 * @return int[]
	 */
	private static function id_list( $ids ) {
		return array_values( array_unique( array_filter( array_map( 'intval', is_array( $ids ) ? $ids : array() ) ) ) );
	}

	/**
	 * Si la tienda tiene activado el control de stock (WooCommerce → Ajustes →
	 * Productos → Inventario). Con él desactivado ningún producto controla su
	 * cantidad, diga lo que diga cada uno.
	 *
	 * @return bool
	 */
	private static function store_manages_stock() {
		return 'yes' === get_option( 'woocommerce_manage_stock' );
	}

	/**
	 * El umbral de pocas existencias de la tienda: la misma expresión que usa
	 * `APSW_App_Store::low_stock()`.
	 *
	 * @return int
	 */
	private static function low_stock_threshold() {
		return absint( get_option( 'woocommerce_notify_low_stock_amount', 2 ) );
	}

	/**
	 * Si un producto tiene activado su propio control de stock, diga lo que
	 * diga el ajuste de la tienda. Es lo que una variación hereda.
	 *
	 * @param WC_Product $product Producto.
	 * @return bool
	 */
	private static function tracks_stock( $product ) {
		return true === $product->get_manage_stock( 'edit' );
	}

	/**
	 * Si la rebaja guardada de un producto tiene fecha de inicio y aún no ha
	 * llegado.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return bool
	 */
	private static function sale_starts_later( $product ) {
		$from = $product->get_date_on_sale_from( 'edit' );

		return $from instanceof DateTimeInterface && $from->getTimestamp() > time();
	}

	/**
	 * La cantidad de un producto que la controla, como entero.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return int
	 */
	private static function quantity( $product ) {
		return (int) $product->get_stock_quantity();
	}

	/**
	 * El precio vigente de un producto, de sus números guardados: el rebajado
	 * si la rebaja está en marcha, y si no el normal.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return string|null null si no tiene precio.
	 */
	private static function active_price( $product ) {
		$regular = $product->get_regular_price( 'edit' );
		$sale    = $product->get_sale_price( 'edit' );
		$price   = is_numeric( $sale ) && $product->is_on_sale( 'edit' ) ? $sale : $regular;

		return is_numeric( $price ) ? (string) $price : null;
	}

	/**
	 * Un número guardado, con punto decimal y los decimales de la tienda:
	 * «120» sale «120.00». Nunca se redondea: si se guardó con más decimales
	 * que los de la tienda, salen todos, para que abrir la pantalla y guardar
	 * sin tocar nada no cambie el precio.
	 *
	 * @param mixed $value Lo que guarda WooCommerce: un texto, o '' si no hay.
	 * @return string|null null si no hay número.
	 */
	private static function stored_number( $value ) {
		$text = is_scalar( $value ) ? trim( (string) $value ) : '';

		if ( '' === $text || ! is_numeric( $text ) ) {
			return null;
		}

		$decimals = max( 0, (int) wc_get_price_decimals() );

		if ( 1 !== preg_match( '/^(-?\d+)(?:\.(\d*))?$/', $text, $parts ) ) {
			return number_format( (float) $text, $decimals, '.', '' );
		}

		$fraction = str_pad( isset( $parts[2] ) ? $parts[2] : '', $decimals, '0' );

		return '' === $fraction ? $parts[1] : $parts[1] . '.' . $fraction;
	}

	/**
	 * Un precio que llega de la app, como lo guarda WooCommerce: con punto
	 * decimal. La app acepta coma o punto, y aquí también.
	 *
	 * @param mixed $value Lo que llegó en `regular` o en `sale`.
	 * @return string|WP_Error '' si viene vacío; invalid_params (400) si no es un número o es negativo.
	 */
	private static function price_input( $value ) {
		if ( null === $value ) {
			return '';
		}

		if ( is_int( $value ) || is_float( $value ) ) {
			$text = (string) $value;
		} elseif ( is_string( $value ) ) {
			$text = trim( $value );
		} else {
			$text = 'x';
		}

		if ( '' === $text ) {
			return '';
		}

		$text = str_replace( ',', '.', $text );

		if ( 1 === preg_match( '/^-\s*[0-9.]+$/', $text ) ) {
			return new WP_Error( 'invalid_params', __( 'The price cannot be negative.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		// Hasta doce cifras y seis decimales, con un solo separador: «1,250.50»
		// no es un número aquí, porque la coma ya es el separador decimal.
		if ( 1 !== preg_match( '/^(\d{0,12})(?:\.(\d{0,6}))?$/', $text, $parts ) || ( '' === $parts[1] && ( ! isset( $parts[2] ) || '' === $parts[2] ) ) ) {
			return new WP_Error( 'invalid_params', __( 'Write the price using numbers only, for example 120.50.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$whole    = ltrim( $parts[1], '0' );
		$whole    = '' === $whole ? '0' : $whole;
		$fraction = isset( $parts[2] ) ? $parts[2] : '';

		return '' === $fraction ? $whole : $whole . '.' . $fraction;
	}

	/**
	 * El precio normal y el rebajado que llegan de la app, comprobados: lo que
	 * comparten cambiar el precio de un producto y crear uno.
	 *
	 * @param mixed $regular        Lo que llegó en `regular`.
	 * @param mixed $sale           Lo que llegó en `sale`.
	 * @param mixed $stored_regular El precio normal que el producto tiene guardado; '' en uno nuevo.
	 * @param mixed $stored_sale    El rebajado que tiene guardado; '' en uno nuevo.
	 * @return array|WP_Error array( normal, rebajado ), cada uno como lo guarda WooCommerce o '' si va vacío; invalid_params o invalid_sale_price (400).
	 */
	private static function price_pair( $regular, $sale, $stored_regular, $stored_sale ) {
		$regular = self::price_input( $regular );
		$sale    = is_wp_error( $regular ) ? $regular : self::price_input( $sale );

		if ( is_wp_error( $sale ) ) {
			return $sale;
		}

		// «1,480» y «1.480» se leen como 1.48: un solo separador es el decimal.
		// Quien quería decir mil cuatrocientos ochenta dejaría el producto a
		// uno con cuarenta y ocho. La tienda sabe cuántos decimales usa, y un
		// precio nuevo con más que esos no se guarda. Cada precio por su lado.
		if ( self::too_many_decimals( $regular, $stored_regular ) || self::too_many_decimals( $sale, $stored_sale ) ) {
			return new WP_Error( 'invalid_params', __( 'That price has more decimals than the store uses. Write it without a thousands separator: 1480, not 1,480.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( '' !== $sale && '' === $regular ) {
			return new WP_Error( 'invalid_sale_price', __( 'Set a regular price before the sale price.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( '' !== $sale && (float) $sale >= (float) $regular ) {
			return new WP_Error( 'invalid_sale_price', __( 'The sale price must be lower than the regular price.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		return array( $regular, $sale );
	}

	/**
	 * Si un precio que llega trae más decimales de los que usa la tienda.
	 *
	 * Cuentan los que se escribieron, ceros incluidos: «120.000» en una tienda
	 * de dos decimales son tres. El precio que ya está guardado pasa tenga los
	 * que tenga: un «19.999» que alguien guardó desde el wp-admin no impide
	 * ponerle una rebaja.
	 *
	 * @param string $new    Lo que devolvió price_input().
	 * @param mixed  $stored Lo que guarda WooCommerce de ese mismo precio.
	 * @return bool
	 */
	private static function too_many_decimals( $new, $stored ) {
		if ( '' === $new || self::same_number( $new, $stored ) ) {
			return false;
		}

		$point = strpos( $new, '.' );

		return false !== $point && strlen( $new ) - $point - 1 > max( 0, (int) wc_get_price_decimals() );
	}

	/**
	 * Si un precio que llega es el que ya está guardado.
	 *
	 * @param string $new    Lo que devolvió price_input().
	 * @param mixed  $stored Lo que guarda WooCommerce.
	 * @return bool
	 */
	private static function same_number( $new, $stored ) {
		$stored = is_scalar( $stored ) ? trim( (string) $stored ) : '';

		if ( '' === $new || '' === $stored ) {
			return $new === $stored;
		}

		return is_numeric( $stored ) && (float) $new === (float) $stored;
	}

	/**
	 * Un número entero que llega de la app.
	 *
	 * @param mixed $value Un entero, o un texto que lo es («12», «-3»).
	 * @return int|null null si no lo es.
	 */
	private static function whole( $value ) {
		if ( is_int( $value ) ) {
			return $value;
		}

		// JSON no distingue 12 de 12.0.
		if ( is_float( $value ) ) {
			return floor( $value ) === $value && abs( $value ) < 1000000000 ? (int) $value : null;
		}

		return is_string( $value ) && 1 === preg_match( '/^-?\d{1,9}$/', trim( $value ) ) ? (int) trim( $value ) : null;
	}

	/**
	 * Un sí o un no que llega de la app.
	 *
	 * @param mixed $value true, false, o como los escribe un formulario («true», «0»).
	 * @return bool|null null si no es ninguno de los dos.
	 */
	private static function flag( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_int( $value ) || ( is_string( $value ) && '' !== trim( $value ) ) ) {
			return filter_var( $value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE );
		}

		return null;
	}

	/**
	 * El nombre de un producto, sin HTML y con tope.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @return string
	 */
	private static function name( $product ) {
		return mb_substr( APSW_App_Text::plain( $product->get_name() ), 0, self::MAX_NAME_CHARS );
	}

	/**
	 * El nombre de una variación dentro de su producto: sus atributos
	 * («Rojo, M»). Si los deja todos en «cualquiera», el suyo entero.
	 *
	 * Una variación desactivada (`private`) sigue en la lista, y se puede
	 * editar, pero la tienda no la vende: lo dice su nombre, «Rojo, M
	 * (desactivada)».
	 *
	 * @param WC_Product $variation Variación.
	 * @return string
	 */
	private static function variation_name( $variation ) {
		$attributes = function_exists( 'wc_get_formatted_variation' ) ? APSW_App_Text::plain( wc_get_formatted_variation( $variation, true, false, false ) ) : '';
		$name       = '' !== $attributes ? $attributes : APSW_App_Text::plain( $variation->get_name() );

		if ( '' === $name ) {
			/* translators: %d: id of a product variation that has no name. */
			$name = sprintf( __( 'Variation #%d', 'mosley-digital-for-woocommerce' ), (int) $variation->get_id() );
		}

		if ( 'publish' === (string) $variation->get_status() ) {
			return mb_substr( $name, 0, self::MAX_NAME_CHARS );
		}

		/* translators: %s: name of a product variation that is disabled, for example "Red, M". */
		$disabled = __( '%s (disabled)', 'mosley-digital-for-woocommerce' );

		// El nombre se corta para que quepa con lo que se le añade.
		return sprintf( $disabled, mb_substr( $name, 0, max( 0, self::MAX_NAME_CHARS - mb_strlen( sprintf( $disabled, '' ) ) ) ) );
	}

	/**
	 * El estado de un producto, con su etiqueta.
	 *
	 * @param WC_Product $product Producto.
	 * @return array array( slug, label ).
	 */
	private static function status( $product ) {
		$slug   = (string) $product->get_status();
		$labels = self::status_labels();

		return array(
			'slug'  => $slug,
			'label' => isset( $labels[ $slug ] ) ? $labels[ $slug ] : $slug,
		);
	}

	/**
	 * La etiqueta de un tipo de producto.
	 *
	 * @param string $type Tipo.
	 * @return string
	 */
	private static function type_label( $type ) {
		$labels = self::type_labels();

		if ( isset( $labels[ $type ] ) ) {
			return $labels[ $type ];
		}

		$types = function_exists( 'wc_get_product_types' ) ? (array) wc_get_product_types() : array();
		$label = isset( $types[ $type ] ) ? APSW_App_Text::plain( $types[ $type ] ) : '';

		return '' !== $label ? $label : $type;
	}

	/**
	 * Los nombres de las categorías de un producto.
	 *
	 * @param int $product_id Id del producto.
	 * @return string[]
	 */
	private static function categories( $product_id ) {
		$terms = get_the_terms( $product_id, 'product_cat' );
		$names = array();

		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$name = is_object( $term ) && isset( $term->name ) ? APSW_App_Text::plain( $term->name ) : '';

			if ( '' !== $name ) {
				$names[] = $name;
			}
		}

		return $names;
	}

	/**
	 * La URL de la imagen de un producto; null si no tiene. La de una variación
	 * sin imagen propia es la de su producto, que es la que da WooCommerce.
	 *
	 * @param WC_Product $product Producto o variación.
	 * @param string     $size    Tamaño de imagen de WordPress.
	 * @return string|null
	 */
	private static function image( $product, $size ) {
		$image_id = (int) $product->get_image_id();
		$url      = $image_id > 0 ? wp_get_attachment_image_url( $image_id, $size ) : false;

		return is_string( $url ) && '' !== $url ? $url : null;
	}

	/**
	 * La nota de impuestos de la pantalla de precio; null si la tienda no
	 * cobra impuestos.
	 *
	 * @return string|null
	 */
	private static function tax_note() {
		if ( ! function_exists( 'wc_tax_enabled' ) || ! wc_tax_enabled() ) {
			return null;
		}

		return wc_prices_include_tax() ? __( 'Prices include tax', 'mosley-digital-for-woocommerce' ) : __( 'Prices do not include tax', 'mosley-digital-for-woocommerce' );
	}

	/**
	 * Un importe con la moneda de la tienda ("$1,480.00"), sin HTML.
	 *
	 * @param mixed $amount Importe.
	 * @return string
	 */
	private static function money( $amount ) {
		return APSW_App_Text::plain( wc_price( (float) $amount ) );
	}
}
