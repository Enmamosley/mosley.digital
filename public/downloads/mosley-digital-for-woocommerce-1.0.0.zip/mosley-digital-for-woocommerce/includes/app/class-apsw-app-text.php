<?php
/**
 * Texto listo para pintar en la app móvil.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * La app pinta texto, no HTML. WordPress y WooCommerce guardan y devuelven
 * muchas cosas con etiquetas y entidades —el nombre de un producto
 * («Café &amp; Té»), un importe de `wc_price()`, una dirección formateada, una
 * nota—, y todo eso pasa por aquí antes de salir. Lo usan Inicio, Pedidos y
 * Productos, para que un mismo nombre se lea igual en las tres pantallas.
 */
class APSW_App_Text {

	/**
	 * Un texto sin HTML ni entidades.
	 *
	 * @param mixed $html Texto, quizá con HTML.
	 * @return string
	 */
	public static function plain( $html ) {
		return trim( html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	}
}
