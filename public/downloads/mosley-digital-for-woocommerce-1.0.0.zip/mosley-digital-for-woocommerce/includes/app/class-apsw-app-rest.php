<?php
/**
 * Rutas REST de la app móvil: Inicio, Pedidos, Productos y los avisos.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registra las quince rutas de la app (`REST_NAMESPACE` y `/app/`), comprueba
 * los permisos y le pasa cada petición a APSW_App_Home, a APSW_App_Orders, a
 * APSW_App_Products, a APSW_App_Push o a APSW_App_Uploads, que devuelven los
 * datos listos para pintar.
 *
 * Leen y escriben la tienda con las funciones de WordPress y de WooCommerce, y
 * ninguna hace una petición hacia fuera: funcionan en cualquier tienda con el
 * plugin. (La única petición hacia fuera del plugin es el aviso de un pedido
 * nuevo, que sale de una tarea en segundo plano: ver APSW_App_Push.) La app se
 * identifica con una contraseña de aplicación de WordPress.
 *
 * Cada ruta declara sus parámetros (`args`): de qué tipo es cada uno y con qué
 * función se limpia antes de que la ruta corra. Lo que no hacen es validarlos:
 *
 * - Ninguno lleva `validate_callback`, y todos llevan su `sanitize_callback`.
 *   A un parámetro con `type` y sin `sanitize_callback` WordPress le pone
 *   `rest_parse_request_arg`, que valida, y lo que no pasa lo contesta él con
 *   su `rest_invalid_param`. La app espera los códigos de la spec
 *   (`invalid_params`, `invalid_status`, `invalid_note`,
 *   `invalid_sale_price`…) con su mensaje en el idioma de la tienda: validan
 *   las tres clases, que son quienes saben qué vale.
 * - Las funciones que limpian no cambian ninguna respuesta: dejan cada valor
 *   como la clase que lo recibe lo iba a leer de todos modos (un id o una
 *   página escritos con cifras, como número; una búsqueda, sin los espacios de
 *   los lados; una nota, por `sanitize_textarea_field()`), y lo que no es del
 *   tipo esperado —una lista donde va un texto— llega como algo que la clase
 *   rechaza igual que rechazaba lo que vino. La búsqueda no pasa por
 *   `sanitize_text_field()`: quita las secuencias `%xx` y las etiquetas, y
 *   buscar «50%acrílico» buscaría «50rílico».
 * - WordPress limpia cada parámetro en todos los sitios de la petición en que
 *   venga (el cuerpo JSON, la query, la ruta). Las escrituras siguen leyendo
 *   sus campos solo del cuerpo, y el id solo de la ruta.
 * - La ruta que sube una foto (`POST /app/products/images`) no declara
 *   ninguno: su cuerpo no es JSON sino `multipart/form-data`, y lo único que
 *   lee es el archivo del campo `file`, que WordPress no cuenta entre los
 *   parámetros de la petición (`WP_REST_Request::get_file_params()`). Lo que
 *   venga además en la query o en los campos del formulario no se mira.
 */
class APSW_App_Rest {

	const REST_NAMESPACE = 'ai-product-studio/v1';

	/**
	 * Periodo de Inicio cuando la app no dice ninguno.
	 *
	 * @var string
	 */
	private const DEFAULT_PERIOD = 'today';

	/**
	 * La pantalla de Inicio.
	 *
	 * @var APSW_App_Home
	 */
	private $home;

	/**
	 * La lista, el detalle y las escrituras de los pedidos.
	 *
	 * @var APSW_App_Orders
	 */
	private $orders;

	/**
	 * La lista, el detalle y las escrituras de los productos.
	 *
	 * @var APSW_App_Products
	 */
	private $products;

	/**
	 * Los teléfonos que reciben los avisos de pedidos nuevos.
	 *
	 * @var APSW_App_Push
	 */
	private $push;

	/**
	 * La `serialize_precision` que tenía PHP antes de que una respuesta de la
	 * app la cambiara; null si no se ha tocado.
	 *
	 * @var string|null
	 */
	private $precision = null;

	/**
	 * Constructor.
	 *
	 * @param APSW_App_Home     $home     La pantalla de Inicio.
	 * @param APSW_App_Orders   $orders   Los pedidos.
	 * @param APSW_App_Products $products Los productos.
	 * @param APSW_App_Push     $push     Los avisos.
	 */
	public function __construct( APSW_App_Home $home, APSW_App_Orders $orders, APSW_App_Products $products, APSW_App_Push $push ) {
		$this->home     = $home;
		$this->orders   = $orders;
		$this->products = $products;
		$this->push     = $push;
	}

	/**
	 * Initialize REST hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_filter( 'rest_pre_echo_response', array( $this, 'exact_decimals' ), 10, 3 );
	}

	/**
	 * Registra las rutas de la app.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/app/home',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_home' ),
				'permission_callback' => array( $this, 'can_read' ),
				'args'                => array(
					'period' => self::text_arg( APSW_App_Home::PERIODS ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/orders',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_orders' ),
				'permission_callback' => array( $this, 'can_read_orders' ),
				'args'                => array(
					'status' => self::text_arg(),
					'search' => self::search_arg(),
					'page'   => self::page_arg(),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/orders/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_order' ),
				'permission_callback' => array( $this, 'can_read_orders' ),
				'args'                => array(
					'id' => self::id_arg(),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/orders/(?P<id>\d+)/status',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_status' ),
				'permission_callback' => array( $this, 'can_write' ),
				'args'                => array(
					'id'     => self::id_arg(),
					'status' => self::text_arg(),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/orders/(?P<id>\d+)/notes',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_note' ),
				'permission_callback' => array( $this, 'can_write' ),
				'args'                => array(
					'id'       => self::id_arg(),
					'note'     => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_textarea_field',
					),
					'customer' => array(
						'type'              => 'boolean',
						'sanitize_callback' => array( __CLASS__, 'clean_yes' ),
					),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_products' ),
				'permission_callback' => array( $this, 'can_read_products' ),
				'args'                => array(
					'page'   => self::page_arg(),
					'search' => self::search_arg(),
					'filter' => self::text_arg( APSW_App_Products::FILTERS ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_product' ),
				'permission_callback' => array( $this, 'can_read_products' ),
				'args'                => array(
					'id' => self::id_arg(),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products/(?P<id>\d+)/price',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_product_price' ),
				'permission_callback' => array( $this, 'can_write_product' ),
				'args'                => array(
					'id'      => self::id_arg(),
					'regular' => self::value_arg( array( 'string', 'number' ) ),
					'sale'    => self::value_arg( array( 'string', 'number' ) ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products/(?P<id>\d+)/stock',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_product_stock' ),
				'permission_callback' => array( $this, 'can_write_product' ),
				'args'                => array(
					'id'       => self::id_arg(),
					'manage'   => self::value_arg( 'boolean' ),
					'quantity' => self::value_arg( 'integer' ),
					'expected' => self::value_arg( 'integer' ),
					'status'   => self::text_arg(),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products/(?P<id>\d+)/status',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_product_status' ),
				'permission_callback' => array( $this, 'can_publish_product' ),
				'args'                => array(
					'id'     => self::id_arg(),
					'status' => self::text_arg(),
				),
			)
		);

		// Crear un producto simple, con las fotos que antes se subieron
		// por la ruta de abajo. Sus campos van en el cuerpo JSON.
		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_product_create' ),
				'permission_callback' => array( $this, 'can_create_product' ),
				'args'                => array(
					'client_id'    => self::text_arg(),
					'name'         => self::text_arg(),
					'regular'      => self::value_arg( array( 'string', 'number' ) ),
					'sale'         => self::value_arg( array( 'string', 'number' ) ),
					'description'  => self::text_arg(),
					'manage'       => self::value_arg( 'boolean' ),
					'quantity'     => self::value_arg( 'integer' ),
					'stock_status' => self::text_arg(),
					'status'       => self::text_arg( array( 'publish', 'draft' ) ),
					'images'       => array(
						'type'              => 'array',
						'items'             => array( 'type' => 'integer' ),
						'sanitize_callback' => array( __CLASS__, 'clean_list' ),
					),
				),
			)
		);

		// Y subir una de esas fotos: un archivo, en el campo `file` de un cuerpo
		// `multipart/form-data`. No lee ningún parámetro.
		register_rest_route(
			self::REST_NAMESPACE,
			'/app/products/images',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_product_image' ),
				'permission_callback' => array( $this, 'can_create_product' ),
				'args'                => array(),
			)
		);

		// Los teléfonos del usuario que reciben los avisos de pedidos nuevos:
		// una ruta con tres métodos, con el permiso de los pedidos.
		register_rest_route(
			self::REST_NAMESPACE,
			'/app/devices',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle_devices' ),
				'permission_callback' => array( $this, 'can_read_orders' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/devices',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_device_register' ),
				'permission_callback' => array( $this, 'can_write' ),
				'args'                => array(
					'token'    => self::text_arg(),
					'platform' => self::text_arg( APSW_App_Push::PLATFORMS ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/app/devices',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'handle_device_remove' ),
				'permission_callback' => array( $this, 'can_write' ),
				'args'                => array(
					'token' => self::text_arg(),
				),
			)
		);
	}

	/**
	 * El id de la ruta: un número escrito con cifras, que es lo único que la
	 * ruta deja pasar (`\d+`).
	 *
	 * @return array
	 */
	private static function id_arg() {
		return array(
			'type'              => 'integer',
			'required'          => true,
			'sanitize_callback' => 'absint',
		);
	}

	/**
	 * La página de una lista.
	 *
	 * @return array
	 */
	private static function page_arg() {
		return array(
			'type'              => 'integer',
			'sanitize_callback' => array( __CLASS__, 'clean_page' ),
		);
	}

	/**
	 * El texto que se busca en una lista.
	 *
	 * @return array
	 */
	private static function search_arg() {
		return array(
			'type'              => 'string',
			'sanitize_callback' => array( __CLASS__, 'clean_search' ),
		);
	}

	/**
	 * Un texto que tiene que ser uno de una lista: un periodo, un filtro, un
	 * estado. La lista se dice aquí cuando es fija; la de los estados de un
	 * pedido es la de la tienda.
	 *
	 * @param string[] $choices Los valores que valen, si son siempre los mismos.
	 * @return array
	 */
	private static function text_arg( array $choices = array() ) {
		$arg = array(
			'type'              => 'string',
			'sanitize_callback' => array( __CLASS__, 'clean_text' ),
		);

		if ( $choices ) {
			$arg['enum'] = array_values( $choices );
		}

		return $arg;
	}

	/**
	 * Un valor suelto del cuerpo de una escritura: un precio, una cantidad, un
	 * sí o un no.
	 *
	 * @param string|string[] $type El tipo, o los tipos, con los que se escribe.
	 * @return array
	 */
	private static function value_arg( $type ) {
		return array(
			'type'              => $type,
			'sanitize_callback' => array( __CLASS__, 'clean_value' ),
		);
	}

	/**
	 * Una página: escrita con cifras, pasa como número. Vacía se queda vacía,
	 * que es la primera. Cualquier otra cosa pasa como 0, que no es ninguna
	 * página: la clase contesta su `invalid_params`.
	 *
	 * @param mixed $value Lo que llegó en `page`.
	 * @return mixed
	 */
	public static function clean_page( $value ) {
		if ( null === $value || '' === $value || is_int( $value ) ) {
			return $value;
		}

		// Nueve cifras como mucho, como las clases: más no caben en un entero.
		return is_string( $value ) && ctype_digit( $value ) && strlen( $value ) <= 9 ? (int) $value : 0;
	}

	/**
	 * Una búsqueda: un texto, sin los espacios de los lados. Lo que no es
	 * texto no busca nada.
	 *
	 * @param mixed $value Lo que llegó en `search`.
	 * @return string|null
	 */
	public static function clean_search( $value ) {
		if ( null === $value ) {
			return null;
		}

		return is_string( $value ) ? trim( $value ) : '';
	}

	/**
	 * Un texto que se compara, entero, con una lista: pasa tal cual. Lo que no
	 * es texto —una lista, un número— pasa como `false`, que no está en
	 * ninguna: la clase contesta su error, sin recorrer lo que vino.
	 *
	 * @param mixed $value Lo que llegó.
	 * @return string|false|null
	 */
	public static function clean_text( $value ) {
		return is_string( $value ) || null === $value ? $value : false;
	}

	/**
	 * Un valor suelto: un texto, un número, un sí o un no pasan tal cual, y los
	 * lee la clase, que es quien sabe cómo se escribe un precio. Una lista o un
	 * objeto pasan vacíos: la clase los rechaza igual, sin recorrerlos.
	 *
	 * @param mixed $value Lo que llegó.
	 * @return mixed
	 */
	public static function clean_value( $value ) {
		return is_scalar( $value ) || null === $value ? $value : array();
	}

	/**
	 * Una lista: pasa tal cual, con sus elementos en orden, y los lee la clase,
	 * que es quien sabe qué vale cada uno. Lo que no es una lista —un texto, un
	 * número— pasa como `false`, que la clase rechaza sin recorrerlo.
	 *
	 * @param mixed $value Lo que llegó.
	 * @return array|false|null
	 */
	public static function clean_list( $value ) {
		if ( null === $value ) {
			return null;
		}

		return is_array( $value ) ? array_values( $value ) : false;
	}

	/**
	 * Un sí que tiene que ser claro: `true`, o como lo escribe un formulario
	 * («true», «1», «yes», «on»). Todo lo demás es no.
	 *
	 * @param mixed $value Lo que llegó.
	 * @return bool
	 */
	public static function clean_yes( $value ) {
		return true === filter_var( $value, FILTER_VALIDATE_BOOLEAN );
	}

	/**
	 * Hace que los decimales de una respuesta de la app salgan como son:
	 * `-8.3`, y no `-8.3000000000000007`.
	 *
	 * `json_encode()` escribe un float con los dígitos que diga la directiva
	 * `serialize_precision` de PHP. Con 17 —lo que trae el php.ini de Local, y
	 * el de más de un hosting— escribe los del número binario; con -1, el
	 * decimal más corto que vuelve a dar el mismo número.
	 *
	 * El JSON no lo escribe la ruta: lo escribe
	 * `WP_REST_Server::serve_request()` cuando el callback ya ha devuelto, así
	 * que cambiar la directiva dentro del callback y dejarla como estaba no
	 * sirve de nada. `rest_pre_echo_response` es el último filtro antes de ese
	 * `wp_json_encode()`. Se cambia ahí, solo para las rutas `/app/` de este
	 * plugin, y se deshace en `shutdown`: después de escribir la respuesta
	 * `serve_request()` no tiene más ganchos, y lo siguiente que corre es eso.
	 * Una llamada interna con `rest_do_request()` no pasa por aquí y no cambia
	 * nada.
	 *
	 * @param mixed                $result  Los datos de la respuesta, que no se tocan.
	 * @param WP_REST_Server|null  $server  El servidor REST.
	 * @param WP_REST_Request|null $request La petición.
	 * @return mixed
	 */
	public function exact_decimals( $result, $server = null, $request = null ) {
		if ( ! $request instanceof WP_REST_Request || ! self::is_app_route( $request->get_route() ) ) {
			return $result;
		}

		$precision = ini_get( 'serialize_precision' );

		if ( false === $precision || '-1' === (string) $precision ) {
			return $result;
		}

		// phpcs:ignore WordPress.PHP.IniSet.Risky -- json_encode() writes floats with this directive; it is changed only while this REST response of the plugin is written, and restored on shutdown.
		if ( false !== ini_set( 'serialize_precision', '-1' ) && null === $this->precision ) {
			$this->precision = (string) $precision;
			add_action( 'shutdown', array( $this, 'restore_precision' ), 0 );
		}

		return $result;
	}

	/**
	 * Deja la `serialize_precision` de PHP como estaba antes de la respuesta.
	 *
	 * @return void
	 */
	public function restore_precision() {
		if ( null !== $this->precision ) {
			// phpcs:ignore WordPress.PHP.IniSet.Risky -- Restores the value the server had before exact_decimals() changed it.
			ini_set( 'serialize_precision', $this->precision );
		}
	}

	/**
	 * Si una ruta es de la app: las de `REST_NAMESPACE` que empiezan por `/app/`.
	 *
	 * @param mixed $route La ruta de la petición.
	 * @return bool
	 */
	private static function is_app_route( $route ) {
		return is_string( $route ) && 0 === strpos( $route, '/' . self::REST_NAMESPACE . '/app/' );
	}

	/**
	 * Leer Inicio: quien administra WooCommerce. Son cifras de la tienda, sin
	 * datos de ningún cliente.
	 *
	 * Si falla, WordPress responde 403 `rest_forbidden`, o 401 si la petición
	 * no trae credenciales válidas.
	 *
	 * @return bool
	 */
	public function can_read() {
		return (bool) current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Leer pedidos (la lista y el detalle): además, quien puede editar
	 * pedidos, que es lo que pide la pantalla de pedidos del wp-admin.
	 *
	 * Un pedido trae el correo, el teléfono y las direcciones del cliente, y
	 * las notas privadas de la tienda: un rol a medida que solo tenga
	 * `manage_woocommerce` no los ve en el wp-admin, y tampoco aquí.
	 *
	 * @return bool
	 */
	public function can_read_orders() {
		return $this->can_read() && (bool) current_user_can( 'edit_shop_orders' );
	}

	/**
	 * Escribir (cambiar un estado, añadir una nota): lo mismo que leer los
	 * pedidos. Tiene su nombre porque es otra pregunta, aunque hoy se
	 * conteste igual.
	 *
	 * @return bool
	 */
	public function can_write() {
		return $this->can_read_orders();
	}

	/**
	 * Leer productos (la lista y el detalle): además de administrar
	 * WooCommerce, quien puede editar productos, que es lo que pide la
	 * pantalla de productos del wp-admin.
	 *
	 * @return bool
	 */
	public function can_read_products() {
		return $this->can_read() && (bool) current_user_can( 'edit_products' );
	}

	/**
	 * Escribir en un producto (su precio, su stock): además, quien puede
	 * editar ese producto, el de la ruta. Un rol a medida puede editar los
	 * suyos y no los de otros.
	 *
	 * Si la ruta es la de una variación, se pregunta por su producto. Las
	 * variaciones se registran sin `map_meta_cap`
	 * (`WC_Post_Types::register_post_types()`), así que `edit_product` sobre
	 * el id de una variación es un permiso suelto que no mira de quién es: un
	 * rol que solo edita sus productos podía cambiar la variación de uno
	 * ajeno, y uno sin ese permiso suelto no podía cambiar la de uno suyo. Es
	 * además el mismo producto por el que pregunta `can_edit` en el detalle,
	 * así que los dos dicen siempre lo mismo.
	 *
	 * Un id que no es de ningún producto pasa, y también el de una variación
	 * sin producto: no hay a quién preguntarle, y la ruta contesta su 404
	 * `product_not_found` en vez de un 403 que no diría que ya no existe.
	 *
	 * @param WP_REST_Request|null $request Solicitud entrante.
	 * @return bool
	 */
	public function can_write_product( $request = null ) {
		if ( ! $this->can_read_products() ) {
			return false;
		}

		$id   = $request instanceof WP_REST_Request ? self::route_id( $request ) : 0;
		$id   = is_int( $id ) || ( is_string( $id ) && ctype_digit( $id ) && strlen( $id ) <= 18 ) ? (int) $id : 0;
		$type = $id > 0 ? get_post_type( $id ) : false;

		if ( 'product_variation' === $type ) {
			$id   = (int) wp_get_post_parent_id( $id );
			$type = $id > 0 ? get_post_type( $id ) : false;
		}

		if ( 'product' !== $type ) {
			return true;
		}

		return (bool) current_user_can( 'edit_product', $id );
	}

	/**
	 * Publicar un producto o pasarlo a borrador: además, quien puede publicar
	 * productos. Es lo que `can_publish` le dice a la app en el detalle.
	 *
	 * @param WP_REST_Request|null $request Solicitud entrante.
	 * @return bool
	 */
	public function can_publish_product( $request = null ) {
		return $this->can_write_product( $request ) && (bool) current_user_can( 'publish_products' );
	}

	/**
	 * Crear un producto y subir sus fotos: además de leer los productos, quien
	 * puede subir archivos a la biblioteca de medios. Es lo que `create` le
	 * dice a la app en la lista: sin él no hay botón de «Nuevo producto».
	 *
	 * Publicarlo pide además el permiso de publicar productos, que depende de
	 * lo que diga el cuerpo y lo comprueba APSW_App_Products::create(): quien
	 * no lo tiene recibe un 403 `cannot_publish`, no el `rest_forbidden` de
	 * quien no puede usar la ruta, porque en borrador sí puede guardarlo.
	 *
	 * @return bool
	 */
	public function can_create_product() {
		return $this->can_read_products() && (bool) current_user_can( 'upload_files' );
	}

	/**
	 * Atiende GET /app/home?period=…
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_home( WP_REST_Request $request ) {
		$period = $request->get_param( 'period' );

		if ( null === $period || '' === $period ) {
			$period = self::DEFAULT_PERIOD;
		}

		return $this->respond( $this->home->home( $period ) );
	}

	/**
	 * Atiende GET /app/orders?status=&search=&page=
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_orders( WP_REST_Request $request ) {
		return $this->respond(
			$this->orders->orders(
				array(
					'status' => $request->get_param( 'status' ),
					'search' => $request->get_param( 'search' ),
					'page'   => $request->get_param( 'page' ),
				)
			)
		);
	}

	/**
	 * Atiende GET /app/orders/<id>
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_order( WP_REST_Request $request ) {
		return $this->respond( $this->orders->order( self::route_id( $request ) ) );
	}

	/**
	 * Atiende POST /app/orders/<id>/status, con `{ "status": "…" }`.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_status( WP_REST_Request $request ) {
		$body   = self::body( $request );
		$result = $this->orders->set_status( self::route_id( $request ), isset( $body['status'] ) ? $body['status'] : null );

		// Un pedido que acaba de pasar a pagado (o de dejar de estarlo) cambia
		// las ventas: Inicio tiene que verlo al recargar, no un minuto después.
		if ( ! is_wp_error( $result ) ) {
			APSW_App_Home::forget_sales_cache();
		}

		return $this->respond( $result );
	}

	/**
	 * Atiende POST /app/orders/<id>/notes, con `{ "note": "…", "customer": false }`.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_note( WP_REST_Request $request ) {
		$body = self::body( $request );

		return $this->respond(
			$this->orders->add_note(
				self::route_id( $request ),
				isset( $body['note'] ) ? $body['note'] : null,
				// Sin un sí en el cuerpo, la nota es privada.
				isset( $body['customer'] ) ? $body['customer'] : false
			)
		);
	}

	/**
	 * Atiende GET /app/products?page=&search=&filter=
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_products( WP_REST_Request $request ) {
		return $this->respond(
			$this->products->products(
				array(
					'page'   => $request->get_param( 'page' ),
					'search' => $request->get_param( 'search' ),
					'filter' => $request->get_param( 'filter' ),
				)
			)
		);
	}

	/**
	 * Atiende GET /app/products/<id>. Con el id de una variación contesta el
	 * detalle de su producto: una variación se ve dentro de él.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_product( WP_REST_Request $request ) {
		return $this->respond( $this->products->product( self::route_id( $request ) ) );
	}

	/**
	 * Atiende POST /app/products/<id>/price, con `{ "regular": "…", "sale": "…" }`.
	 * `<id>` puede ser el de una variación.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_product_price( WP_REST_Request $request ) {
		return $this->respond( $this->products->set_price( self::route_id( $request ), self::body_fields( $request, array( 'regular', 'sale' ) ) ) );
	}

	/**
	 * Atiende POST /app/products/<id>/stock, con
	 * `{ "manage": true, "quantity": 12, "expected": 14, "status": "…" }`.
	 * `<id>` puede ser el de una variación.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_product_stock( WP_REST_Request $request ) {
		return $this->respond( $this->products->set_stock( self::route_id( $request ), self::body_fields( $request, array( 'manage', 'quantity', 'expected', 'status' ) ) ) );
	}

	/**
	 * Atiende POST /app/products/<id>/status, con `{ "status": "publish" }`.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_product_status( WP_REST_Request $request ) {
		$body = self::body( $request );

		return $this->respond( $this->products->set_status( self::route_id( $request ), isset( $body['status'] ) ? $body['status'] : null ) );
	}

	/**
	 * Atiende POST /app/products, con
	 * `{ "client_id": "…", "name": "…", "regular": "…", "sale": "…", "description": "…",
	 * "manage": false, "quantity": 0, "stock_status": "instock", "status": "publish", "images": [ 12, 13 ] }`.
	 *
	 * Contesta el detalle del producto, con 201 si se creó ahora y con 200 si
	 * ese `client_id` ya había creado el suyo.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_product_create( WP_REST_Request $request ) {
		$result = $this->products->create( self::body_fields( $request, array( 'client_id', 'name', 'regular', 'sale', 'description', 'manage', 'quantity', 'stock_status', 'status', 'images' ) ) );

		if ( is_wp_error( $result ) ) {
			return $this->respond( $result );
		}

		$response = $this->respond( $result['product'] );

		if ( $result['created'] ) {
			$response->set_status( 201 );
		}

		return $response;
	}

	/**
	 * Atiende POST /app/products/images: una foto, en el campo `file` de un
	 * cuerpo `multipart/form-data`.
	 *
	 * El archivo se lee de los archivos de la petición, que en una petición de
	 * verdad son los `$_FILES` de PHP, y de ningún otro sitio. El tamaño de la
	 * petición, de su cabecera: cuando el cuerpo supera lo que PHP admite,
	 * llega sin ningún archivo, y es lo único que queda para saber por qué.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_product_image( WP_REST_Request $request ) {
		$files = $request->get_file_params();
		$file  = is_array( $files ) && isset( $files['file'] ) ? $files['file'] : null;

		return $this->respond( APSW_App_Uploads::upload( $file, $request->get_header( 'content_length' ), get_current_user_id() ) );
	}

	/**
	 * Atiende GET /app/devices: los teléfonos del usuario que hace la petición.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_devices( WP_REST_Request $request ) {
		return $this->respond( $this->push->devices( get_current_user_id() ) );
	}

	/**
	 * Atiende POST /app/devices, con `{ "token": "ExponentPushToken[…]", "platform": "ios" }`.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_device_register( WP_REST_Request $request ) {
		$body = self::body( $request );

		return $this->respond( $this->push->register( get_current_user_id(), isset( $body['token'] ) ? $body['token'] : null, isset( $body['platform'] ) ? $body['platform'] : null ) );
	}

	/**
	 * Atiende DELETE /app/devices, con `{ "token": "ExponentPushToken[…]" }`.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_device_remove( WP_REST_Request $request ) {
		$body = self::body( $request );

		return $this->respond( $this->push->unregister( get_current_user_id(), isset( $body['token'] ) ? $body['token'] : null ) );
	}

	/**
	 * El id del pedido o del producto, que es el de la ruta.
	 *
	 * Se lee de los parámetros de la URL y no con `get_param()`, que mira
	 * antes el cuerpo JSON y la query: un `id` ahí taparía al de la ruta, y la
	 * escritura caería en otro pedido, o en otro producto, que el de la
	 * dirección.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return string|int
	 */
	private static function route_id( WP_REST_Request $request ) {
		$params = $request->get_url_params();

		return is_array( $params ) && isset( $params['id'] ) ? $params['id'] : 0;
	}

	/**
	 * El cuerpo JSON de una escritura. Solo el cuerpo: lo que venga en la
	 * query no cuenta, para que un enlace no baste para escribir.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @return array Vacío si la petición no trae un objeto JSON.
	 */
	private static function body( WP_REST_Request $request ) {
		$params = $request->get_json_params();

		return is_array( $params ) ? $params : array();
	}

	/**
	 * Los campos de una escritura que el cuerpo trae, y solo esos: lo que no
	 * se pidió (un `id`, por ejemplo) no pasa, y lo que el cuerpo no trae no se
	 * inventa. Así quien valida distingue un campo vacío de uno que no llegó.
	 *
	 * @param WP_REST_Request $request Solicitud entrante.
	 * @param string[]        $fields  Nombres de los campos de esa escritura.
	 * @return array
	 */
	private static function body_fields( WP_REST_Request $request, array $fields ) {
		return array_intersect_key( self::body( $request ), array_flip( $fields ) );
	}

	/**
	 * La respuesta de una ruta.
	 *
	 * Un error sale tal cual, con su código y su mensaje en el idioma de la
	 * tienda, que la app enseña sin tocar. WordPress saca el código HTTP de `status` en los
	 * datos del error: si alguno llega sin él, se le pone el 500 que WordPress
	 * usaría de todos modos, para que la app lo encuentre siempre en el mismo
	 * sitio.
	 *
	 * @param mixed $result Lo que devolvió APSW_App_Home, APSW_App_Orders, APSW_App_Products, APSW_App_Push o APSW_App_Uploads.
	 * @return WP_REST_Response|WP_Error
	 */
	private function respond( $result ) {
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();

			if ( ! is_array( $data ) || ! isset( $data['status'] ) ) {
				$result->add_data( array_merge( is_array( $data ) ? $data : array(), array( 'status' => 500 ) ) );
			}

			return $result;
		}

		return rest_ensure_response( $result );
	}
}
