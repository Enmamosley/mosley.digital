<?php
/**
 * Los pedidos de la app móvil: lista, detalle, cambio de estado y notas.
 *
 * @package APSW
 */

defined( 'ABSPATH' ) || exit;

/**
 * Da forma a lo que pintan la pestaña Pedidos y el detalle de un pedido, y
 * ejecuta las dos escrituras. Todo sale listo para mostrar: los importes ya
 * formateados con la moneda del pedido, las fechas en ISO 8601 con el desfase
 * de la tienda y los textos sin HTML. Solo usa la API de pedidos de
 * WooCommerce (`wc_get_orders()`, `wc_order_search()`, `wc_orders_count()` y
 * los métodos de `WC_Order`), así que funciona igual con HPOS y sin él.
 *
 * Los textos que devuelve van por gettext, con el inglés de base
 * (`mosley-digital-for-woocommerce`). Los nombres de los estados son los de
 * WooCommerce, en el idioma de la tienda.
 *
 * No comprueba permisos ni toca la caché de ventas de Inicio: eso es cosa de
 * APSW_App_Rest.
 */
class APSW_App_Orders {

	const PER_PAGE         = 20;
	const MAX_SEARCH_CHARS = 100;
	const MAX_NOTE_CHARS   = 2000;
	const MAX_NOTES        = 20;

	/**
	 * Caracteres que tiene como poco una búsqueda que no es un número. Una
	 * letra suelta casa con media tienda. Un número se busca siempre, tenga
	 * las cifras que tenga: es como se encuentra un pedido por su número.
	 */
	const MIN_SEARCH_CHARS = 2;

	/**
	 * Pedidos a los que llega una búsqueda: los 500 más recientes que casan,
	 * que son 25 páginas. Con los pedidos en wp_posts, `wc_order_search()`
	 * devuelve todos los ids que coinciden, sin tope, y todos acababan en el
	 * `post__in` de la consulta de la lista.
	 */
	const MAX_SEARCH_RESULTS = 500;

	/** Tope del nombre de una línea. */
	private const MAX_NAME_CHARS = 120;

	/**
	 * El estado «Borrador» de los carritos del checkout por bloques. Lo añade
	 * el propio WooCommerce a `wc_get_order_statuses()`, pero no son pedidos:
	 * nadie los pagó, y cada día borra del todo los que llevan más de un día
	 * (`DraftOrders::delete_expired_draft_orders()`).
	 */
	private const CHECKOUT_DRAFT = 'checkout-draft';

	/**
	 * Estados a los que la app no manda un pedido, aunque la tienda los tenga.
	 *
	 * - `refunded`: al entrar en él WooCommerce crea un reembolso
	 *   (`wc_order_fully_refunded()`), y los reembolsos no entran en esta fase.
	 * - `checkout-draft`: un toque en «Borrador» sería perder el pedido al día
	 *   siguiente.
	 */
	private const NOT_A_TARGET = array( 'refunded', self::CHECKOUT_DRAFT );

	/**
	 * Estados de WordPress con los que `wc_get_order()` devuelve un pedido que
	 * para la app no existe: lo que está en la papelera, y el borrador que el
	 * wp-admin crea al abrir «Añadir pedido» y nadie ha guardado todavía. No
	 * son estados de la tienda, así que la lista y la búsqueda —que piden los
	 * de `wc_get_order_statuses()`— nunca los traen.
	 */
	private const NOT_AN_ORDER = array( 'trash', 'auto-draft' );

	/**
	 * Última página que se sirve. Son 100.000 pedidos de profundidad, más de
	 * lo que nadie recorre en un teléfono, y deja el `offset` muy lejos de
	 * desbordar un entero cuando `page` llega con veinte cifras.
	 */
	private const MAX_PAGE = 5000;

	/**
	 * La lista de pedidos (§2.4 de la spec).
	 *
	 * @param array $args array( status, search, page ), todos opcionales.
	 * @return array|WP_Error array( orders, page, has_more, statuses ), o invalid_status / invalid_params (400).
	 */
	public function orders( array $args ) {
		$page = $this->page( isset( $args['page'] ) ? $args['page'] : null );

		if ( is_wp_error( $page ) ) {
			return $page;
		}

		$statuses = $this->statuses();
		$search   = $this->search_term( isset( $args['search'] ) ? $args['search'] : '' );
		$status   = isset( $args['status'] ) ? $args['status'] : '';

		// Con búsqueda el estado no cuenta, ni para filtrar ni para validar.
		if ( '' !== $search || '' === $status ) {
			// «Todos» son los pedidos de verdad. Sin `status`, wc_get_orders()
			// trae también los borradores del checkout. El wp-admin tampoco los
			// cuenta en «Todos», y aquí siguen teniendo su ficha con su contador.
			$wanted = array_values( array_diff( array_map( 'strval', array_keys( $statuses ) ), array( self::CHECKOUT_DRAFT ) ) );
		} elseif ( is_string( $status ) && isset( $statuses[ $status ] ) ) {
			$wanted = array( $status );
		} else {
			return new WP_Error( 'invalid_status', __( 'That status does not exist in this store.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$offset = ( $page - 1 ) * self::PER_PAGE;
		$query  = array(
			'type'    => 'shop_order',
			'status'  => $wanted,
			// Uno más de los que se enseñan, para saber si hay otra página.
			'limit'   => self::PER_PAGE + 1,
			'offset'  => $offset,
			'orderby' => 'date',
			'order'   => 'DESC',
		);

		// Una búsqueda demasiado corta no busca: no encuentra nada.
		if ( '' !== $search ) {
			$query['post__in'] = $this->is_searchable( $search ) ? $this->search_ids( $search, $query ) : array();
		}

		// Un `post__in` vacío no filtra: WooCommerce descarta los argumentos
		// vacíos y devolvería todos los pedidos de la tienda.
		$orders = isset( $query['post__in'] ) && ! $query['post__in'] ? array() : wc_get_orders( $query );
		$orders = is_array( $orders ) ? array_values( $orders ) : array();
		$counts = array();

		foreach ( $statuses as $slug => $label ) {
			$counts[] = array(
				'slug'  => (string) $slug,
				'label' => $label,
				'count' => (int) wc_orders_count( (string) $slug, 'shop_order' ),
			);
		}

		return array(
			'orders'   => array_map( array( $this, 'row' ), array_slice( $orders, 0, self::PER_PAGE ) ),
			'page'     => $page,
			'has_more' => count( $orders ) > self::PER_PAGE,
			'statuses' => $counts,
		);
	}

	/**
	 * El detalle de un pedido (§2.5 de la spec).
	 *
	 * @param int|string $order_id Id del pedido.
	 * @return array|WP_Error order_not_found (404) si no existe, no es un pedido o está en la papelera.
	 */
	public function order( $order_id ) {
		$order = $this->find( $order_id );

		return is_wp_error( $order ) ? $order : $this->detail( $order );
	}

	/**
	 * Cambia el estado de un pedido (§2.6 de la spec). WooCommerce manda los
	 * correos y dispara los ganchos de ese cambio, como desde el wp-admin.
	 *
	 * @param int|string $order_id Id del pedido.
	 * @param string     $status   Estado nuevo, sin el prefijo `wc-`.
	 * @return array|WP_Error El detalle actualizado, u order_not_found (404) / invalid_status (400).
	 */
	public function set_status( $order_id, $status ) {
		$order = $this->find( $order_id );

		if ( is_wp_error( $order ) ) {
			return $order;
		}

		$statuses = $this->statuses();

		if ( ! is_string( $status ) || ! isset( $statuses[ $status ] ) ) {
			return new WP_Error( 'invalid_status', __( 'That status does not exist in this store.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( in_array( $status, self::NOT_A_TARGET, true ) ) {
			/* translators: %s: name of an order status, for example "Refunded". */
			$message = sprintf( __( 'An order cannot be moved to "%s" from the app.', 'mosley-digital-for-woocommerce' ), $statuses[ $status ] );

			return new WP_Error( 'invalid_status', $message, array( 'status' => 400 ) );
		}

		// Ya está en ese estado: una repetición no duplica notas ni correos.
		if ( $status === $order->get_status() ) {
			return $this->detail( $order );
		}

		// update_status() no lanza: si algo falla al guardar lo registra y
		// devuelve false.
		if ( ! $order->update_status( $status, __( 'Status changed from the Mosley Digital app.', 'mosley-digital-for-woocommerce' ), true ) ) {
			return new WP_Error( 'status_update_failed', __( 'The order status could not be changed.', 'mosley-digital-for-woocommerce' ), array( 'status' => 500 ) );
		}

		// Se vuelve a leer: los ganchos del cambio trabajan con su propia copia
		// del pedido y pueden haberlo tocado otra vez (fecha de pago, stock).
		return $this->order( $order->get_id() );
	}

	/**
	 * Añade una nota a un pedido, firmada por el usuario (§2.7 de la spec).
	 *
	 * @param int|string $order_id Id del pedido.
	 * @param string     $note     Texto de la nota.
	 * @param bool       $customer true para que WooCommerce se la envíe al cliente por correo.
	 * @return array|WP_Error El detalle actualizado, u order_not_found (404) / invalid_note (400).
	 */
	public function add_note( $order_id, $note, $customer ) {
		$order = $this->find( $order_id );

		if ( is_wp_error( $order ) ) {
			return $order;
		}

		$note   = sanitize_textarea_field( $note );
		$length = mb_strlen( $note );

		if ( 0 === $length ) {
			return new WP_Error( 'invalid_note', __( 'Write the note before saving it.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		if ( $length > self::MAX_NOTE_CHARS ) {
			/* translators: %d: maximum number of characters of an order note. */
			$message = sprintf( __( 'The note cannot be longer than %d characters.', 'mosley-digital-for-woocommerce' ), self::MAX_NOTE_CHARS );

			return new WP_Error( 'invalid_note', $message, array( 'status' => 400 ) );
		}

		// Una nota al cliente es un correo que no se puede retirar: solo sale
		// con un sí claro. «false» escrito como texto no lo es.
		$to_customer = filter_var( $customer, FILTER_VALIDATE_BOOLEAN );

		// add_order_note() devuelve el id del comentario, o false si WordPress
		// no pudo guardarlo.
		if ( ! $order->add_order_note( $note, $to_customer ? 1 : 0, true ) ) {
			return new WP_Error( 'note_failed', __( 'The note could not be saved.', 'mosley-digital-for-woocommerce' ), array( 'status' => 500 ) );
		}

		return $this->detail( $order );
	}

	/**
	 * El número de un teléfono listo para `https://wa.me/<número>`: solo
	 * dígitos, con el prefijo del país y sin `+`.
	 *
	 * Un teléfono que ya trae su prefijo (`+52…` o `0052…`) se usa tal cual. A
	 * los demás se les antepone el del país de facturación, sin los ceros
	 * iniciales: el 0 de «07911 123456» es el prefijo de marcado nacional y no
	 * forma parte del número internacional.
	 *
	 * @param string $phone   Teléfono como lo escribió el cliente.
	 * @param string $country País de facturación (código ISO de dos letras).
	 * @return string|null Entre 8 y 15 dígitos, o null si no se puede componer.
	 */
	public static function whatsapp_number( $phone, $country ) {
		$phone = preg_replace( '/[^0-9+]/', '', is_scalar( $phone ) ? (string) $phone : '' );

		if ( 0 === strpos( $phone, '+' ) ) {
			$digits = self::digits( $phone );
		} elseif ( 0 === strpos( $phone, '00' ) ) {
			$digits = self::digits( substr( $phone, 2 ) );
		} else {
			// Algunos países tienen varios prefijos: WooCommerce ya devuelve el
			// primero, pero su docblock admite un array.
			$code   = WC()->countries->get_country_calling_code( (string) $country );
			$code   = self::digits( is_array( $code ) ? reset( $code ) : $code );
			$number = ltrim( self::digits( $phone ), '0' );

			// Sin prefijo no hay número internacional: diez dígitos locales
			// caben en el rango y wa.me los tomaría por un número de otro país.
			$digits = '' === $code || '' === $number ? '' : $code . $number;
		}

		$length = strlen( $digits );

		return $length >= 8 && $length <= 15 ? $digits : null;
	}

	/**
	 * La página pedida, desde 1.
	 *
	 * @param mixed $page Lo que llegó en `page`; null o '' es la primera.
	 * @return int|WP_Error
	 */
	private function page( $page ) {
		if ( null === $page || '' === $page ) {
			return 1;
		}

		// Nueve cifras como mucho: una cadena más larga no cabe en un entero.
		$digits = is_string( $page ) && ctype_digit( $page ) && strlen( $page ) <= 9;
		$page   = is_int( $page ) || $digits ? (int) $page : 0;

		if ( $page < 1 || $page > self::MAX_PAGE ) {
			return new WP_Error( 'invalid_params', __( 'Invalid page.', 'mosley-digital-for-woocommerce' ), array( 'status' => 400 ) );
		}

		return $page;
	}

	/**
	 * El texto de la búsqueda, limpio y con tope. '' es que no hay búsqueda.
	 *
	 * @param mixed $search Lo que llegó en `search`.
	 * @return string
	 */
	private function search_term( $search ) {
		if ( ! is_string( $search ) ) {
			return '';
		}

		// La app enseña los pedidos como «#1234», y así se escriben: la
		// búsqueda por id de WooCommerce solo entiende el número.
		$search = preg_replace( '/^#\s*(?=[0-9])/', '', trim( $search ) );

		return trim( mb_substr( (string) $search, 0, self::MAX_SEARCH_CHARS ) );
	}

	/**
	 * Si un texto es una búsqueda: un número, o al menos MIN_SEARCH_CHARS
	 * caracteres.
	 *
	 * @param string $search Texto de search_term(), no vacío.
	 * @return bool
	 */
	private function is_searchable( $search ) {
		return ctype_digit( $search ) || mb_strlen( $search ) >= self::MIN_SEARCH_CHARS;
	}

	/**
	 * Los ids de los pedidos que casan con la búsqueda: como mucho los
	 * MAX_SEARCH_RESULTS más recientes.
	 *
	 * `wc_order_search()` no se porta igual en los dos almacenes:
	 *
	 * - Con los pedidos en `wp_posts` devuelve todos los ids que coinciden, sin
	 *   orden ni tope (`WC_Order_Data_Store_CPT::search_orders()`). Aquí se
	 *   queda con los de id más alto, que son los más nuevos.
	 * - Con HPOS es un `wc_get_orders( array( 's' => … ) )` sin `limit`
	 *   (`OrdersTableDataStore::search_orders()`), así que devuelve como mucho
	 *   `posts_per_page` ids —10 de fábrica—, de cualquier estado. La lista
	 *   enseñaría 10 resultados y diría que no hay más.
	 *
	 * Esa consulta interna pasa por `woocommerce_order_query_args`, y ahí se le
	 * pone lo que necesita esta página: los mismos estados y tipo que la
	 * lista, y tantos ids como pedidos hay hasta el final de la página, más
	 * uno, sin pasar del tope. Salen del más reciente al más antiguo, que es
	 * el orden de la lista.
	 *
	 * El tope es el mismo en todas las páginas, así que todas se cortan del
	 * mismo conjunto: ninguna repite ni se salta un pedido, y la última dice
	 * que no hay más.
	 *
	 * Si se busca un número, ese id entra siempre, aunque haya 500 pedidos
	 * más nuevos que lo lleven en un teléfono: los dos almacenes dan por
	 * resultado el pedido con ese número, y buscarlo tiene que encontrarlo.
	 * Que sea un pedido, y de los que se enseñan, lo decide la consulta de la
	 * lista, que filtra estos ids por tipo y estado.
	 *
	 * @param string $term  Texto buscado.
	 * @param array  $query La consulta de la lista: type, status, limit y offset.
	 * @return int[]
	 */
	private function search_ids( $term, array $query ) {
		$widen = static function ( $query_vars ) use ( $query ) {
			if ( is_array( $query_vars ) && ! empty( $query_vars['s'] ) ) {
				$query_vars['type']   = $query['type'];
				$query_vars['status'] = $query['status'];
				$query_vars['limit']  = min( self::MAX_SEARCH_RESULTS, $query['offset'] + $query['limit'] );
			}

			return $query_vars;
		};

		add_filter( 'woocommerce_order_query_args', $widen );

		try {
			$ids = wc_order_search( $term );
		} finally {
			remove_filter( 'woocommerce_order_query_args', $widen );
		}

		$ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ) ) ) );

		rsort( $ids );

		$ids    = array_slice( $ids, 0, self::MAX_SEARCH_RESULTS );
		$number = ctype_digit( $term ) ? (int) $term : 0;

		if ( $number > 0 && ! in_array( $number, $ids, true ) ) {
			$ids[] = $number;
		}

		return $ids;
	}

	/**
	 * Una fila de la lista.
	 *
	 * @param WC_Order $order Pedido.
	 * @return array
	 */
	private function row( WC_Order $order ) {
		return array(
			'id'            => (int) $order->get_id(),
			'number'        => (string) $order->get_order_number(),
			'status'        => $this->status( $order ),
			'date'          => self::iso_date( $order->get_date_created() ),
			'customer'      => $this->customer_name( $order ),
			'total'         => self::money( $order->get_total(), $order ),
			'items_summary' => $this->items_summary( $order ),
		);
	}

	/**
	 * Las dos primeras líneas con su cantidad, y cuántas más hay:
	 * «Taza azul ×2, Termo ×1 y 3 más».
	 *
	 * @param WC_Order $order Pedido.
	 * @return string
	 */
	private function items_summary( WC_Order $order ) {
		$items = array_values( $order->get_items() );
		$names = array();

		foreach ( array_slice( $items, 0, 2 ) as $item ) {
			$quantity = $item->get_quantity();
			$names[]  = self::item_name( $item ) . ' ×' . ( is_numeric( $quantity ) ? $quantity + 0 : 0 );
		}

		$more = count( $items ) - count( $names );

		if ( $more <= 0 ) {
			return implode( ', ', $names );
		}

		return sprintf(
			/* translators: 1: the first items of an order, separated by commas, 2: number of items that are not listed. Example: "Blue mug ×2, Flask ×1 and 3 more". */
			_n( '%1$s and %2$d more', '%1$s and %2$d more', $more, 'mosley-digital-for-woocommerce' ),
			implode( ', ', $names ),
			$more
		);
	}

	/**
	 * El pedido, o el error de que no existe.
	 *
	 * Un reembolso (`shop_order_refund`) tiene id y `wc_get_order()` lo
	 * devuelve, pero no es un pedido que abrir: hereda de `WC_Abstract_Order`,
	 * no de `WC_Order`. Los tipos de otros plugins que sí heredan de `WC_Order`
	 * (suscripciones) tampoco salen en la lista, así que tampoco se abren. Ni
	 * lo que está en la papelera o es un borrador del wp-admin: sin esto, con
	 * su id se leían los datos del cliente y se le podía cambiar el estado o
	 * mandar una nota.
	 *
	 * @param int|string $order_id Id del pedido.
	 * @return WC_Order|WP_Error
	 */
	private function find( $order_id ) {
		$id    = is_int( $order_id ) || ( is_string( $order_id ) && ctype_digit( $order_id ) ) ? (int) $order_id : 0;
		$order = $id > 0 ? wc_get_order( $id ) : false;

		if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() || in_array( $order->get_status(), self::NOT_AN_ORDER, true ) ) {
			return new WP_Error( 'order_not_found', __( 'This order no longer exists.', 'mosley-digital-for-woocommerce' ), array( 'status' => 404 ) );
		}

		return $order;
	}

	/**
	 * La forma del detalle.
	 *
	 * @param WC_Order $order Pedido.
	 * @return array
	 */
	private function detail( WC_Order $order ) {
		$email = trim( (string) $order->get_billing_email() );
		$phone = trim( (string) $order->get_billing_phone() );
		$title = APSW_App_Text::plain( $order->get_payment_method_title() );
		$note  = trim( (string) $order->get_customer_note() );

		// «Lleva envío» el pedido que tiene una línea de envío, como en los
		// totales de WooCommerce. La dirección de envío sola no cuenta: un
		// pedido puede guardarla aunque nada se envíe.
		$ships = count( $order->get_shipping_methods() ) > 0;

		return array(
			'id'            => (int) $order->get_id(),
			'number'        => (string) $order->get_order_number(),
			'status'        => $this->status( $order ),
			'date'          => self::iso_date( $order->get_date_created() ),
			'customer'      => array(
				'name'     => $this->customer_name( $order ),
				'email'    => '' !== $email ? $email : null,
				'phone'    => '' !== $phone ? $phone : null,
				'whatsapp' => self::whatsapp_number( $phone, $order->get_billing_country() ),
			),
			'billing'       => self::address_lines( $order->get_formatted_billing_address() ),
			'shipping'      => $ships
				? array(
					'method'  => APSW_App_Text::plain( $order->get_shipping_method() ),
					'address' => self::address_lines( $order->get_formatted_shipping_address() ),
				)
				: null,
			'items'         => $this->items( $order ),
			'totals'        => $this->totals( $order, $ships ),
			'payment'       => array(
				'method' => '' !== $title ? $title : null,
				'paid'   => (bool) $order->is_paid(),
			),
			'customer_note' => '' !== $note ? $note : null,
			'notes'         => $this->notes( $order ),
			'next_statuses' => $this->next_statuses( $order ),
			'can_edit'      => (bool) current_user_can( 'edit_shop_orders' ),
		);
	}

	/**
	 * Las líneas de producto del detalle.
	 *
	 * @param WC_Order $order Pedido.
	 * @return array
	 */
	private function items( WC_Order $order ) {
		$items = array();

		foreach ( $order->get_items() as $item ) {
			$meta = array();

			// Como wc_display_item_meta(): los metadatos visibles, sin los
			// atributos que ya van en el nombre de la variación.
			foreach ( $item->get_formatted_meta_data() as $entry ) {
				$value = self::one_line( $entry->display_value );

				if ( '' !== $value ) {
					$meta[] = self::one_line( $entry->display_key ) . ': ' . $value;
				}
			}

			// El producto puede haberse borrado después de la venta.
			$product  = $item->get_product();
			$image_id = $product ? (int) $product->get_image_id() : 0;
			$thumb    = $image_id > 0 ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : false;
			$quantity = $item->get_quantity();

			$items[] = array(
				'name'     => self::item_name( $item ),
				'meta'     => $meta ? implode( ', ', $meta ) : null,
				'quantity' => is_numeric( $quantity ) ? $quantity + 0 : 0,
				// Antes de cupones, como la fila «Subtotal»: las líneas suman
				// esa fila y el descuento va en la suya.
				'total'    => self::money( $item->get_subtotal(), $order ),
				'thumb'    => $thumb ? (string) $thumb : null,
			);
		}

		return $items;
	}

	/**
	 * Las filas de importes, en el orden en que se leen: de arriba abajo
	 * suman la última. Por eso el total va neto de reembolsos, como el que
	 * WooCommerce deja sin tachar en `get_formatted_order_total()`.
	 *
	 * @param WC_Order $order Pedido.
	 * @param bool     $ships Si lleva envío.
	 * @return array
	 */
	private function totals( WC_Order $order, $ships ) {
		$discount = (float) $order->get_discount_total();
		$fees     = $order->get_fees();
		$tax      = (float) $order->get_total_tax();
		$refunded = (float) $order->get_total_refunded();
		$rows     = array( array( 'subtotal', __( 'Subtotal', 'mosley-digital-for-woocommerce' ), (float) $order->get_subtotal() ) );

		if ( $discount > 0 ) {
			$rows[] = array( 'discount', __( 'Discount', 'mosley-digital-for-woocommerce' ), -$discount );
		}

		if ( $ships ) {
			$rows[] = array( 'shipping', __( 'Shipping', 'mosley-digital-for-woocommerce' ), (float) $order->get_shipping_total() );
		}

		// Los cargos (comisión del pago contra entrega, envoltorio) entran en
		// el total del pedido: sin su fila, las demás no lo suman. Sus
		// impuestos van con los del resto, en la fila siguiente. Un cargo
		// negativo es un descuento hecho a mano, y conserva su signo.
		if ( $fees ) {
			$fee_total = 0.0;

			foreach ( $fees as $fee ) {
				$fee_total += (float) $fee->get_total();
			}

			$rows[] = array( 'fees', __( 'Fees', 'mosley-digital-for-woocommerce' ), $fee_total );
		}

		if ( $tax > 0 ) {
			$rows[] = array( 'tax', __( 'Taxes', 'mosley-digital-for-woocommerce' ), $tax );
		}

		if ( $refunded > 0 ) {
			$rows[] = array( 'refunded', __( 'Refunded', 'mosley-digital-for-woocommerce' ), -$refunded );
		}

		$rows[] = array( 'total', __( 'Total', 'mosley-digital-for-woocommerce' ), max( 0.0, (float) $order->get_total() - $refunded ) );

		return array_map(
			static function ( $row ) use ( $order ) {
				return array(
					'key'   => $row[0],
					'label' => $row[1],
					'value' => self::money( $row[2], $order ),
				);
			},
			$rows
		);
	}

	/**
	 * Las notas más recientes, de la más nueva a la más antigua.
	 *
	 * Por id y no por fecha: un cambio de estado deja varias notas en el mismo
	 * segundo, y el id es el orden en que se escribieron. Es también el orden
	 * del wp-admin.
	 *
	 * @param WC_Order $order Pedido.
	 * @return array
	 */
	private function notes( WC_Order $order ) {
		$notes = wc_get_order_notes(
			array(
				'order_id' => $order->get_id(),
				'limit'    => self::MAX_NOTES,
				'orderby'  => 'id',
				'order'    => 'DESC',
			)
		);

		return array_map(
			static function ( $note ) {
				// wc_get_order_note() deja 'system' en added_by cuando la nota
				// la firmó WooCommerce y no un usuario.
				$system = 'system' === $note->added_by;

				if ( $note->customer_note ) {
					$type = 'customer';
				} else {
					$type = $system ? 'system' : 'private';
				}

				return array(
					'id'     => (int) $note->id,
					'text'   => APSW_App_Text::plain( $note->content ),
					'date'   => self::iso_date( $note->date_created ),
					'type'   => $type,
					'author' => $system ? 'WooCommerce' : (string) $note->added_by,
				);
			},
			is_array( $notes ) ? array_values( $notes ) : array()
		);
	}

	/**
	 * Los estados a los que se puede pasar el pedido.
	 *
	 * @param WC_Order $order Pedido.
	 * @return array Lista de array( slug, label ).
	 */
	private function next_statuses( WC_Order $order ) {
		$next = array();

		foreach ( $this->target_statuses() as $slug => $label ) {
			if ( $slug !== $order->get_status() ) {
				$next[] = array(
					'slug'  => $slug,
					'label' => $label,
				);
			}
		}

		return $next;
	}

	/**
	 * Los estados de la tienda, también los de otros plugins.
	 *
	 * @return array slug sin el prefijo `wc-` => etiqueta.
	 */
	private function statuses() {
		$statuses = array();

		foreach ( wc_get_order_statuses() as $key => $label ) {
			$key              = (string) $key;
			$slug             = 0 === strpos( $key, 'wc-' ) ? substr( $key, 3 ) : $key;
			$statuses[ $slug ] = (string) $label;
		}

		return $statuses;
	}

	/**
	 * Los estados a los que la app puede mandar un pedido.
	 *
	 * @return array slug => etiqueta.
	 */
	private function target_statuses() {
		return array_diff_key( $this->statuses(), array_flip( self::NOT_A_TARGET ) );
	}

	/**
	 * El estado de un pedido, con su etiqueta.
	 *
	 * @param WC_Order $order Pedido.
	 * @return array array( slug, label ).
	 */
	private function status( WC_Order $order ) {
		$slug = (string) $order->get_status();

		return array(
			'slug'  => $slug,
			'label' => (string) wc_get_order_status_name( $slug ),
		);
	}

	/**
	 * El nombre con el que la lista y el detalle enseñan al cliente.
	 *
	 * Por este orden: el nombre de facturación; el de su cuenta, si el pedido
	 * es de un cliente registrado y la cuenta sigue existiendo; su correo de
	 * facturación; y, si no hay nada de eso, «Invitado». Un pedido hecho para
	 * un cliente con cuenta puede no llevar nombre de facturación, y llamarlo
	 * «Invitado» no era verdad.
	 *
	 * @param WC_Order $order Pedido.
	 * @return string
	 */
	private function customer_name( WC_Order $order ) {
		$name = trim( (string) $order->get_formatted_billing_full_name() );

		if ( '' !== $name ) {
			return $name;
		}

		// get_user() devuelve false si el pedido es de un invitado o si la
		// cuenta se borró después de la compra.
		$user = $order->get_user();
		$name = is_object( $user ) && isset( $user->display_name ) ? trim( (string) $user->display_name ) : '';

		if ( '' !== $name ) {
			return $name;
		}

		$email = trim( (string) $order->get_billing_email() );

		return '' !== $email ? $email : __( 'Guest', 'mosley-digital-for-woocommerce' );
	}

	/**
	 * El nombre de una línea, con tope.
	 *
	 * @param WC_Order_Item $item Línea.
	 * @return string
	 */
	private static function item_name( $item ) {
		return mb_substr( APSW_App_Text::plain( $item->get_name() ), 0, self::MAX_NAME_CHARS );
	}

	/**
	 * Un importe con la moneda del pedido ("$1,250.00"), sin HTML.
	 *
	 * @param float    $amount Importe.
	 * @param WC_Order $order  Pedido.
	 * @return string
	 */
	private static function money( $amount, WC_Order $order ) {
		return APSW_App_Text::plain( wc_price( (float) $amount, array( 'currency' => $order->get_currency() ) ) );
	}

	/**
	 * Una fecha en ISO 8601 con el desfase de la tienda.
	 *
	 * Con `wp_date()` y no con `WC_DateTime::date( 'c' )`: en una tienda cuya
	 * zona horaria es un desfase manual («UTC-6»), `date()` da la hora local
	 * con `+00:00` detrás, que es otro instante.
	 *
	 * @param DateTimeInterface|null $date Fecha.
	 * @return string '' si el pedido no tiene fecha.
	 */
	private static function iso_date( $date ) {
		return $date instanceof DateTimeInterface ? (string) wp_date( 'c', $date->getTimestamp() ) : '';
	}

	/**
	 * Las líneas de una dirección formateada por WooCommerce, que las separa
	 * con `<br/>` y escapa cada valor.
	 *
	 * @param string $html Dirección de get_formatted_*_address().
	 * @return array
	 */
	private static function address_lines( $html ) {
		$lines = array_map( array( 'APSW_App_Text', 'plain' ), preg_split( '#<br\s*/?>#i', (string) $html ) );

		return array_values( array_filter( $lines, 'strlen' ) );
	}

	/**
	 * Un texto sin HTML ni entidades, en una sola línea.
	 *
	 * @param mixed $html Texto, quizá con HTML.
	 * @return string
	 */
	private static function one_line( $html ) {
		$text = APSW_App_Text::plain( $html );
		$flat = preg_replace( '/\s+/u', ' ', $text );

		// preg_replace() devuelve null si el texto no es UTF-8 válido.
		return null === $flat ? $text : trim( $flat );
	}

	/**
	 * Solo los dígitos de un texto.
	 *
	 * @param mixed $text Texto.
	 * @return string
	 */
	private static function digits( $text ) {
		return preg_replace( '/[^0-9]/', '', (string) $text );
	}
}
