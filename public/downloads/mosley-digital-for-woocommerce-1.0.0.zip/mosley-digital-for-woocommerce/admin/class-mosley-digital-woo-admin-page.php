<?php
/**
 * La página «Mosley Digital» del menú de WooCommerce.
 *
 * @package Mosley_Digital_Woo
 */

defined( 'ABSPATH' ) || exit;

/**
 * Una página de solo lectura: para qué sirve el plugin, los tres pasos para
 * conectar la app, dos comprobaciones de lo que la app necesita de la tienda
 * (HTTPS y contraseñas de aplicación) y qué sale de la tienda hacia un
 * servicio externo cuando alguien activa los avisos de pedidos nuevos. No
 * tiene formularios ni guarda nada.
 */
class Mosley_Digital_Woo_Admin_Page {

	const SLUG       = 'mosley-digital';
	const CAPABILITY = 'manage_woocommerce';

	/**
	 * Engancha la página al menú de administración.
	 *
	 * @return void
	 */
	public function init() {
		// Después de que WooCommerce registre su menú, y al final de él.
		add_action( 'admin_menu', array( $this, 'register_page' ), 99 );
	}

	/**
	 * Añade la página bajo WooCommerce, para quien administra la tienda.
	 *
	 * @return void
	 */
	public function register_page() {
		// «Mosley Digital» es el nombre de la app: no se traduce.
		add_submenu_page( 'woocommerce', 'Mosley Digital', 'Mosley Digital', self::CAPABILITY, self::SLUG, array( $this, 'render' ) );
	}

	/**
	 * Lo que la app necesita de la tienda, con su sí o su no.
	 *
	 * La app se identifica con una contraseña de aplicación de WordPress, que
	 * viaja en cada petición: por eso pide HTTPS, y por eso WordPress mismo no
	 * ofrece las contraseñas de aplicación sin él.
	 *
	 * @return array Lista de array( 'label', 'ok', 'help' ).
	 */
	public static function checks() {
		return array(
			array(
				'label' => __( 'The store is served over HTTPS', 'mosley-digital-for-woocommerce' ),
				'ok'    => 'https' === strtolower( (string) wp_parse_url( home_url(), PHP_URL_SCHEME ) ),
				'help'  => __( 'The app only connects to stores served over HTTPS. Install an SSL certificate and use https:// in the site address (Settings > General).', 'mosley-digital-for-woocommerce' ),
			),
			array(
				'label' => __( 'Application passwords are available', 'mosley-digital-for-woocommerce' ),
				'ok'    => function_exists( 'wp_is_application_passwords_available' ) && wp_is_application_passwords_available(),
				'help'  => __( 'The app uses them to sign in. WordPress turns them off on sites without HTTPS, and so do some security plugins: check their settings.', 'mosley-digital-for-woocommerce' ),
			),
		);
	}

	/**
	 * Pinta la página. Todo lo que sale de la tienda va escapado.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html( 'Mosley Digital' ); ?></h1>

			<p><?php esc_html_e( 'This plugin connects your store to the Mosley Digital mobile app: the sales of the period compared with the previous one, the orders to fulfil, the products that are low in stock, and every order and every product in detail, on your phone. From the app you can also change the status of an order and add notes to it, change the price and the stock of a product, publish it or move it back to draft, and create a product with its photos, which are saved in the media library of this store.', 'mosley-digital-for-woocommerce' ); ?></p>
			<p><?php esc_html_e( 'The app talks directly to your store. The only thing this plugin sends to an external service is the notification of a new order, and only when someone has turned notifications on in the app for this store: see "New order notifications" below.', 'mosley-digital-for-woocommerce' ); ?></p>

			<h2><?php esc_html_e( 'How to connect the app', 'mosley-digital-for-woocommerce' ); ?></h2>
			<ol>
				<li><?php esc_html_e( 'Install the Mosley Digital app on your phone.', 'mosley-digital-for-woocommerce' ); ?></li>
				<li>
					<?php esc_html_e( 'Type the address of this store in the app:', 'mosley-digital-for-woocommerce' ); ?>
					<code><?php echo esc_html( home_url() ); ?></code>
				</li>
				<li><?php esc_html_e( 'Approve the access with your WordPress user. An application password is created just for the app, and you can revoke it at any time from your profile.', 'mosley-digital-for-woocommerce' ); ?></li>
			</ol>
			<p class="description"><?php esc_html_e( 'Your user must be able to manage WooCommerce (an administrator or a shop manager). Orders and products are shown to users who can also edit them.', 'mosley-digital-for-woocommerce' ); ?></p>

			<h2><?php esc_html_e( 'Checks', 'mosley-digital-for-woocommerce' ); ?></h2>
			<ul class="mosley-digital-checks">
				<?php foreach ( self::checks() as $check ) : ?>
					<li class="<?php echo esc_attr( $check['ok'] ? 'mosley-digital-check-yes' : 'mosley-digital-check-no' ); ?>">
						<span class="dashicons <?php echo esc_attr( $check['ok'] ? 'dashicons-yes-alt' : 'dashicons-warning' ); ?>" style="color: <?php echo esc_attr( $check['ok'] ? '#00a32a' : '#d63638' ); ?>;" aria-hidden="true"></span>
						<?php echo esc_html( $check['label'] ); ?>:
						<strong><?php echo esc_html( $check['ok'] ? __( 'Yes', 'mosley-digital-for-woocommerce' ) : __( 'No', 'mosley-digital-for-woocommerce' ) ); ?></strong>
						<?php if ( ! $check['ok'] ) : ?>
							<br>
							<span class="description"><?php echo esc_html( $check['help'] ); ?></span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>

			<h2><?php esc_html_e( 'New order notifications', 'mosley-digital-for-woocommerce' ); ?></h2>
			<p><?php esc_html_e( 'Each user can turn on new order notifications in the app. From then on, when an order comes in (it reaches Processing, On hold or Completed from Pending payment, Failed, Cancelled or a draft, or it is created in one of those statuses), this store sends a notification to the phones that turned them on, except those of the person who made the change, through the Expo push notification service (650 Industries, Inc.), which hands it to Apple or Google to deliver it.', 'mosley-digital-for-woocommerce' ); ?></p>
			<p><?php esc_html_e( 'What is sent to Expo: the push token of each phone, the text of the notification (the order number, the order total and the name of the store) and, so that the app can open the order, the address of the store and the id of the order. No customer data is sent. Nothing is sent while no phone has notifications turned on.', 'mosley-digital-for-woocommerce' ); ?></p>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of phones. */
						__( 'Phones with notifications turned on for this store: %d.', 'mosley-digital-for-woocommerce' ),
						self::phones()
					)
				);
				?>
			</p>
			<p>
				<a href="<?php echo esc_url( 'https://expo.dev/terms' ); ?>"><?php esc_html_e( 'Expo terms of service', 'mosley-digital-for-woocommerce' ); ?></a>
				&middot;
				<a href="<?php echo esc_url( 'https://expo.dev/privacy' ); ?>"><?php esc_html_e( 'Expo privacy policy', 'mosley-digital-for-woocommerce' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Cuántos teléfonos tienen los avisos activados en esta tienda.
	 *
	 * @return int
	 */
	private static function phones() {
		return class_exists( 'APSW_App_Push', false ) ? APSW_App_Push::device_count() : 0;
	}
}
