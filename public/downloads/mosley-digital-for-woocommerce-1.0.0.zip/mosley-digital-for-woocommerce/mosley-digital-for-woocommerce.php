<?php
/**
 * Plugin Name:       Mosley Digital for WooCommerce
 * Plugin URI:        https://mosley.digital/woo
 * Description:       Connects your WooCommerce store to the Mosley Digital mobile app: today's sales, orders to fulfil, low stock, your products and new order notifications, on your phone.
 * Version:           1.0.0
 * Author:            Mosley Digital
 * Author URI:        https://mosley.digital
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Requires Plugins:  woocommerce
 * WC requires at least: 8.0
 * WC tested up to:   11.1
 * Text Domain:       mosley-digital-for-woocommerce
 * Domain Path:       /languages
 *
 * @package Mosley_Digital_Woo
 */

defined( 'ABSPATH' ) || exit;

/*
 * Este plugin solo sirve a la app móvil Mosley Digital las pantallas de
 * Inicio, Pedidos y Productos y los avisos de pedidos nuevos: quince rutas
 * REST (APSW_App_Rest) que leen la tienda, y escriben en ella, con las
 * funciones de WordPress y de WooCommerce.
 *
 * Guarda una caché de un minuto con los totales de ventas y, de quien activa
 * los avisos en la app, el identificador de avisos de su teléfono. La app
 * también crea productos, y sus fotos se guardan en la biblioteca de medios de
 * la tienda: las que no llegan a ser de ningún producto las borra, pasado un
 * día, una tarea programada (APSW_App_Uploads). Y hace una sola petición hacia
 * fuera: el aviso de un pedido nuevo, al servicio de avisos de Expo, que solo
 * sale si hay algún teléfono registrado en la tienda (APSW_App_Push).
 *
 * Mosley Digital publica otro plugin, más grande, «Mosley Digital IA for
 * WooCommerce», que trae estas mismas rutas con estas mismas clases. Los dos
 * no pueden servirlas a la vez, así que cuando el otro está activo éste se
 * aparta del todo: no registra rutas, no añade su página y no declara ninguna
 * clase. Para que eso valga se cargue cual se cargue antes, al incluirse este
 * archivo no declara más que sus propias funciones: decide en
 * `plugins_loaded`, cuando todos los plugins activos ya se han incluido —y el
 * otro, que arranca lo primero de ese gancho, ya ha definido lo suyo—. Ahí
 * carga lo que tiene que estar en cualquier petición —las traducciones y los
 * avisos, que escuchan los cambios de estado de los pedidos—, y las demás
 * clases de la app en `rest_api_init`, que es cuando hacen falta.
 *
 * Tampoco puede haber dos copias de este plugin en marcha. Todo lo que este
 * archivo declara con nombre va dentro de un `if`, así que una segunda copia
 * —la misma versión en otra carpeta— no declara nada dos veces: se incluye, no
 * arranca, y avisa en la pantalla de plugins de que sobra. Y antes de
 * publicarse, en sus primeras versiones de prueba, el plugin se llamaba
 * «Mosley Digital para WooCommerce», se instalaba en otra carpeta y declaraba
 * sus funciones sin esa guarda; sus nombres no se repiten aquí, y si esa copia
 * sigue activa ésta se aparta y lo avisa en el escritorio.
 *
 * La 1.0.0 es la primera versión publicada. Las de prueba que hubo antes
 * llevaban otra numeración, más alta (de la 2.19.0 a la 2.23.0): donde quede
 * una instalada, en esta misma carpeta, WordPress no ofrece ésta como
 * actualización y hay que subir el zip encima.
 *
 * Lo que va fuera del `if` lo hace cada copia por su cuenta, arranque o no, y
 * por eso va en funciones sin nombre: dos copias no pueden declarar la misma.
 */

/*
 * Le dice a WooCommerce que este plugin es compatible con el almacenamiento de
 * pedidos de alto rendimiento (HPOS): los pedidos se leen y se escriben solo
 * con las funciones de WooCommerce, nunca con consultas a sus tablas.
 *
 * Lo declara cada copia, con su propio archivo: WooCommerce mira plugin por
 * plugin, y al que está activo y no ha declarado nada lo da por incompatible.
 * Una copia que no arranca tampoco toca los pedidos.
 */
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

if ( ! defined( 'MOSLEY_DIGITAL_WOO_PLUGIN_FILE' ) ) {

	define( 'MOSLEY_DIGITAL_WOO_PLUGIN_FILE', __FILE__ );

	/**
	 * Si está activo el otro plugin de Mosley Digital, el que ya trae estas
	 * rutas.
	 *
	 * Se le reconoce por lo que solo él define: la constante de su archivo
	 * principal y su clase de arranque. Las dos existen cuando este plugin
	 * decide, en `plugins_loaded` con la prioridad por defecto: el otro las
	 * define lo primero de ese gancho, y sus versiones anteriores, en cuanto
	 * se incluía su archivo.
	 *
	 * @return bool
	 */
	function mosley_digital_woo_other_plugin_active() {
		return defined( 'APSW_PLUGIN_FILE' ) || class_exists( 'APSW_Plugin', false );
	}

	/**
	 * Si sigue activa una copia de prueba de este plugin de las que se
	 * instalaban en otra carpeta, con su nombre anterior.
	 *
	 * Se la reconoce por su función de arranque, que esta versión ya no
	 * declara.
	 *
	 * @return bool
	 */
	function mosley_digital_woo_earlier_copy_active() {
		return function_exists( 'mosley_digital_woo_bootstrap' );
	}

	/**
	 * Arranca el plugin, si le toca: con WooCommerce activo, sin el otro
	 * plugin y sin una copia anterior de éste.
	 *
	 * @return void
	 */
	function mosley_digital_woo_start() {
		if ( ! class_exists( 'WooCommerce', false ) || mosley_digital_woo_other_plugin_active() ) {
			return;
		}

		// Los textos van por gettext, con el inglés de base y el español en
		// languages/: ver APSW_App_I18n.
		if ( ! class_exists( 'APSW_App_I18n', false ) ) {
			require_once __DIR__ . '/includes/app/class-apsw-app-i18n.php';
		}

		APSW_App_I18n::register( __DIR__ . '/languages', false );

		if ( mosley_digital_woo_earlier_copy_active() ) {
			add_action( 'admin_notices', 'mosley_digital_woo_earlier_copy_notice' );

			return;
		}

		// Los avisos de pedidos nuevos escuchan los cambios de estado de los
		// pedidos, que pasan en cualquier petición —la compra de un cliente—.
		mosley_digital_woo_push()->init();

		add_action( 'rest_api_init', 'mosley_digital_woo_register_rest_routes' );

		// La tarea que borra las fotos que la app subió para un producto que no
		// se llegó a crear, y deja en borrador el producto que una petición
		// dejó a medio crear al morirse. Corre en una petición de WP-Cron, que
		// no pasa por la API REST: sus clases se cargan cuando le toca.
		add_action( 'apsw_app_uploads_cleanup', 'mosley_digital_woo_clean_uploads' );

		if ( is_admin() ) {
			if ( ! class_exists( 'Mosley_Digital_Woo_Admin_Page', false ) ) {
				require_once __DIR__ . '/admin/class-mosley-digital-woo-admin-page.php';
			}

			( new Mosley_Digital_Woo_Admin_Page() )->init();
		}
	}

	/**
	 * Los avisos de pedidos nuevos: los mismos para los ganchos de los pedidos
	 * y para las rutas.
	 *
	 * @return APSW_App_Push
	 */
	function mosley_digital_woo_push() {
		static $push = null;

		if ( null === $push ) {
			$classes = array(
				'APSW_App_Text' => 'includes/app/class-apsw-app-text.php',
				'APSW_App_Push' => 'includes/app/class-apsw-app-push.php',
			);

			foreach ( $classes as $class => $file ) {
				if ( ! class_exists( $class, false ) ) {
					require_once __DIR__ . '/' . $file;
				}
			}

			$push = new APSW_App_Push();
		}

		return $push;
	}

	/**
	 * La tarea de las fotos pendientes y de los productos a medio crear: carga
	 * sus clases y la corre.
	 *
	 * Si el otro plugin de Mosley Digital se activó después de programarla, la
	 * corre él.
	 *
	 * @return void
	 */
	function mosley_digital_woo_clean_uploads() {
		if ( mosley_digital_woo_other_plugin_active() ) {
			return;
		}

		if ( ! class_exists( 'APSW_App_Uploads', false ) ) {
			require_once __DIR__ . '/includes/app/class-apsw-app-uploads.php';
		}

		if ( ! class_exists( 'APSW_App_Products', false ) ) {
			require_once __DIR__ . '/includes/app/class-apsw-app-products.php';
		}

		APSW_App_Uploads::clean();
		APSW_App_Products::sweep();
	}

	/**
	 * Al desactivar el plugin: quita la tarea de las fotos pendientes —la de
	 * cada día y, si hay una, la siguiente pasada—, que es de WP-Cron y
	 * seguiría programada sin nadie que la atienda. Se
	 * vuelve a programar sola cuando el plugin vuelve a estar activo y llega
	 * una petición a la API REST.
	 *
	 * Si el otro plugin está activo, la tarea es suya.
	 *
	 * @return void
	 */
	function mosley_digital_woo_deactivate() {
		if ( ! mosley_digital_woo_other_plugin_active() ) {
			wp_clear_scheduled_hook( 'apsw_app_uploads_cleanup' );
		}
	}

	/**
	 * Avisa, a quien puede gestionar los plugins, de que este plugin no está
	 * en marcha porque sigue activa una copia anterior.
	 *
	 * @return void
	 */
	function mosley_digital_woo_earlier_copy_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-warning"><p>';
		echo esc_html(
			sprintf(
				/* translators: %s: the name this plugin had in its first test builds, before its public release: "Mosley Digital para WooCommerce". */
				__( 'Mosley Digital for WooCommerce is not running because its earlier version, "%s", is still active. That earlier copy is the one to deactivate and delete.', 'mosley-digital-for-woocommerce' ),
				'Mosley Digital para WooCommerce'
			)
		);
		echo '</p></div>';
	}

	/**
	 * Carga las clases de la app y registra sus quince rutas, con los permisos
	 * que cada una comprueba (APSW_App_Rest). Y deja programada la tarea diaria
	 * de las fotos pendientes, si no lo está.
	 *
	 * Se vuelve a mirar si el otro plugin está activo: pudo activarse en esta
	 * misma petición, después de `plugins_loaded`, y entonces las clases son
	 * ya las suyas. Y ninguna se carga si ya está declarada.
	 *
	 * @return void
	 */
	function mosley_digital_woo_register_rest_routes() {
		if ( mosley_digital_woo_other_plugin_active() ) {
			return;
		}

		$classes = array(
			'APSW_App_Store'    => 'includes/app/class-apsw-app-store.php',
			'APSW_App_Text'     => 'includes/app/class-apsw-app-text.php',
			'APSW_App_Home'     => 'includes/app/class-apsw-app-home.php',
			'APSW_App_Orders'   => 'includes/app/class-apsw-app-orders.php',
			'APSW_App_Products' => 'includes/app/class-apsw-app-products.php',
			'APSW_App_Uploads'  => 'includes/app/class-apsw-app-uploads.php',
			'APSW_App_Rest'     => 'includes/app/class-apsw-app-rest.php',
		);

		foreach ( $classes as $class => $file ) {
			if ( ! class_exists( $class, false ) ) {
				require_once __DIR__ . '/' . $file;
			}
		}

		// Inicio sin nadie a quien preguntarle por la pestaña de chat de la
		// app: este plugin no la tiene.
		$rest = new APSW_App_Rest( new APSW_App_Home(), new APSW_App_Orders(), new APSW_App_Products(), mosley_digital_woo_push() );

		$rest->register_routes();

		// Los decimales de una respuesta salen como son (-8.3, no
		// -8.3000000000000007): ver APSW_App_Rest::exact_decimals().
		add_filter( 'rest_pre_echo_response', array( $rest, 'exact_decimals' ), 10, 3 );

		APSW_App_Uploads::schedule_cleanup();
	}

	add_action( 'plugins_loaded', 'mosley_digital_woo_start' );

	register_deactivation_hook( __FILE__, 'mosley_digital_woo_deactivate' );

} elseif ( MOSLEY_DIGITAL_WOO_PLUGIN_FILE !== __FILE__ ) {

	/*
	 * Otra copia de este plugin, en otra carpeta, se incluyó antes: es la que
	 * arranca. Ésta no hace nada, y se lo dice en la pantalla de plugins a
	 * quien puede borrarla.
	 */
	add_action(
		'admin_notices',
		static function () {
			global $pagenow;

			if ( 'plugins.php' !== $pagenow || ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			echo '<div class="notice notice-warning"><p>';
			echo esc_html(
				sprintf(
					/* translators: 1: folder of the copy of the plugin that is running, 2: folder of the copy that can be deleted. */
					__( 'Another copy of Mosley Digital for WooCommerce is already active, in the folder "%1$s". The copy in the folder "%2$s" does nothing: you can deactivate and delete it.', 'mosley-digital-for-woocommerce' ),
					basename( dirname( MOSLEY_DIGITAL_WOO_PLUGIN_FILE ) ),
					basename( __DIR__ )
				)
			);
			echo '</p></div>';
		}
	);
}
